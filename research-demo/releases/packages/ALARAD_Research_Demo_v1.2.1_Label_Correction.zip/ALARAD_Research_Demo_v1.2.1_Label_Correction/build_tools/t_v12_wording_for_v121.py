"""Targeted checks for the v1.2 wording/marker changes. Usage: t_v12_wording.py <v1.2.html> <v1.1.html>"""
import sys,re,json
from playwright.sync_api import sync_playwright
F12,F11=sys.argv[1],sys.argv[2]; res=[]
def T(n,c,d=''):
    res.append(bool(c)); print(('PASS' if c else 'FAIL'),'|',n,('| '+str(d)[:230] if (d and not c) else ''))
def boot(b,f,w=1440,h=900):
    pg=b.new_page(viewport={'width':w,'height':h}); pg.route('**/fonts.*/**',lambda r:r.abort()); pg.goto('file://'+f); pg.wait_for_timeout(400); return pg
FLOOR="(sid)=>{const g=[...document.querySelectorAll('#floorMap .staff-dot')].find(g=>g.textContent.includes(sid));const c=g.querySelectorAll('circle');const k=c[c.length-1];return {fill:k.getAttribute('fill'),stroke:k.getAttribute('stroke'),dash:k.getAttribute('stroke-dasharray'),text:g.textContent,title:(g.querySelector('title')||{}).textContent||''}}"
with sync_playwright() as p:
    b=p.chromium.launch(); pg=boot(b,F12); E=pg.evaluate; errs=[]
    pg.on('pageerror',lambda e:errs.append(str(e)))
    tick=lambda n:E("(()=>{for(let i=0;i<%d;i++)demoTick()})()"%n)
    def setup(): E("(()=>{resetLiveDemo(false);DEMO.flags.started=true;DEMO.startedAt=0;})()")
    # ---------- 1 suspected frozen
    setup(); tick(3); E("DEMO.fault={kind:'frozen',value:null}"); tick(7); sid=E("DEMO.staffId")
    T('precondition: SUSPECTED_FROZEN / uncertain',E("DEMO.sensor.state")=='SUSPECTED_FROZEN' and E("demoStaff().dataStatus")=='uncertain')
    E("showView('staff')")
    row=E("(sid)=>[...document.querySelectorAll('#staffTable tr')].find(r=>r.innerText.includes(sid)).innerText.replace(/\\n/g,' ')",sid)
    T('1 Staff Monitor: "Dose shown includes these repeated readings."','Dose shown includes these repeated readings.' in row,row)
    T('1 Staff Monitor: all existing uncertainty wording preserved',all(x in row for x in ['DATA UNCERTAIN — suspected frozen sensor','not a confirmed sensor failure','not a verified current measurement','Last assessed: NORMAL']),row)
    E("(sid)=>selectStaff(sid)",sid); panel=E("document.getElementById('staffInfoPanel').innerText")
    T('1 selected-staff panel shows the dose clarification + DATA UNCERTAIN','Dose shown includes these repeated readings.' in panel and 'DATA UNCERTAIN' in panel,panel)
    fl=E(FLOOR,sid)
    T('1 floor map: uncertain (last assessed NORMAL) marker fill is amber #fbbf24',fl['fill']=='#fbbf24',fl)
    T('1 floor map: dashed amber border, "· UNCERTAIN" label and tooltip preserved',fl['stroke']=='#fbbf24' and fl['dash']=='2 2' and '· UNCERTAIN' in fl['text'] and 'DATA UNCERTAIN — suspected frozen sensor (not a confirmed failure; not a verified current measurement)' in fl['title'],fl)
    # a high last-assessed class must not be masked by the amber fill
    E("(sid)=>{const s=staff.find(x=>x.id===sid); window.__keep=s.status; s.status='critical'; renderFloorMap&&renderFloorMap();}",sid)
    fl2=E(FLOOR,sid); T('1 floor map: uncertain worker whose last class is CRITICAL keeps the red fill (high class not masked) + dashed border + label',fl2['fill']=='#f87171' and fl2['dash']=='2 2' and 'UNCERTAIN' in fl2['text'],fl2)
    E("(sid)=>{const s=staff.find(x=>x.id===sid); s.status=window.__keep; renderFloorMap&&renderFloorMap();}",sid)
    # UNKNOWN unchanged (grey)
    setup(); tick(3); E("DEMO.fault={kind:'disconnect',value:null}"); tick(4); sid=E("DEMO.staffId")
    fu=E(FLOOR,sid); T('1 floor map: UNKNOWN marker unchanged (grey fill, dashed border, label)',fu['fill']=='#94a3b8' and fu['dash']=='2 2' and 'UNKNOWN' in fu['text'],fu)
    E("showView('staff')"); ru=E("(sid)=>[...document.querySelectorAll('#staffTable tr')].find(r=>r.innerText.includes(sid)).innerText",sid)
    T('1 UNKNOWN row does not get the frozen-dose sentence','Dose shown includes' not in ru and 'UNKNOWN — MONITORING UNAVAILABLE' in ru,ru)
    # normal worker unchanged
    setup(); tick(3); sid=E("DEMO.staffId"); fn=E(FLOOR,sid); T('1 floor map: normal marker still green and undashed',fn['fill']=='#34d399' and fn['dash'] is None,fn)
    # ---------- 2 live demo forecast
    setup(); tick(12); E("showView('livedemo')"); lp=E("document.getElementById('ldPredict').innerText.replace(/\\n/g,' ')")
    T('2 Live Demo: forecast covers "next 3 readings (3 simulated minutes)"','next 3 readings (3 simulated minutes)' in lp,lp)
    T('2 Live Demo: exact sentence "Extrapolation only — not a detection and not an alert; alerts come from threshold-based rules. Not a trained model."','Extrapolation only — not a detection and not an alert; alerts come from threshold-based rules. Not a trained model.' in lp,lp)
    T('2 Live Demo: SIMULATED PREDICTION tag and deviation-rule wording preserved','SIMULATED PREDICTION' in lp and 'Predicted risk if the trend continued (deviation rule only)' in lp,lp)
    # ---------- 3 alerts
    E("showView('alerts')"); at=E("document.getElementById('alertsList').innerText")
    T('3 Alerts: no "Time-series forecast" anywhere in the Alerts list or in the explanations',('Time-series forecast' not in at) and not any('Time-series forecast' in ' '.join(E("(()=>explainAlert(alerts.find(a=>a.id===%d)))()"%i)) for i in (3,4,5)),at[:300])
    for i,t in ((3,'ST-11'),(4,'ST-13'),(5,'ST-20')):
        m=E("alerts.find(a=>a.id==%d).meta"%i); ex=' '.join(E("explainAlert(alerts.find(a=>a.id==%d))"%i))
        T(f'3 Alert {t}: meta says illustrative static example, not generated by the live engine','Source: Illustrative example (static entry, not generated by the live detection engine)' in m,m)
        T(f'3 Alert {t}: explanation states static/hand-written origin and never "Generated by"','static, hand-written illustrative example' in ex and 'not generated by the live detection engine' in ex and 'Generated by' not in ex,ex)
    T('[v1.2.1: intentionally changed from v1.2] alerts 1, 2 now also carry the static-origin explanation (no "Generated by")',all(('static, hand-written illustrative example' in ' '.join(E("explainAlert(alerts.find(a=>a.id==%d))"%i))) and 'Generated by' not in ' '.join(E("explainAlert(alerts.find(a=>a.id==%d))"%i)) for i in (1,2)))
    T('3 alert ids/levels/titles unchanged (6 alerts, 2 critical, 3 warning, 1 info)',E("alerts.length")==6 and E("alerts.filter(a=>a.level==='critical').length")==2 and E("alerts.filter(a=>a.level==='warning').length")==3 and E("alerts.filter(a=>a.level==='info').length")==1)
    # ---------- 4 anomaly
    E("showView('anomaly')"); an=E("document.getElementById('view-anomaly').innerText")
    T('4 Anomaly: "Engine Input" heading and "this rule-based engine outputs"','Engine Input' in an and 'this rule-based engine outputs a risk score, forecast, and alert/recommendation only' in an,an[:300])
    T('4 Anomaly: no "Model Input" / "this model outputs"','Model Input' not in an and 'this model outputs' not in an)
    T('4 Anomaly: "Recalculate Model" button preserved and still works',E("[...document.querySelectorAll('#view-anomaly button')].some(x=>x.textContent.includes('Recalculate Model'))"))
    E("(()=>{[...document.querySelectorAll('#view-anomaly button')].find(x=>x.textContent.includes('Recalculate Model')).click()})()"); an2=E("document.getElementById('view-anomaly').innerText")
    T('4 Anomaly: recalculation runs; constant-rate + "not a trend forecast" wording shown with the user-defined duration',re.search(r'Projected dose for a \d+-minute task at this constant rate = [\d.]+ mSv \(current rate held constant; not a trend forecast\)',an2) is not None,an2[-500:])
    T('4 Anomaly: factor table label "Projected task dose (current rate held constant over the task — not a trend forecast)"','Projected task dose (current rate held constant over the task — not a trend forecast)' in an2)
    E("(()=>{const e=document.getElementById('inDur'); e.value=45; runAnomalyModel();})()"); an3=E("document.getElementById('view-anomaly').innerText")
    T('5 Anomaly: user-defined duration still respected (45-minute task)','Projected dose for a 45-minute task' in an3,an3[-400:])
    # ---------- 5 live demo / lab durations
    setup(); tick(6); E("showView('livedemo')"); fx=E("document.getElementById('ldFactors').innerText.replace(/\\n/g,' ')")
    T('5 Live Demo: factor reads "current rate held constant … not a trend forecast" and keeps "over 20 min"','Projected task dose (current rate held constant over the task — not a trend forecast)' in fx and re.search(r'mSv over 20 min',fx) is not None,fx)
    T('5 Live Demo: trend row still "informational, no threshold"','Trend (informational, no threshold)' in fx)
    E("showView('simlab')"); sl=E("document.getElementById('view-simlab').innerText")
    T('5 Simulation Lab: 30-minute horizon preserved + constant-rate / not a trend forecast wording','30-minute projection horizon' in sl and 'the current rate held constant for 30 minutes — not a trend forecast' in sl,'')
    # ---------- disclaimers & identity
    body=E("document.body.innerText")
    T('disclaimers kept: SIMULATED DATA ONLY strips, SIMULATION / DEMO label, prototype footer, SIMULATED pill',E("document.body.textContent.split('SIMULATED DATA ONLY').length-1")>=2 and 'SIMULATION / DEMO' in body and 'Prototype — not for clinical use' in E("document.querySelector('.sidebar-foot').textContent") and 'SIMULATED' in E("document.querySelector('.live-pill').innerText"))
    h12=open(F12,encoding='utf-8').read(); h11=open(F11,encoding='utf-8').read()
    cnt=lambda h:[len(re.findall(x,h,re.I)) for x in ('simulat','not for clinical use','not a medical decision','not clinically validated','research prototype','SIMULATED DATA ONLY','not a trained','NOT ESTABLISHED','FUTURE WORK')]
    T('no disclaimer removed: counts of simulation / not-clinical / not-a-trained-model phrases are >= those in v1.1 (equal except the added sentences)',all(a>=c for a,c in zip(cnt(h12),cnt(h11))),(cnt(h12),cnt(h11)))
    T('sidebar label reads ALARAD v1.2.1 and no "v1.1"/"v1.0" label remains',E("document.querySelector('.sidebar-foot').textContent").startswith('ALARAD v1.2.1') and 'ALARAD v1.1' not in open(F12,encoding='utf-8').read() and 'ALARAD v1.0' not in open(F12,encoding='utf-8').read() and 'ALARAD v1.2 ' not in open(F12,encoding='utf-8').read())
    T('no page errors',not errs,errs)
    # ---------- no calculation change: v1.1 vs v1.2 identical outputs
    pg2=boot(b,F11)
    JS="""()=>{const out=[];const rooms=Object.keys(typeof baselineRates!=='undefined'?baselineRates:{}).slice(0,3);
      for(const room of ['Cath Lab 1','CT Suite','Fluoroscopy Suite'])for(const rate of [20,60,90,118,310,470,900,3000])for(const dur of [5,20,30,45])for(const mode of ['personal','area'])
        out.push(JSON.stringify(evaluateExposure({room,procMult:1.4,rate,dur,dist:2,refDist:1,shield:1,mode})));
      out.push(JSON.stringify(linearForecast([118,126,115,122,190,310,420,470])));
      out.push(JSON.stringify(CONFIG)); return out.join('\\n')}"""
    a,c=pg.evaluate(JS),pg2.evaluate(JS)
    # evaluateExposure output has text fields that changed by design: the factor name only
    norm=lambda s:s
    T('engine unchanged: 192 evaluateExposure calls + linearForecast + CONFIG identical in v1.1 and v1.2',norm(a)==norm(c) and a.count('\n')>150)
    sm=lambda pgx:pgx.evaluate("()=>{return JSON.stringify(SimLab.SCEN.map(s=>{const r=SimLab.run(s.id,3,0);return [s.id,r.fingerprint,r.TP,r.FP,r.FN]}))}")
    sa,sc=sm(pg),sm(pg2)
    T('Simulation Lab fingerprints identical in v1.1 and v1.2 (or n/a in both)',sa==sc,(sa[:80],sc[:80]))
    b.close()
print('TOTAL',len(res),'PASS',sum(res),'FAIL',len(res)-sum(res)); sys.exit(0 if all(res) else 1)
