# ALARAD Safety-Failure Scenarios (S7–S13) — Simulated

**ALL DATA IS SIMULATED.** Sensor communication status is simulated; no hardware exists. Not a clinical, regulatory or validated-AI claim.

Settings: confirmation 1 min, immediate-alert policy dose (threshold 0.35 mSv projected task dose, simulation assumption), sensor parameters {"staleAfter":2,"disconnectedAfter":5,"frozenN":6,"frozenExitN":2,"recoverN":2,"resolution":0.1}.

| Scenario | Rad events | TP | FP | FN | DQ faults | DQ TP | DQ FP | DQ FN | Observed dose mSv | Unmonitored min | Incidents rad/DQ | Naive notif. | Unresolved |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 7 Sensor disconnects during normal monitoring | 0 | 0 | 0 | 0 | 1 | 1 | 0 | 0 | 0.0683 | 15 | 0/1 | 1 | 1 |
| 8 Sensor disconnects during an active radiation incident | 1 | 1 | 0 | 0 | 1 | 1 | 0 | 0 | 0.2543 | 15 | 1/1 | 3 | 2 |
| 9 Invalid reading during an increasing exposure trend | 1 | 1 | 0 | 0 | 2 | 2 | 0 | 0 | 0.1508 | 3 | 1/1 | 4 | 2 |
| 10 Frozen sensor reading | 1 | 0 | 0 | 1 | 1 | 1 | 0 | 0 | 0.0561 | 0 | 0/1 | 1 | 1 |
| 11 Recovery after a communication interruption | 1 | 1 | 0 | 0 | 1 | 1 | 0 | 0 | 0.1381 | 7 | 1/1 | 2 | 2 |
| 12 Multiple workers with independent sensor failures | 1 | 1 | 0 | 0 | 3 | 3 | 0 | 0 | 0.2367 | 18 | 1/3 | 4 | 4 |
| 13 Simultaneous radiation and data-quality alerts | 1 | 1 | 0 | 0 | 1 | 1 | 0 | 0 | 0.1342 | 8 | 1/1 | 3 | 2 |

Observed dose is NOT the complete dose when unmonitored minutes exist. Missing, invalid and stale readings are never treated as zero exposure.
