#!/bin/bash
# Full reproducible verification. Usage: ./run_all.sh   (from the package root; ~20 min). Exit code 0 only if every gate in logs/SUMMARY.md passes.
set -u; cd "$(dirname "$0")"; ./setup_env.sh || { echo "hash check failed"; exit 2; }
mkdir -p logs evidence/data_regenerated_scenarios evidence/screenshots_after evidence/screenshots_before evidence/regen_candidate evidence/regen_baseline
L=logs; run(){ n=$1; shift; s=$(date +%s.%N); "$@" > $L/$n.stdout 2> $L/$n.stderr; c=$?; e=$(date +%s.%N); echo "exit_code=$c duration_s=$(echo "$e - $s" | bc) finished=$(date -u +%FT%TZ)" > $L/$n.meta; echo "$n exit=$c"; }
run run_build_candidate ./build_tools/build_candidate.sh
for n in t2_rerun t_sim_v2 t_validation_v2 t_phase3 t_final_fixes; do run run_$n python3 tests/$n.py; done
run run_t_validation python3 tests/t_validation.py                       # Phase-2 original: informational, expected 113 PASS / 1 FAIL (documented intentional change)
run run_t_final_fixes_base env TARGET=base python3 tests/t_final_fixes.py   # must FAIL on the baseline (proves the tests detect the defects)
cp logs/run_t_final_fixes.stdout logs/run_t_final_fixes_cand.stdout 2>/dev/null
RC=reference_calculations
run ref_science python3 $RC/ref_science.py env/new $L/ref_science_results.json
run ref_scenarios python3 $RC/ref_scenarios.py env/new . reference_data/phase2 evidence/data_regenerated_scenarios
run ref_policy python3 $RC/ref_policy.py env/new evidence/data_regenerated_scenarios
run ref_misc python3 $RC/ref_misc.py env/new $L/ref_misc_results.json
run ref_before_after python3 $RC/ref_before_after.py env/p2 env/new $L/ref_before_after_results.json
run ref_sweep python3 $RC/ref_sweep.py env/new reference_data/phase2 evidence/data_regenerated_scenarios
run ui_audit python3 $RC/ui_audit.py env/new evidence/screenshots_after $L/ui_audit_results.json
run shots_after python3 $RC/shots_extra.py env/new evidence/screenshots_after 8896
run shots_before python3 $RC/shots_extra.py env/base evidence/screenshots_before 8897
run regen_data_candidate python3 $RC/regen_data.py env/new evidence/regen_candidate
run regen_data_baseline python3 $RC/regen_data.py env/base evidence/regen_baseline
run data_sync_diff python3 $RC/data_sync_diff.py reference_data/phase3_baseline/data data evidence/DATA_SYNC_REPORT.md
python3 summarize.py; exit $?
