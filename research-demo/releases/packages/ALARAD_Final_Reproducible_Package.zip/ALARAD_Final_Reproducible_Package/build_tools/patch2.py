"""Final-release-candidate patch #2 (applied AFTER patch.py): N-01 (uncertain display on staff surfaces) and N-03 (static test card labelling). Display/text only."""
import sys
p=sys.argv[1]; s=open(p,encoding='utf-8').read()
def rep(old,new,cnt=1):
    global s
    assert s.count(old)==cnt,(s.count(old),old[:90])
    s=s.replace(old,new)
# ---------- N-01 ----------
rep("function staffUnknown(s){ return s.dataStatus==='unknown'; }",
"function staffUnknown(s){ return s.dataStatus==='unknown'; }\n/* N-01: SUSPECTED_FROZEN = repeated identical readings. Uncertain, NOT a confirmed sensor failure and NOT a verified current measurement. */\nfunction staffUncertain(s){ return s.dataStatus==='uncertain'; }")
rep("""  return `<span class="badge ${s.status}" ${s.incidentFlag?`title="${s.incidentFlag}"`:''}>${s.status.toUpperCase()}</span>${s.incidentFlag?'<div style="font-size:9.5px;color:var(--red);margin-top:3px;">active incident</div>':''}`;
}""","""  if(staffUncertain(s)) return `<span class="badge elevated" ${s.incidentFlag?`title="${s.incidentFlag}"`:''}>DATA UNCERTAIN — suspected frozen sensor</span><div class="unmon-note">repeated identical readings: not a confirmed sensor failure and not a verified current measurement. Last assessed: ${s.status.toUpperCase()}</div>${s.incidentFlag?'<div style="font-size:9.5px;color:var(--red);margin-top:3px;">active incident</div>':''}`;
  return `<span class="badge ${s.status}" ${s.incidentFlag?`title="${s.incidentFlag}"`:''}>${s.status.toUpperCase()}</span>${s.incidentFlag?'<div style="font-size:9.5px;color:var(--red);margin-top:3px;">active incident</div>':''}`;
}""")
# floor map
rep("    const unk = staffUnknown(s);\n    const color = unk?","    const unk = staffUnknown(s), unc = staffUncertain(s);\n    const color = unk?")
rep("""${unk?'stroke="#fbbf24" stroke-width="1.5" stroke-dasharray="2 2"':''}></circle><text x="${s.x+9}" y="${s.y+4}" font-size="9" fill="#cbd5f5">${s.id}${unk?' · UNKNOWN':''}</text>${unk?`<title>${s.id}: UNKNOWN — MONITORING UNAVAILABLE</title>`:''}</g>`;""",
"""${(unk||unc)?'stroke="#fbbf24" stroke-width="1.5" stroke-dasharray="2 2"':''}></circle><text x="${s.x+9}" y="${s.y+4}" font-size="9" fill="#cbd5f5">${s.id}${unk?' · UNKNOWN':unc?' · UNCERTAIN':''}</text>${unk?`<title>${s.id}: UNKNOWN — MONITORING UNAVAILABLE</title>`:unc?`<title>${s.id}: DATA UNCERTAIN — suspected frozen sensor (not a confirmed failure; not a verified current measurement)</title>`:''}</g>`;""")
# selected panel: reuse the shared helper for unknown/uncertain
i=s.index("    <div class=\"calc-line\">Status: ${staffUnknown(s)?"); j=s.index("\n",i)
s=s[:i]+"""    <div class="calc-line">Status: ${(staffUnknown(s)||staffUncertain(s))?staffStatusHtml(s):`<span class="badge ${s.status}">${s.status.toUpperCase()}</span>`}${s.incidentFlag?` <span style="font-size:10.5px;color:var(--red)">${s.incidentFlag}</span>`:''}</div>"""+s[j:]
# mini list
rep("    const unk=staffUnknown(s);\n    const color = unk?","    const unk=staffUnknown(s), unc=staffUncertain(s);\n    const color = unk?")
rep("""outline:1px dashed #fbbf24':''}"></div><div class="sname">${s.name}</div><div class="sroom">${unk?'UNKNOWN — monitoring unavailable':s.dept}</div></div>`;""",
"""outline:1px dashed #fbbf24':unc?';outline:1px dashed #fbbf24':''}"></div><div class="sname">${s.name}</div><div class="sroom">${unk?'UNKNOWN — monitoring unavailable':unc?'DATA UNCERTAIN — suspected frozen':s.dept}</div></div>`;""")
# dashboard
rep("""      <div class="crit-banner" id="critBanner" style="display:flex;">""","""      <div class="crit-banner" id="uncBanner" role="status" style="display:none;background:rgba(251,191,36,.08);border-color:#fbbf24;">
        <span class="ico">⚠</span>
        <div><b id="uncCount">0</b> worker(s) with <b>DATA UNCERTAIN</b> — repeated identical readings (suspected frozen sensor; not a confirmed failure). Readings are shown but are not verified current measurements.</div>
        <div class="spacer"></div>
        <button class="btn sm" onclick="showView('staff')">Staff Monitor</button>
      </div>
      <div class="crit-banner" id="critBanner" style="display:flex;">""")
rep("""  if(ub){ ub.style.display=nUnk>0?'flex':'none'; document.getElementById('unkCount').textContent=nUnk; }
  if(sub) sub.textContent = nUnk>0 ? (staff.length-nUnk)+' monitored · '+nUnk+' UNKNOWN (monitoring unavailable)' : 'Under monitoring';""",
"""  const nUnc=staff.filter(s=>s.dataStatus==='uncertain').length, ucb=document.getElementById('uncBanner');
  if(ub){ ub.style.display=nUnk>0?'flex':'none'; document.getElementById('unkCount').textContent=nUnk; }
  if(ucb){ ucb.style.display=nUnc>0?'flex':'none'; document.getElementById('uncCount').textContent=nUnc; }
  if(sub) sub.textContent = (nUnk>0||nUnc>0) ? (staff.length-nUnk-nUnc)+' monitored'+(nUnk>0?' · '+nUnk+' UNKNOWN (monitoring unavailable)':'')+(nUnc>0?' · '+nUnc+' DATA UNCERTAIN (suspected frozen)':'') : 'Under monitoring';""")
# ---------- N-03 ----------
rep('{"name":"Phase-1 Simulation Lab suite (87) — unchanged","total":87','{"name":"Phase-1 Simulation Lab suite (87) — 5 assertions re-baselined in Phase 2","total":87')
rep('{"name":"Original app suite (92) — unchanged, reference"','{"name":"Original app suite (92) — assertions unmodified"')
rep('the validation suite recorded 113 checks on the Phase-3 build before the Lab test-status card existed and 114 with it, since that card adds one check."}',
    'the 113-vs-114 difference in the validation suite comes from a conditional placeholder (2 checks if this table exists, 1 placeholder otherwise). STATIC TEXT typed into this file; it is not produced by running tests."' + ',\n"recordedFor":"the Phase-3 build (SHA-256 736b8ab6…b980b2e0); NOT updated for later builds"}')
rep('<h4 style="margin-top:14px;">7 · Test execution status</h4>${ts}',
    '<p class="sl-note" id="slStaticTestBanner" role="note" style="border:1px solid var(--amber);border-radius:6px;padding:6px 8px;margin-top:14px;"><b>STATIC RECORD — NOT LIVE VERIFICATION EVIDENCE.</b> The table below is text typed into this file by the author. This page does not run any test and cannot show that any test passed. Verification of a build is only by running the test commands in the verification package (tests/run_all.sh) and reading its logs.</p><h4>7 · Test execution status (static record)</h4>${ts}')
rep("""<p class="sl-note">${TESTS.note}</p>`:'<p class="sl-note">Not embedded.</p>';""","""<p class="sl-note">${TESTS.note} <b>Recorded for ${TESTS.recordedFor||'an earlier build'}.</b></p>`:'<p class="sl-note">Not embedded.</p>';""")
open(p,'w',encoding='utf-8').write(s)
