import re,sys
p='src/cand.html'; s=open(p,encoding='utf-8').read()
def rep(old,new,cnt=1):
    global s
    assert s.count(old)==cnt,(s.count(old),old[:80])
    s=s.replace(old,new)
# ---- CSS (H-01 note style, M-07 tablet-only overflow containment)
rep("@media(prefers-reduced-motion:reduce){*{animation:none!important;transition:none!important;}}",
"""@media(prefers-reduced-motion:reduce){*{animation:none!important;transition:none!important;}}
/* Final candidate (H-01): note shown under a dose / status when monitoring is or was unavailable */
.unmon-note{font-size:9.5px;color:var(--amber);margin-top:3px;line-height:1.35;}
/* Final candidate (M-07): tablet widths only — contain wide tables inside their card (desktop >1100px and mobile <=760px rules are untouched) */
@media(min-width:761px) and (max-width:1100px){ .card table{display:block;max-width:100%;overflow-x:auto;} }""")
# ---- H-01 Dashboard: banner + KPI sub-line
rep("""      <div class="crit-banner" id="critBanner" style="display:flex;">""","""      <div class="crit-banner" id="unkBanner" role="status" style="display:none;background:rgba(251,191,36,.12);border-color:#fbbf24;">
        <span class="ico">⚠</span>
        <div><b id="unkCount">0</b> worker(s) with <b>UNKNOWN — MONITORING UNAVAILABLE</b> (simulated sensor link lost) — current exposure cannot be assessed and the observed dose is incomplete. Not shown as normal.</div>
        <div class="spacer"></div>
        <button class="btn sm" onclick="showView('staff')">Staff Monitor</button>
      </div>
      <div class="crit-banner" id="critBanner" style="display:flex;">""")
rep("""<div class="lbl">Active Staff</div><div class="sub">Under monitoring</div>""","""<div class="lbl">Active Staff</div><div class="sub" id="kpiStaffSub">Under monitoring</div>""")
rep("""  document.getElementById('kpiStaff').textContent = staff.length;
}
function staffUnknown""" if False else """  const el=document.getElementById('kpiRecs'); if(el) el.textContent = recs.filter(r=>r.status==='pending').length;
  document.getElementById('kpiStaff').textContent = staff.length;
}""","""  const el=document.getElementById('kpiRecs'); if(el) el.textContent = recs.filter(r=>r.status==='pending').length;
  document.getElementById('kpiStaff').textContent = staff.length;
  /* Final candidate (H-01): the Dashboard must not say "Under monitoring" for workers whose monitoring is unavailable */
  const nUnk=staff.filter(s=>s.dataStatus==='unknown').length, ub=document.getElementById('unkBanner'), sub=document.getElementById('kpiStaffSub');
  if(ub){ ub.style.display=nUnk>0?'flex':'none'; document.getElementById('unkCount').textContent=nUnk; }
  if(sub) sub.textContent = nUnk>0 ? (staff.length-nUnk)+' monitored · '+nUnk+' UNKNOWN (monitoring unavailable)' : 'Under monitoring';
}""")
# ---- H-01 helpers + renderStaff
rep("""function renderStaff(){
  document.getElementById('staffTable').innerHTML = staff.map(s=>
    `<tr><td><b>${s.name}</b><br><span style="color:var(--muted2);font-size:10px;">${s.id}</span></td>
    <td>${s.role}</td><td>${s.dept}</td><td>${s.today.toFixed(2)} mSv</td><td>${s.year.toFixed(1)} mSv</td>
    <td><span class="badge ${s.status}" ${s.incidentFlag?`title="${s.incidentFlag}"`:''}>${s.status.toUpperCase()}</span>${s.incidentFlag?'<div style="font-size:9.5px;color:var(--red);margin-top:3px;">active incident</div>':''}</td>""",
"""/* Final candidate (H-01): a worker whose monitoring is unavailable is NEVER shown as NORMAL (display only; s.status, doses and incidents are not changed). */
function staffUnknown(s){ return s.dataStatus==='unknown'; }
function staffUnmonNote(s){ return s.unmonMin>0?`<div class="unmon-note">observed dose is INCOMPLETE — ${s.unmonMin} min unmonitored</div>`:''; }
function staffStatusHtml(s){
  if(staffUnknown(s)) return `<span class="badge elevated" ${s.incidentFlag?`title="${s.incidentFlag}"`:''}>UNKNOWN — MONITORING UNAVAILABLE</span>${s.status!=='normal'?`<div class="unmon-note">last assessed: ${s.status.toUpperCase()} (historical, not current)</div>`:''}${s.incidentFlag?'<div style="font-size:9.5px;color:var(--red);margin-top:3px;">radiation incident still open</div>':''}`;
  return `<span class="badge ${s.status}" ${s.incidentFlag?`title="${s.incidentFlag}"`:''}>${s.status.toUpperCase()}</span>${s.incidentFlag?'<div style="font-size:9.5px;color:var(--red);margin-top:3px;">active incident</div>':''}`;
}
function renderStaff(){
  document.getElementById('staffTable').innerHTML = staff.map(s=>
    `<tr><td><b>${s.name}</b><br><span style="color:var(--muted2);font-size:10px;">${s.id}</span></td>
    <td>${s.role}</td><td>${s.dept}</td><td>${s.today.toFixed(2)} mSv${staffUnmonNote(s)}</td><td>${s.year.toFixed(1)} mSv</td>
    <td>${staffStatusHtml(s)}</td>""")
# floor map
rep("""    const color = s.status==='critical'?'#f87171':s.status==='elevated'?'#fbbf24':'#34d399';
    const sel = s.id===selectedStaffId""","""    const unk = staffUnknown(s);
    const color = unk?'#94a3b8':s.status==='critical'?'#f87171':s.status==='elevated'?'#fbbf24':'#34d399';
    const sel = s.id===selectedStaffId""")
rep("""<circle cx="${s.x}" cy="${s.y}" r="6" fill="${color}"></circle><text x="${s.x+9}" y="${s.y+4}" font-size="9" fill="#cbd5f5">${s.id}</text></g>`;""",
"""<circle cx="${s.x}" cy="${s.y}" r="6" fill="${color}" ${unk?'stroke="#fbbf24" stroke-width="1.5" stroke-dasharray="2 2"':''}></circle><text x="${s.x+9}" y="${s.y+4}" font-size="9" fill="#cbd5f5">${s.id}${unk?' · UNKNOWN':''}</text>${unk?`<title>${s.id}: UNKNOWN — MONITORING UNAVAILABLE</title>`:''}</g>`;""")
# selected-staff panel
rep("""<div class="calc-line">Today's dose: <b>${s.today.toFixed(2)} mSv</b> · Cumulative (yr): <b>${s.year.toFixed(1)} mSv</b></div>
    <div class="calc-line">Status: <span class="badge ${s.status}">${s.status.toUpperCase()}</span>${s.incidentFlag?` <span style="font-size:10.5px;color:var(--red)">${s.incidentFlag}</span>`:''}</div>""",
"""<div class="calc-line">Today's dose: <b>${s.today.toFixed(2)} mSv</b> · Cumulative (yr): <b>${s.year.toFixed(1)} mSv</b>${staffUnmonNote(s)}</div>
    <div class="calc-line">Status: ${staffUnknown(s)?`<span class="badge elevated">UNKNOWN — MONITORING UNAVAILABLE</span>${s.status!=='normal'?`<div class="unmon-note">last assessed: ${s.status.toUpperCase()} (historical, not current)</div>`:''}`:`<span class="badge ${s.status}">${s.status.toUpperCase()}</span>`}${s.incidentFlag?` <span style="font-size:10.5px;color:var(--red)">${s.incidentFlag}</span>`:''}</div>""")
# mini list
rep("""    const color = s.status==='critical'?'#f87171':s.status==='elevated'?'#fbbf24':'#34d399';
    return `<div class="staff-mini-row" data-id="${s.id}" role="button" tabindex="0" onkeydown="if(event.key==='Enter')selectStaff('${s.id}')" onclick="selectStaff('${s.id}')"><div class="sdot" style="background:${color}"></div><div class="sname">${s.name}</div><div class="sroom">${s.dept}</div></div>`;""",
"""    const unk=staffUnknown(s);
    const color = unk?'#94a3b8':s.status==='critical'?'#f87171':s.status==='elevated'?'#fbbf24':'#34d399';
    return `<div class="staff-mini-row" data-id="${s.id}" role="button" tabindex="0" onkeydown="if(event.key==='Enter')selectStaff('${s.id}')" onclick="selectStaff('${s.id}')"><div class="sdot" style="background:${color}${unk?';outline:1px dashed #fbbf24':''}"></div><div class="sname">${s.name}</div><div class="sroom">${unk?'UNKNOWN — monitoring unavailable':s.dept}</div></div>`;""")
# demo: reset flags, record unmonitored minutes, refresh panel
rep("const _ds=demoStaff(); if(_ds) _ds.dataStatus=null;","const _ds=demoStaff(); if(_ds){ _ds.dataStatus=null; _ds.unmonMin=0; }")
rep("const st=demoStaff(); DEMO.unmon++; st.dataStatus='unknown';","const st=demoStaff(); DEMO.unmon++; st.dataStatus='unknown'; st.unmonMin=DEMO.unmon;")
rep("renderStaff(); renderFloorMap(); renderStaffMiniList(); updateCritBanner(); renderSensorGrid(); demoRefresh();\n}\nfunction demoUnavailableHtml",
    "renderStaff(); renderFloorMap(); renderStaffMiniList(); updateCritBanner(); renderSensorGrid(); selectStaff(selectedStaffId); demoRefresh();\n}\nfunction demoUnavailableHtml")
rep("  renderStaff(); renderFloorMap(); renderStaffMiniList(); updateCritBanner(); renderSensorGrid();\n  demoRefresh();\n}\nfunction demoWatchAlert",
    "  renderStaff(); renderFloorMap(); renderStaffMiniList(); updateCritBanner(); renderSensorGrid(); selectStaff(selectedStaffId);\n  demoRefresh();\n}\nfunction demoWatchAlert")
# ---- M-06 wording
rep("if(r.uncertain) return base+' (UNCERTAIN — repeated values)';","if(r.uncertain) return 'UNCERTAIN — repeated values, suspected frozen sensor (last assessed: '+base+')';")
rep("""<div>Employee status<b class="badge ${st.status}">${st.status.toUpperCase()}</b>${st.dataStatus==='uncertain'?'<span class="badge elevated">DATA UNCERTAIN</span>':''}</div>`""",
"""<div>Employee status${st.dataStatus==='uncertain'?`<b class="badge elevated">UNCERTAIN — suspected frozen sensor</b><span class="badge elevated">DATA UNCERTAIN</span><span style="color:var(--amber);font-size:10px;">last assessed: ${st.status.toUpperCase()}</span>`:`<b class="badge ${st.status}">${st.status.toUpperCase()}</b>`}</div>`""")
rep(""":w.status==='ack'?'ACKNOWLEDGED':'NORMAL';""",""":w.status==='ack'?'ACKNOWLEDGED':(st.dataStatus==='uncertain'?'DATA UNCERTAIN':'NORMAL');""")
# ---- M-05
rep("let fcRates=[], slope=0;","let fcRates=[], slope=null;")
i=s.index("  const rv=rs.filter(r=>r.rate!=null);\n"); j=s.index("\n",s.index("if(rv.length>=3",i))
print(s[i:j][:400])
s=s[:i]+"""  /* Final candidate (M-05): trend/forecast only from the trailing CONTIGUOUS valid readings (>=3); otherwise UNAVAILABLE. Formula unchanged. */
  const run=[]; for(let q=rs.length-1;q>=0&&rs[q].rate!=null;q--) run.unshift(rs[q].rate);
  if(run.length>=3){ const f=linearForecast(run.slice(-4)); slope=f.slope; fcRates=f.next.map(v=>Math.max(0,Math.round(v))); }"""+s[j:]
rep("style=\"width:${Math.min(100,Math.max(0,slope/60*100)).toFixed(0)}%\"","style=\"width:${slope==null?0:Math.min(100,Math.max(0,slope/60*100)).toFixed(0)}%\"")
rep("${rs.length>=3?'regression slope '+slope.toFixed(1)+' µSv/h per reading':'collecting data…'}","${rs.length<3?'collecting data…':slope==null?'UNAVAILABLE — needs ≥3 contiguous valid readings':'regression slope '+slope.toFixed(1)+' µSv/h per reading'}")
# ---- M-04
rep("""<button class="btn sm" onclick="demoInjectFault()">Inject fault</button>
        <button class="btn sm ghost" onclick="demoClearFault()">Restore link</button>""",
"""<button class="btn sm" id="ldInjectBtn" onclick="demoInjectFault()">Inject fault</button>
        <button class="btn sm ghost" id="ldClearBtn" onclick="demoClearFault()">Restore link</button>
        <span id="ldFaultNote" class="unmon-note" style="display:none"></span>""")
rep("""function demoInjectFault(){
  if(!DEMO.flags.started||DEMO.flags.resolved){""","""/* Final candidate (M-04): fault controls are blocked while the scripted stream is not running (paused awaiting acknowledgement, or ended). Returns the reason text or ''. */
function demoStreamEnded(){ return DEMO.flags.started && DEMO.idx>=DEMO.script.length; }
function demoFaultBlock(){
  if(!DEMO.flags.started) return '';
  if(DEMO.flags.resolved) return 'The incident was resolved and the scripted simulated stream has ended (no further samples). Reset the demo to run it again.';
  if(DEMO.idx>=DEMO.script.length){
    if(DEMO.flags.detected&&!DEMO.flags.left) return 'The simulated stream is paused until the worker acknowledges the alert ("Acknowledge & leave area"). Fault controls are available again afterwards.';
    return 'The scripted simulated stream has ended (no further samples). Reset the demo to run it again.';
  }
  return '';
}
function demoInjectFault(){
  { const blk=demoFaultBlock(); if(blk){ toast('Fault controls unavailable',blk); return; } }
  if(!DEMO.flags.started||DEMO.flags.resolved){""")
rep("""function demoClearFault(){
  if(!DEMO.fault) return;""","""function demoClearFault(){
  if(!DEMO.fault) return;
  { const blk=demoFaultBlock(); if(blk){ toast('Fault controls unavailable',blk); return; } }""")
old="""hb.innerHTML='Sensor state: <span class="badge '+(s==='HEALTHY'?'normal':bad?'critical':'elevated')+'">'+s.replace('_',' ')+'</span>'+(DEMO.fault?' <span style="color:var(--amber)">(fault active: '+DEMO.fault.kind+')</span>':'')+(DEMO.unmon?' · '+DEMO.unmon+' min unmonitored':''); }"""
new="""const blk=demoFaultBlock(), endd=!!blk; hb.innerHTML=(endd?'Sensor state at last sample: ':'Sensor state: ')+'<span class="badge '+(s==='HEALTHY'?'normal':bad?'critical':'elevated')+'">'+s.replace('_',' ')+'</span>'+(endd?' <span style="color:var(--amber)">· '+(DEMO.flags.detected&&!DEMO.flags.left&&!DEMO.flags.resolved?'stream paused — no new samples until the worker acknowledges':'stream ended — no further samples')+(DEMO.fault?'; injected fault "'+DEMO.fault.kind+'" was still active at the last sample':'')+'</span>':(DEMO.fault?' <span style="color:var(--amber)">(fault active: '+DEMO.fault.kind+')</span>':''))+(DEMO.unmon?' · '+DEMO.unmon+' min unmonitored':''); }
  { const blk2=demoFaultBlock(), ib=document.getElementById('ldInjectBtn'), cb=document.getElementById('ldClearBtn'), fn=document.getElementById('ldFaultNote');
    if(ib) ib.disabled=!!blk2; if(cb) cb.disabled=!!blk2;
    if(fn){ fn.style.display=blk2?'inline':'none'; fn.textContent=blk2?'Fault controls disabled: '+blk2:''; } }"""
rep(old,new)
open(p,'w',encoding='utf-8').write(s)
