#!/bin/bash
# Rebuilds the candidate from the untouched Phase-3 baseline with the two documented patch scripts and compares it with the shipped candidate.
set -e; R="$(cd "$(dirname "$0")/.." && pwd)"; T=$(mktemp -d); mkdir "$T/src"; cp "$R/baseline/ALARAD_Prototype_Phase3.html" "$T/src/cand.html"
cd "$T"; python3 "$R/build_tools/patch.py" >/dev/null; python3 "$R/build_tools/patch2.py" src/cand.html
if cmp -s src/cand.html "$R/candidate/ALARAD_Prototype_Final_Release_Candidate.html"; then echo "REPRODUCED: patch.py + patch2.py applied to the baseline give the shipped candidate"; sha256sum src/cand.html; else echo "NOT REPRODUCED"; exit 1; fi
