"""Before/after evidence screenshots for the corrected items. Usage: shots_extra.py <dir containing alarad_prototype.html> <output dir> <port>"""
import subprocess,time,sys,os
from playwright.sync_api import sync_playwright
D,OUT,PORT=sys.argv[1],sys.argv[2],sys.argv[3]; os.makedirs(OUT,exist_ok=True)
srv=subprocess.Popen(['python3','-m','http.server',PORT,'-d',D],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);time.sleep(1)
try:
  with sync_playwright() as p:
    b=p.chromium.launch(args=['--no-sandbox']); pg=b.new_page(viewport={'width':768,'height':1024}); pg.goto(f'http://localhost:{PORT}/alarad_prototype.html'); pg.wait_for_timeout(500); E=pg.evaluate
    for v in ['staff','policy']:
        E(f"showView('{v}')"); pg.wait_for_timeout(300); pg.screenshot(path=f'{OUT}/M07_tablet768_{v}.png'); print('tablet',v,E("document.documentElement.scrollWidth"))
    pg.set_viewport_size({'width':1440,'height':900})
    E("(()=>{resetLiveDemo(false);DEMO.flags.started=true;DEMO.startedAt=0;for(let i=0;i<3;i++)demoTick();DEMO.fault={kind:'disconnect',value:null};for(let i=0;i<3;i++)demoTick();})()")
    for v,n in [('staff','H01_staff_monitor_outage'),('dashboard','H01_dashboard_outage'),('emergency','H01_floormap_minilist_outage'),('livedemo','M05_trend_during_gap')]:
        E(f"showView('{v}')"); pg.wait_for_timeout(300); pg.screenshot(path=f'{OUT}/{n}.png')
    E("(()=>{resetLiveDemo(false);DEMO.flags.started=true;DEMO.startedAt=0;for(let i=0;i<3;i++)demoTick();DEMO.fault={kind:'frozen',value:null};for(let i=0;i<7;i++)demoTick();})()")
    for v,n in [('staff','N01_staff_monitor_frozen'),('dashboard','N01_dashboard_frozen'),('emergency','N01_floormap_minilist_frozen'),('livedemo','M06_livedemo_frozen')]:
        E(f"showView('{v}')"); pg.wait_for_timeout(300); pg.screenshot(path=f'{OUT}/{n}.png')
    E("showView('simlab')"); pg.wait_for_timeout(300); E("document.getElementById('slValCard').scrollIntoView()"); pg.wait_for_timeout(200)
    E("(()=>{const x=document.getElementById('slStaticTestBanner')||[...document.querySelectorAll('#slValCard h4')].find(h=>h.textContent.includes('Test execution'));if(x)x.scrollIntoView({block:'center'})})()"); pg.wait_for_timeout(200); pg.screenshot(path=f'{OUT}/N03_static_test_card.png')
    b.close()
finally: srv.terminate()
