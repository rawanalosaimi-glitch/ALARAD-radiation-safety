"""Compare two data directories (old Phase-3 package data/ vs regenerated) and state exactly what changed. Usage: data_sync_diff.py <old> <new> <report.md>"""
import csv,sys,json,io
old,new,out=sys.argv[1:4]; L=['# Data synchronisation report (Phase-3 package data/ -> final candidate)\n']
for f in ['safety_steps.csv','safety_summary.csv']:
    a=list(csv.reader(open(f"{old}/{f}",encoding='utf-8'))); b=list(csv.reader(open(f"{new}/{f}",encoding='utf-8')))
    assert len(a)==len(b) and a[0]==b[0], f+': shape/header changed'
    cols={}; ex={}
    for ra,rb in zip(a[1:],b[1:]):
        for i,(x,y) in enumerate(zip(ra,rb)):
            if x!=y: cols[a[0][i]]=cols.get(a[0][i],0)+1; ex.setdefault(a[0][i],(x,y))
    L.append(f"## {f}: {len(a)-1} data rows, header identical; changed columns: {cols or 'none'}\n")
    for c,(x,y) in ex.items(): L.append(f"- `{c}` example: `{x}` -> `{y}`")
    L.append('')
for f in ['cmp.json']:
    A=json.load(open(f"{old}/{f}")); B=json.load(open(f"{new}/{f}")); L.append(f"## {f}: {'IDENTICAL' if A==B else 'DIFFERENT'}\n")
a=open(f"{old}/safety_report.md",encoding='utf-8').read().splitlines(); b=open(f"{new}/safety_report.md",encoding='utf-8').read().splitlines()
d=[(x,y) for x,y in zip(a,b) if x!=y]
L.append(f"## safety_report.md: {len(a)} vs {len(b)} lines, {len(d)} differing lines\n")
for x,y in d[:10]: L.append(f"- `{x[:150]}`\n  -> `{y[:150]}`")
open(out,'w',encoding='utf-8').write('\n'.join(L)+'\n'); print('\n'.join(L))
