"""Misc independent checks: report-number consistency, edge cases (timestamps/intervals/values), worker isolation, text claims scan."""
import subprocess,time,json,sys,re
from playwright.sync_api import sync_playwright
HTML_DIR,OUT=sys.argv[1:3]
srv=subprocess.Popen(['python3','-m','http.server','8888','-d',HTML_DIR],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL); time.sleep(1)
res={}
with sync_playwright() as p:
    b=p.chromium.launch(args=['--no-sandbox']); pg=b.new_page(); pg.goto('http://localhost:8888/alarad_prototype.html'); pg.wait_for_timeout(600); E=pg.evaluate
    res['incident_counts']=E("""()=>{SafetyLab.runAll();const r=SafetyLab.results();return Object.fromEntries(Object.entries(r).map(([k,v])=>[k,{naiveRad:v.naiveRad,naiveDq:v.naiveDq,incRad:v.inc.radiation!==undefined?v.inc.radiation:v.inc,inc:v.inc}]))}""")
    # timestamps / intervals / values
    ts=E("""()=>{const A=AlaradSafety;const o={};
      o.missing=A.validateTimestamp(undefined,{}).codes||A.validateTimestamp(undefined,{});o.nan=A.validateTimestamp(NaN,{});o.str=A.validateTimestamp('abc',{});o.neg=A.validateTimestamp(-1,{});
      o.mono=A.validateTimestamp(5,{prev:5});o.back=A.validateTimestamp(4,{prev:5});o.ok=A.validateTimestamp(6,{prev:5});o.future=A.validateTimestamp(100,{now:50});
      o.int_missing=A.validateInterval(undefined);o.int_zero=A.validateInterval(0);o.int_neg=A.validateInterval(-1);o.int_big=A.validateInterval(1441);o.int_ok=A.validateInterval(1);
      o.val_nan=A.validateValue(NaN);o.val_inf=A.validateValue(Infinity);o.val_neg=A.validateValue(-0.1);o.val_zero=A.validateValue(0);o.val_max=A.validateValue(1e6);o.val_over=A.validateValue(1e6+1);o.val_miss=A.validateValue(null);o.val_str=A.validateValue('5');return o}""")
    res['validators']=ts
    res['engine_extremes']=E("""()=>{const f=(r)=>{const e=evaluateExposure({room:'Cath Lab 1',procMult:1,rate:r,dur:30,mode:'personal'});return [e.riskClass,e.invalid===true,e.codes||null]};return {zero:f(0),tiny:f(1e-9),high:f(999999),max:f(1e6),over:f(1e6+1),neg0:f(-0)}}""")
    res['modes']=E("""()=>{const f=(m)=>{const e=evaluateExposure({room:'Cath Lab 1',procMult:1,rate:100,dur:30,mode:m,dist:1,refDist:1,shield:1});return [e.riskClass,e.invalid===true,e.codes||null]};return {personal:f('personal'),area:f('area'),badge:f('badge'),undef:f(undefined),empty:f(''),upper:f('PERSONAL')}}""")
    # worker isolation S12 at minute 30 & 45
    res['S12_isolation']=E("""()=>{const r=SafetyLab.results().S12;return r.workers.map(w=>({id:w.id,room:w.room,t30:w.rows[30].status,s30:w.rows[30].state,t45:w.rows[45].status,s45:w.rows[45].state,TP:w.TP,FP:w.FP,FN:w.FN,dTP:w.dTP}))}""")
    # S1-S6 / S7-S13 scenario parameter inventory
    res['scenario_inventory']=E("""()=>({orig:SimLab.SCEN.map(s=>({id:s.id,name:s.name,seed:s.seed,steps:SimLab.STEPS,workers:s.workers.map(w=>({id:w.id,room:w.room,pm:w.procMult,mode:w.mode||'personal',pattern:w.pattern,truth:w.truth}))})),
        safety:SafetyLab.SC.map(s=>({id:s.id,name:s.name,seed:s.seed,workers:s.workers.map(w=>({id:w.id,room:w.room,pm:w.procMult,pattern:w.pattern,truth:w.truth,faults:w.faults}))}))})""")
    # text claim scan across ALL views (hidden included)
    txt=E("[...document.querySelectorAll('.view')].map(v=>[v.id,v.textContent.replace(/\\s+/g,' ')])")
    pat=r'(clinically? (validated|proven|approved|ready)|validated (ai|ml|model)|certified|FDA|CE[- ]marked|NRRC[- ](approved|compliant)|SDAIA[- ](approved|compliant)|approved by|real[- ]time hardware|connected to (real|actual)|machine[- ]learning|deep learning|neural|trained (model|on)|guarantee|regulatory approval|hospital[- ]ready|production[- ]ready|\\bSAFE\\b)'
    hits=[]
    for vid,t in txt:
        for m in re.finditer(pat,t,flags=re.I): hits.append((vid,t[max(0,m.start()-90):m.end()+90]))
    res['claim_hits']=hits
    b.close()
srv.terminate()
json.dump(res,open(OUT,'w'),indent=1,default=str)
print(json.dumps({k:res[k] for k in ('incident_counts','validators','engine_extremes','modes','S12_isolation')},indent=0,default=str)[:5200]); print(len(res['claim_hits']),'claim-term hits')
