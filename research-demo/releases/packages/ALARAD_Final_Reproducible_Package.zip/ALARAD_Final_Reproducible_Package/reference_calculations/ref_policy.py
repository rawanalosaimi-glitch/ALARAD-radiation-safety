"""Independent verification of the immediate-alert before/after comparison (20 seeds, K in {1,3,5}) - recomputed from raw per-minute rates; compared with SafetyLab.policyCompare()."""
import subprocess,time,json,sys
from playwright.sync_api import sync_playwright
HTML_DIR,OUT=sys.argv[1:3]; GR=2
srv=subprocess.Popen(['python3','-m','http.server','8877','-d',HTML_DIR],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL); time.sleep(1)
with sync_playwright() as p:
    b=p.chromium.launch(args=['--no-sandbox']); pg=b.new_page(); pg.goto('http://localhost:8877/alarad_prototype.html'); pg.wait_for_timeout(600); E=pg.evaluate
    cmp=E("SafetyLab.policyCompare()")
    raw={}
    for sid in ['S3','S5','S6']:
        raw[sid]=E("""(sid)=>{const o=[];for(let off=0;off<20;off++){const r=SimLab.runQuiet(sid,1,off,{immediate:'off'});o.push(r.workers.map(w=>({b:w.baseline,rate:w.rows.map(x=>x.valid?x.engineRate:null),truth:w.rows.map(x=>!!x.truth)})));}return o}""",sid)
    for sid in ['S3H','S8']:
        raw[sid]=E("""(sid)=>{const sc=sid==='S3H'?SafetyLab.S3H:SafetyLab.SC[1];const o=[];for(let off=0;off<20;off++){const r=SafetyLab.runScenario(sc,1,off,{mode:'off'});o.push(r.workers.map(w=>({b:w.baseline,rate:w.rows.map(x=>x.usable?x.rate:null),truth:w.rows.map(x=>!!x.truthRad)})));}return o}""",sid)
    b.close()
srv.terminate()
def runs_of(bits):
    out=[];i=0
    while i<len(bits):
        if bits[i]:
            j=i
            while j+1<len(bits) and bits[j+1]: j+=1
            out.append((i,j));i=j+1
        else:i+=1
    return out
def sim(w,K,pol):
    b=w['b'];rt=w['rate'];fl=[];im=[]
    for r in rt:
        if r is None: fl.append(False);im.append(False);continue
        dev=(r-b)/b;dose=r*30/60/1000
        fl.append(not(dev<0.5 and dose<0.15)); im.append(pol and dose>=0.35)
    dets=[]
    for (i,j) in runs_of(fl):
        det=i+K-1 if (j-i+1)>=K else None
        ii=[t for t in range(i,j+1) if im[t]]
        if ii: det=min(det,ii[0]) if det is not None else ii[0]
        if det is not None: dets.append(det)
    ev=[(i,j+1) for i,j in runs_of(w['truth'])]; used=set();m=[]
    for on,off in ev:
        pick=None
        for k,a in enumerate(dets):
            if k not in used and on<=a<=off+GR: pick=k;break
        if pick is None:m.append(None)
        else:used.add(pick);m.append(dets[pick])
    for k,a in enumerate(dets):
        if k in used: continue
        for (on,off),mm in zip(ev,m):
            if mm is not None and on<=a<=off+GR: used.add(k);break
    return sum(x is not None for x in m),len(dets)-len(used),sum(x is None for x in m),[x-e[0] for x,e in zip(m,ev) if x is not None]
rows=[];bad=0
for c in cmp:
    sid,K=c['id'],c['K']
    for pol,key in ((False,'off'),(True,'on')):
        TP=FP=FN=0;lat=[]
        for ws in raw[sid]:
            for w in ws:
                a=sim(w,K,pol);TP+=a[0];FP+=a[1];FN+=a[2];lat+=a[3]
        L=sum(lat)/len(lat) if lat else None; app=c[key]
        ok=(TP,FP,FN)==(app['TP'],app['FP'],app['FN']) and ((L is None and app['lat'] is None) or (L is not None and app['lat'] is not None and abs(L-app['lat'])<1e-9))
        bad+=0 if ok else 1
        rows.append({'scenario':sid,'K':K,'policy':key,'mine':[TP,FP,FN,L],'app':[app['TP'],app['FP'],app['FN'],app['lat']],'match':ok})
        print('PASS' if ok else 'FAIL',sid,'K',K,key,'mine TP/FP/FN/lat',TP,FP,FN,L,'| app',app['TP'],app['FP'],app['FN'],app['lat'])
json.dump({'rows':rows,'mismatches':bad},open(OUT+'/ref_policy_results.json','w'),indent=1)
print('mismatches',bad,'of',len(rows))
