"""Independent recomputation of the sensitivity sweep. Raw per-minute engine rates (inputs) are taken from the app; flagging, alert episodes (confirmation window + immediate criterion),
event matching, TP/FP/FN/TN and latency are recomputed here for ALL 8,640 runs and compared with the Phase-2 packaged sweep_runs.csv; the 432-cell pooled grid is re-aggregated
from the run-level rows and compared with sweep_grid.csv; finally the full sweep is re-executed in the browser and compared byte-for-byte."""
import subprocess,time,json,sys,csv,io,hashlib
from playwright.sync_api import sync_playwright
HTML_DIR,P2,OUT=sys.argv[1:4]
GR=2;WIN=10;STEPS=60
runs=list(csv.DictReader(open(P2+'/sweep_runs.csv'))); grid=list(csv.DictReader(open(P2+'/sweep_grid.csv')))
sids=sorted(set(r['scenario'] for r in runs)); print('scenarios',sids,len(runs),'runs',len(grid),'cells')
srv=subprocess.Popen(['python3','-m','http.server','8875','-d',HTML_DIR],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL); time.sleep(1)
NZ={'U5':('uniform',0.05),'G5':('gaussian',0.05),'G10':('gaussian',0.10),'G20':('gaussian',0.20)}
data={}
with sync_playwright() as p:
    b=p.chromium.launch(args=['--no-sandbox']); pg=b.new_page(); pg.goto('http://localhost:8875/alarad_prototype.html'); pg.wait_for_timeout(600); E=pg.evaluate
    for sid in sids:
        for nid,(m,l) in NZ.items():
            data[(sid,nid)]=E("""([sid,m,l])=>{const o=[];for(let off=0;off<20;off++){const r=SimLab.runQuiet(sid,1,off,{noiseModel:m,noiseLevel:l,immediate:'off'});
              o.push(r.workers.map(w=>({b:w.baseline,rate:w.rows.map(x=>x.valid?x.engineRate:null),truth:w.rows.map(x=>x.truth)})));}return o}""",[sid,m,l])
    # full sweep re-execution
    t0=time.time(); E('SimLab.runSweep()')
    pg.wait_for_function("SimLab.sweepState&&SimLab.sweepState()&&SimLab.sweepState().cells&&SimLab.sweepState().cells.length>=432",timeout=280000)
    g2=E("SimLab.sweepCsv()"); r2=E("SimLab.sweepRunsCsv()"); print('sweep rerun s',round(time.time()-t0,1))
    b.close()
srv.terminate()
def runs_of(bits):
    out=[];i=0
    while i<len(bits):
        if bits[i]:
            j=i
            while j+1<len(bits) and bits[j+1]: j+=1
            out.append((i,j));i=j+1
        else:i+=1
    return out
def sim(w,de,K):
    b=w['b'];rt=w['rate']
    flagged=[];imm=[]
    for r in rt:
        if r is None: flagged.append(False);imm.append(False);continue
        dev=(r-b)/b; dose=r*30/60/1000
        flagged.append(not(dev<de and dose<0.15)); imm.append(dose>=0.35)
    eps=[];alert=[False]*STEPS
    for (i,j) in runs_of(flagged):
        det=i+K-1 if (j-i+1)>=K else None
        ii=[t for t in range(i,j+1) if imm[t]]
        if ii: det=min(det,ii[0]) if det is not None else ii[0]
        if det is not None:
            eps.append((det,j))
            for t in range(det,j+1): alert[t]=True
    ev=[]; tr=w['truth']
    for (i,j) in runs_of(tr): ev.append((i,j+1))
    used=set();m=[]
    dets=sorted(e[0] for e in eps)
    for (on,off) in ev:
        pick=None
        for k,a in enumerate(dets):
            if k in used: continue
            if on<=a<=off+GR: pick=k;break
        if pick is None:m.append(None)
        else: used.add(pick);m.append(dets[pick])
    for k,a in enumerate(dets):
        if k in used: continue
        for (on,off),mm in zip(ev,m):
            if mm is not None and on<=a<=off+GR: used.add(k);break
    TP=sum(x is not None for x in m);FN=len(ev)-TP;FP=len(dets)-len(used)
    TN=0
    for k in range(STEPS//WIN):
        a0,a1=k*WIN,k*WIN+WIN
        if not any(a0<off+GR and a1>on for (on,off) in ev):
            if not any(alert[a0:a1]): TN+=1
    lat=[x-e[0] for x,e in zip(m,ev) if x is not None]
    return dict(ev=len(ev),TP=TP,FP=FP,FN=FN,TN=TN,lat=lat)
mis=[];n=0
for r in runs:
    sid,de,K,nid,off=r['scenario'],float(r['dev_elevated']),int(r['confirmation_min']),r['noise_id'],int(r['seed_offset'])
    ws=data[(sid,nid)][off]; tot=dict(ev=0,TP=0,FP=0,FN=0,TN=0,lat=[])
    for w in ws:
        o=sim(w,de,K)
        for k in ('ev','TP','FP','FN','TN'): tot[k]+=o[k]
        tot['lat']+=o['lat']
    n+=1
    exp=(int(r['ground_truth_events']),int(r['TP']),int(r['FP']),int(r['FN']),int(r['TN']))
    got=(tot['ev'],tot['TP'],tot['FP'],tot['FN'],tot['TN'])
    lat_ok=(r['mean_latency_min']=='' and not tot['lat']) or (r['mean_latency_min']!='' and tot['lat'] and abs(float(r['mean_latency_min'])-sum(tot['lat'])/len(tot['lat']))<0.0006)
    if exp!=got or not lat_ok: mis.append((sid,de,K,nid,off,exp,got,r['mean_latency_min'],tot['lat']))
print('run-level mismatches:',len(mis),'of',n); print(mis[:5])
# re-aggregate grid
from collections import defaultdict
agg=defaultdict(lambda:[0,0,0,0,0,0,0])
for r in runs:
    k=(r['scenario'],r['dev_elevated'],r['confirmation_min'],r['noise_id'])
    a=agg[k]; a[0]+=int(r['ground_truth_events']);a[1]+=int(r['TP']);a[2]+=int(r['FP']);a[3]+=int(r['FN']);a[4]+=int(r['TN']);a[5]+=1
gm=0
for g in grid:
    k=(g['scenario'],g['dev_elevated'],g['confirmation_min'],g['noise_id']); a=agg[k]
    if (a[0],a[1],a[2],a[3],a[4])!=(int(g['ground_truth_events']),int(g['TP']),int(g['FP']),int(g['FN']),int(g['TN'])) or a[5]!=int(g['seeds']): gm+=1
    TP,FP,FN=a[1],a[2],a[3]
    pr=TP/(TP+FP) if TP+FP else None; rc=TP/(TP+FN) if TP+FN else None
    if (g['pooled_precision']=='')!=(pr is None) or (pr is not None and abs(float(g['pooled_precision'])-pr)>6e-5): gm+=1
    if (g['pooled_recall']=='')!=(rc is None) or (rc is not None and abs(float(g['pooled_recall'])-rc)>6e-5): gm+=1
print('grid-cell mismatches (re-aggregation of run-level rows):',gm,'of',len(grid))
same_g=(g2==open(P2+'/sweep_grid.csv',encoding='utf-8').read()); same_r=(r2==open(P2+'/sweep_runs.csv',encoding='utf-8').read())
print('full sweep re-run byte-identical to Phase-2 sweep_grid.csv:',same_g,'| sweep_runs.csv:',same_r)
open(OUT+'/regen_sweep_grid.csv','w').write(g2); open(OUT+'/regen_sweep_runs.csv','w').write(r2)
# headline pooled numbers by level (documented in Phase-2 report)
lv=defaultdict(lambda:[0,0,0])
for r in runs:
    for key,val in (('thr',r['dev_elevated']),('K',r['confirmation_min']),('noise',r['noise_id'])):
        a=lv[(key,val)];a[0]+=int(r['TP']);a[1]+=int(r['FP']);a[2]+=int(r['FN'])
out=[{'level':f'{k[0]}={k[1]}','TP':v[0],'FP':v[1],'FN':v[2],'precision':round(v[0]/(v[0]+v[1]),4) if v[0]+v[1] else None,'recall':round(v[0]/(v[0]+v[2]),4) if v[0]+v[2] else None} for k,v in sorted(lv.items())]
json.dump({'run_mismatches':len(mis),'runs':n,'grid_mismatches':gm,'cells':len(grid),'rerun_grid_identical':same_g,'rerun_runs_identical':same_r,'levels':out,'mismatch_examples':mis[:20]},open(OUT+'/ref_sweep_results.json','w'),indent=1)
print(json.dumps(out)[:1500])
