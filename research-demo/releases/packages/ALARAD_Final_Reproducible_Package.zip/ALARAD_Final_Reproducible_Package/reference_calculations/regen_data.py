"""Regenerate the Phase-3 data files (S7-S13 steps/summary CSV, safety report, before/after comparison JSON) from a given build.
Usage: python3 regen_data.py <dir containing alarad_prototype.html> <output dir>
Method check: run on the untouched Phase-3 build it must reproduce the Phase-3 package data/ byte-for-byte."""
import subprocess,time,json,sys,os
from playwright.sync_api import sync_playwright
D,OUT=sys.argv[1:3]; os.makedirs(OUT,exist_ok=True)
srv=subprocess.Popen(['python3','-m','http.server','8895','-d',D],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL); time.sleep(1)
try:
  with sync_playwright() as p:
    b=p.chromium.launch(args=['--no-sandbox']); pg=b.new_page(); pg.goto('http://localhost:8895/alarad_prototype.html'); pg.wait_for_timeout(600); E=pg.evaluate
    d=E("(()=>{SafetyLab.reset();SafetyLab.runAll();return {steps:SafetyLab.stepsCsv(),sum:SafetyLab.summaryCsv(),rep:SafetyLab.reportMd(),pol:SafetyLab.policyCompare(),val:SafetyLab.validationCompare()}})()")
    open(OUT+'/safety_steps.csv','w',encoding='utf-8',newline='').write(d['steps']); open(OUT+'/safety_summary.csv','w',encoding='utf-8',newline='').write(d['sum'])
    open(OUT+'/safety_report.md','w',encoding='utf-8',newline='').write(d['rep'])
    json.dump({'pol':d['pol'],'val':d['val']},open(OUT+'/cmp.json','w'),indent=1)
    b.close()
finally: srv.terminate()
print('written',OUT)
