"""Cross-build regression: the REAL Phase-2 engine (unmodified Phase-2 HTML) vs the Phase-3 engine.
(1) 10 invalid-input cases: actual Phase-2 behaviour vs claimed 'before' and Phase-3 'after'. (2) 4,000 random VALID inputs: outputs must be identical."""
import subprocess,time,json,random,sys
from playwright.sync_api import sync_playwright
P2,P3,OUT=sys.argv[1:4]
s1=subprocess.Popen(['python3','-m','http.server','8893','-d',P2],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
s2=subprocess.Popen(['python3','-m','http.server','8894','-d',P3],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL); time.sleep(1)
cases=[('Rate NaN',{'rate':'NaN'}),('Rate Infinity',{'rate':'Infinity'}),('Rate -50',{'rate':-50}),('Rate null',{'rate':None}),('Rate "abc"',{'rate':'abc'}),('Area refDist 0',{'mode':'area','refDist':0}),('Area shield -1',{'mode':'area','shield':-1}),('procMult 0',{'procMult':0}),('Unknown room',{'room':'Nowhere'}),('Mode "badge"',{'mode':'badge'})]
JS="""(ch)=>{const base={room:'Cath Lab 1',procMult:1,rate:100,dur:30,dist:2,refDist:1,shield:1,mode:'personal'};const a=Object.assign({},base,ch);if(a.rate==='NaN')a.rate=NaN;if(a.rate==='Infinity')a.rate=Infinity;let e;try{e=evaluateExposure(a)}catch(x){return ['EXC',String(x).slice(0,60)]}return [e.riskClass,e.invalid===true,Number.isFinite(e.cumulativeDose)?e.cumulativeDose:null,e.baseline]}"""
rows=[];out={}
with sync_playwright() as p:
    b=p.chromium.launch(args=['--no-sandbox'])
    pg2=b.new_page(); pg2.goto('http://localhost:8893/ALARAD_Prototype_Validation.html'); pg2.wait_for_timeout(600)
    pg3=b.new_page(); pg3.goto('http://localhost:8894/alarad_prototype.html'); pg3.wait_for_timeout(600)
    for nm,ch in cases:
        a=pg2.evaluate(JS,ch); c=pg3.evaluate(JS,ch); rows.append({'case':nm,'phase2_actual':a,'phase3_actual':c}); print(f'{nm:16s} Phase-2 {a} | Phase-3 {c}')
    random.seed(20261104); rooms=list(pg3.evaluate("baselineRates").keys()); batch=[]
    for _ in range(3000): batch.append({'mode':'personal','room':random.choice(rooms),'procMult':random.choice([0.5,0.7,1,1.2,1.4,1.8,2,3,10]),'rate':random.choice([random.uniform(0,1000),random.uniform(0,150),random.uniform(0,1e5)]),'dur':random.choice([1,5,15,20,30,45,60,480,1440])})
    for _ in range(1000): batch.append({'mode':'area','room':random.choice(rooms),'procMult':random.choice([1,1.4,2]),'rate':random.uniform(1,3000),'dur':random.choice([15,30,60]),'dist':random.uniform(0.2,50),'refDist':random.uniform(0.2,50),'shield':random.choice([1,0.4,0.15,random.uniform(0.01,1)])})
    J2="""(bt)=>bt.map(a=>{const e=evaluateExposure(a);return [e.riskClass,e.riskLabel,e.workerRate,e.cumulativeDose,e.deviation,e.baseline,e.kind,e.correction,JSON.stringify(e.series),JSON.stringify(e.fc),JSON.stringify(e.factors)]})"""
    r2=pg2.evaluate(J2,batch); r3=pg3.evaluate(J2,batch)
    diff=[i for i,(x,y) in enumerate(zip(r2,r3)) if json.dumps(x)!=json.dumps(y)]
    print('random VALID inputs compared:',len(batch),'| differing outputs between the real Phase-2 engine and the Phase-3 engine:',len(diff))
    out={'invalid_cases':rows,'valid_compared':len(batch),'valid_differences':len(diff),'diff_examples':[batch[i] for i in diff[:5]]}
    b.close()
s1.terminate();s2.terminate()
json.dump(out,open(OUT,'w'),indent=1)
