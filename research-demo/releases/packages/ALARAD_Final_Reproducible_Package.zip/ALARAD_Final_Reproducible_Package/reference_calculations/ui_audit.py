"""Browser/UI audit of the UNMODIFIED Phase-3 HTML (Chromium, clean context per viewport). Writes screenshots and ui_audit_results.json."""
import subprocess,time,json,sys,re
from playwright.sync_api import sync_playwright
HTML_DIR,SHOT,OUT=sys.argv[1:4]
srv=subprocess.Popen(['python3','-m','http.server','8879','-d',HTML_DIR],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL); time.sleep(1)
URL='http://localhost:8879/alarad_prototype.html'
R=[];ERR=[];FONTFAIL=[]
def C(area,name,ok,detail=''):
    R.append({'area':area,'check':name,'result':'PASS' if ok else 'FAIL','detail':str(detail)[:600]}); print('PASS' if ok else 'FAIL','|',area,'|',name,'|',str(detail)[:300])
def INFO(area,name,detail): R.append({'area':area,'check':name,'result':'INFO','detail':str(detail)[:900]}); print('INFO |',area,'|',name,'|',str(detail)[:300])
VIEWS=['dashboard','staff','alerts','airec','exposure','anomaly','wearable','security','emergency','askai','policy','livedemo','simlab']
VP={'desktop 1440x900':(1440,900),'tablet 768x1024':(768,1024),'mobile 390x844':(390,844)}
def newpage(b,w,h):
    ctx=b.new_context(viewport={'width':w,'height':h},device_scale_factor=1,accept_downloads=True); pg=ctx.new_page()
    pg.on('pageerror',lambda e:ERR.append('pageerror:'+str(e)[:200])); pg.on('console',lambda m:ERR.append('console.'+m.type+':'+m.text[:200]) if (m.type=='error' and 'ERR_TUNNEL' not in m.text and 'fonts.g' not in m.text) else None)
    pg.on('dialog',lambda d:(ERR.append('dialog:'+d.message[:100]),d.dismiss()))
    pg.on('requestfailed',lambda r:(FONTFAIL.append(r.url[:100]) if 'fonts.g' in r.url else ERR.append('requestfailed:'+r.url[:120])))
    pg.goto(URL); pg.wait_for_timeout(700); return ctx,pg
def goview(pg,v,mobile=False):
    try: pg.click(f'.nav-item[data-view="{v}"]',timeout=2500); return 'click'
    except Exception: pg.evaluate("v=>showView(v)",v); return 'showView() fallback (nav item not clickable)'
try:
 with sync_playwright() as p:
  b=p.chromium.launch(args=['--no-sandbox'])
  # ======= 1. every view x three viewports =======
  for vn,(w,h) in VP.items():
      ctx,pg=newpage(b,w,h); E=pg.evaluate; ERR.clear()
      nav_note=set()
      for v in VIEWS:
          how=goview(pg,v); pg.wait_for_timeout(250)
          if how!='click': nav_note.add(v)
          vis=E("v=>{const e=document.getElementById('view-'+v)||document.querySelector('.view.active');return !!e&&e.offsetParent!==null}",v)
          ov=E("document.documentElement.scrollWidth-window.innerWidth")
          C('views '+vn,f'{v}: renders, no horizontal page overflow (overflow {ov}px)',vis and ov<=2,f'visible={vis} overflow={ov}')
      C('views '+vn,'no JS errors / console errors / dialogs / failed requests while visiting all 13 views',len(ERR)==0,ERR[:4])
      if nav_note: INFO('views '+vn,'navigation items not directly clickable at this width (fallback used)',sorted(nav_note))
      # clipped controls / overlapping: elements wider than viewport
      wide=E("[...document.querySelectorAll('button,select,input,.card,table')].filter(e=>e.offsetParent!==null&&e.getBoundingClientRect().right>window.innerWidth+2&&!e.closest('.sl-tw,.tbl-wrap,[style*=overflow]')).map(e=>(e.id||e.className||e.tagName).toString().slice(0,30)).slice(0,8)")
      C('views '+vn,'no control/card extends beyond the viewport outside a scroll wrapper',len(wide)==0,wide)
      ctx.close()
  # ======= 2. functional flows on desktop =======
  ctx,pg=newpage(b,1440,900); E=pg.evaluate; ERR.clear()
  pg.screenshot(path=SHOT+'/01_normal_monitoring_dashboard.png')
  goview(pg,'staff'); pg.wait_for_timeout(300); pg.screenshot(path=SHOT+'/02_staff_monitor.png')
  # ---- every visible enabled button on each view: click, require no JS error; flag buttons with no observable effect
  noeff=[]
  for v in VIEWS:
      if v in ('livedemo',): continue
      ctx2,pg2=newpage(b,1440,900); goview(pg2,v); pg2.wait_for_timeout(250)
      ids=pg2.evaluate("[...document.querySelectorAll('.view.active button, #view-'+'%s'+' button')].filter(e=>e.offsetParent!==null&&!e.disabled).map((e,i)=>{e.setAttribute('data-aud',i);return [i,(e.textContent||'').trim().slice(0,40),e.getAttribute('onclick')||'']})"%v)
      seen=set()
      for i,txt,oc in ids:
          if (txt,oc) in seen: continue
          seen.add((txt,oc))
          if 'download' in oc.lower() or 'Download' in txt: continue
          okt=pg2.evaluate("""k=>{document.querySelectorAll('[data-aud2]').forEach(e=>e.removeAttribute('data-aud2'));const b=[...document.querySelectorAll('button')].find(e=>e.offsetParent!==null&&!e.disabled&&(e.textContent||'').trim().slice(0,40)===k[0]&&(e.getAttribute('onclick')||'')===k[1]);if(!b)return false;b.setAttribute('data-aud2','1');b.scrollIntoView({block:'center'});return true}""",[txt,oc])
          if not okt: continue
          before=pg2.evaluate("document.body.innerHTML.length+'|'+(document.querySelector('.view.active')||document.body).innerText.length")
          try: pg2.click('[data-aud2="1"]',timeout=4000)
          except Exception as e: noeff.append((v,txt,'click failed: '+str(e)[:60])); continue
          pg2.wait_for_timeout(300)
          after=pg2.evaluate("document.body.innerHTML.length+'|'+(document.querySelector('.view.active')||document.body).innerText.length")
          if before==after and not oc: noeff.append((v,txt,'no onclick attribute and no DOM change'))
      ctx2.close()
  C('controls','clicking every distinct visible button on 12 non-demo views produced no JS error',len(ERR)==0,ERR[:4])
  INFO('controls','buttons with no observable effect (for manual review, not auto-defects)',noeff[:20])
  # ---- Anomaly page: invalid inputs
  goview(pg,'anomaly'); pg.wait_for_timeout(200)
  def anomaly(vals):
      for k,v in vals.items(): pg.fill('#'+k,str(v)) if pg.query_selector('#'+k).evaluate("e=>e.tagName")=='INPUT' else pg.select_option('#'+k,str(v))
      pg.click('text=Recalculate Model'); pg.wait_for_timeout(250)
      return pg.evaluate("[document.getElementById('anErr')?document.getElementById('anErr').innerText:'',document.getElementById('anResult')?document.getElementById('anResult').innerText:'']") if False else pg.evaluate("document.getElementById('view-anomaly').innerText")
  base={'inMode':'personal','inRate':180,'inDur':45}
  t=anomaly(base); C('anomaly','valid personal input produces a result labelled MEASURED (not modeled)',('MEASURED' in t.upper()),re.findall(r'.{0,30}MEASURED.{0,30}',t.upper())[:1])
  t=anomaly({'inMode':'area','inRate':180,'inDur':45,'inRefDist':1,'inDist':2}); C('anomaly','area-monitor input produces a result labelled MODELED estimate',('MODELED' in t.upper() or 'MODELLED' in t.upper()),re.findall(r'.{0,30}MODEL.{0,30}',t.upper())[:1])
  for nm,vals in [('empty rate',{'inMode':'personal','inRate':'','inDur':45}),('negative rate',{'inMode':'personal','inRate':-5,'inDur':45}),('zero duration',{'inMode':'personal','inRate':180,'inDur':0}),('area distance 0',{'inMode':'area','inRate':180,'inDur':45,'inRefDist':1,'inDist':0}),('rate above UI max',{'inMode':'personal','inRate':100001,'inDur':45})]:
      t=anomaly(vals); bad=('LOW RISK' in t.upper() or 'CRITICAL' in t.upper() or 'ELEVATED RISK' in t.upper()) and not ('INVALID' in t.upper() or 'REJECT' in t.upper() or 'MUST' in t.upper() or 'ENTER' in t.upper())
      C('anomaly',f'invalid input "{nm}" is rejected with a message and shows no risk class',not bad,t[-260:].replace('\n',' | '))
  anomaly(base)
  b.close() if False else None
  # ======= 3. Live Demo: radiation incident, disconnect during incident, frozen =======
  ERR.clear(); goview(pg,'livedemo'); pg.wait_for_timeout(300)
  pg.click('#ldStartBtn'); pg.wait_for_timeout(500)
  pg.wait_for_timeout(8700)
  pg.screenshot(path=SHOT+'/03_live_demo_radiation_incident.png')
  st1=E("({alerts:alerts.filter(a=>!a.resolved).map(a=>[a.id,a.level,a.category||null,a.dq||false,a.demo||false]),health:document.getElementById('ldHealth').textContent,now:document.getElementById('ldNow').innerText.slice(0,200)})")
  INFO('live demo','state after ~11 s of manual demo (before fault)',json.dumps(st1))
  rad=[a for a in E("alerts.filter(a=>!a.resolved&&!a.dq).map(a=>({id:a.id,level:a.level,demo:!!a.demo}))")]
  C('live demo','a radiation (non-DQ) alert is open after the injected exposure rise',len(rad)>=1,json.dumps(rad))
  E("demoWorkerLeaves()"); E("document.getElementById('ldFaultSel').value='disconnect'"); E("demoInjectFault()")   # HARNESS ADAPTATION (final candidate): acknowledge first - the stream is paused (faults blocked, M-04) until the worker leaves
  pg.wait_for_timeout(3300)
  pg.screenshot(path=SHOT+'/04_disconnect_during_active_incident_unknown_state.png')
  S=E("""({open:alerts.filter(a=>!a.resolved).map(a=>({id:a.id,dq:!!a.dq,cat:a.category||null,lvl:a.level})),all:alerts.length,
      health:document.getElementById('ldHealth').innerText,now:document.getElementById('ldNow').innerText,unkBars:document.querySelectorAll('.ld-bar.unk').length,
      view:document.getElementById('view-livedemo').innerText,sensor:DEMO.sensor&&DEMO.sensor.state,rates:DEMO.readings.slice(-8).map(r=>r.rate)})""")
  txt=S['view']
  C('incident+outage','radiation alert still OPEN (not resolved/removed) while sensor is disconnected',any(not x['dq'] for x in S['open']),json.dumps(S['open']))
  C('incident+outage','a separate DATA QUALITY alert exists',any(x['dq'] for x in S['open']),json.dumps(S['open']))
  C('incident+outage','UI states UNKNOWN — MONITORING UNAVAILABLE',('UNKNOWN' in txt.upper() and 'UNAVAILABLE' in txt.upper()),re.findall(r'.{40}UNAVAILABLE.{20}',txt,flags=re.S)[:1])
  C('incident+outage','hatched "no valid reading" bars shown for unavailable minutes (unknown, not zero)',S['unkBars']>=3,S['unkBars'])
  C('incident+outage','last valid reading is labelled HISTORICAL',('HISTORICAL' in txt.upper()),re.findall(r'.{60}HISTORICAL.{40}',txt,flags=re.S)[:1])
  C('incident+outage','the word SAFE (whole word) never appears as a status',re.search(r'\bSAFE\b',txt) is None,re.findall(r'.{20}\bSAFE\b.{20}',txt)[:2])
  C('incident+outage','missing minutes are not displayed as 0 µSv/h',not re.search(r'(?<!slope )(?<![\d.])0 µSv/h',txt) and all(r is None for r in S['rates'][-3:]),S['rates'])
  slope=re.findall(r'regression slope [^\n]*',txt)
  C('incident+outage','trend row shows no numeric slope (e.g. 0.0) while data are unavailable',not any(re.search(r'slope\s+-?\d',x) for x in slope),slope)
  goview(pg,'alerts'); pg.wait_for_timeout(300); at=E("document.getElementById('view-alerts').innerText")
  pg.screenshot(path=SHOT+'/05_alerts_page_simultaneous_incidents.png')
  C('incident+outage','Alerts page shows both categories (RADIATION and DATA QUALITY labels)',('DATA QUALITY' in at.upper() and ('RADIATION' in at.upper())),re.findall(r'.{0,30}DATA QUALITY.{0,30}',at.upper())[:1])
  # ---- RSO lifecycle on the DQ alert via real UI functions
  ids=E("alerts.filter(a=>!a.resolved).map(a=>({id:a.id,dq:!!a.dq}))"); dq=[x for x in ids if x['dq']][0]['id']; rd=[x for x in ids if not x['dq']][0]['id']
  r1=E("(id)=>{resolveAlert(id,'Sensor reconnected and data verified','');return alerts.find(a=>a.id===id).resolved===true}",dq)
  C('lifecycle','DQ alert cannot be resolved as "Sensor reconnected and data verified" while sensor is still disconnected',r1 is False,r1)
  r2=E("(id)=>{resolveAlert(id,'Equipment issue corrected','');return alerts.find(a=>a.id===id).resolved===true}",rd)
  C('lifecycle','radiation alert cannot be resolved without acknowledgement + action (OPEN → ACK → ACTION → RESOLVED enforced)',r2 is False,r2)
  E("(id)=>ackAlert(id)",rd); E("(id)=>addActionTo(id,'Worker removed from the room')",rd)
  pg.wait_for_timeout(100)
  r3=E("(id)=>{resolveAlert(id,'',''); return alerts.find(a=>a.id===id).resolved===true}",rd)
  C('lifecycle','resolution without a documented reason is refused',r3 is False,r3)
  INFO('lifecycle','Live Demo scripted stream ends after 14 simulated minutes when the worker acknowledges; the incident+outage flow therefore ends in a non-recovered state (recovery is exercised in the next flow)',E("[DEMO.sensor.state,DEMO.idx,DEMO.script.length,!!DEMO.timer]"))
  E("(id)=>resolveAlert(id,'Procedure-related exposure','audit')",rd)
  r6=E("(id)=>{const a=alerts.find(x=>x.id===id);return [a.resolved,a.resolution||a.reason||null]}",rd); INFO('lifecycle','radiation alert after valid ack+action+reason',json.dumps(r6))
  C('lifecycle','radiation alert resolves only through the explicit RSO path',r6[0] is True,r6)
  C('live demo','no JS errors during incident + outage + recovery + resolution',len(ERR)==0,ERR[:4])
  # ---- outage with NO incident: do the main RSO surfaces say UNKNOWN?
  ERR.clear(); E("resetLiveDemo(false)"); pg.wait_for_timeout(900); goview(pg,'livedemo'); pg.click('#ldStartBtn'); pg.wait_for_timeout(2300)
  E("document.getElementById('ldFaultSel').value='disconnect'"); E("demoInjectFault()"); pg.wait_for_timeout(6200)
  st=E("[DEMO.sensor.state,DEMO.unmon,JSON.stringify(staff.find(s=>s.id==='ST-02'))]"); INFO('outage-main-views','sensor state / unmonitored min / staff record',json.dumps(st))
  goview(pg,'staff'); pg.wait_for_timeout(300); pg.screenshot(path=SHOT+'/04c_staff_monitor_during_outage.png')
  row=E("[...document.querySelectorAll('#view-staff tr')].filter(r=>r.innerText.includes('ST-02')).map(r=>r.innerText.replace(/\\s+/g,' ')).join('|')")
  C('outage-main-views','Staff Monitor row for the disconnected worker states UNKNOWN / monitoring unavailable (not NORMAL)',bool(re.search(r'UNKNOWN|UNAVAILABLE|NO CURRENT DATA',row,re.I)) and not re.search(r'\bNORMAL\b',row),row)
  C('outage-main-views','Staff Monitor marks the dose as incomplete / unmonitored time',bool(re.search(r'incomplete|unmonitored',row,re.I)),row)
  goview(pg,'dashboard'); pg.wait_for_timeout(300); pg.screenshot(path=SHOT+'/04d_dashboard_during_outage.png')
  dt=E("document.getElementById('view-dashboard').innerText.replace(/\\s+/g,' ')+' '+[...document.querySelectorAll('#floorMap *, .floor-wrap *')].map(e=>e.getAttribute('title')||e.getAttribute('aria-label')||'').join(' ')")
  C('outage-main-views','Dashboard / floor map indicates the unavailable monitoring (UNKNOWN / unavailable) for the worker',bool(re.search(r'UNKNOWN|UNAVAILABLE|NO CURRENT DATA',dt,re.I)),'no mention' if not re.search(r'UNKNOWN|UNAVAILABLE',dt,re.I) else 'mentioned')
  goview(pg,'wearable'); pg.wait_for_timeout(300); wt=E("document.getElementById('view-wearable').innerText")
  C('outage-main-views','Wearable page shows NO CURRENT DATA for the disconnected device',('NO CURRENT DATA' in wt),'')
  goview(pg,'alerts'); pg.wait_for_timeout(300); alt=E("document.getElementById('view-alerts').innerText")
  C('outage-main-views','Alerts page shows a DATA QUALITY alert for the worker',bool(re.search(r'monitoring unavailable',alt,re.I)),'')
  C('outage-main-views','no JS errors',len(ERR)==0,ERR[:3])
  # ---- recovery flow (correct timing): short outage, reconnect, DQ alert lifecycle
  ERR.clear(); E("resetLiveDemo(false)"); pg.wait_for_timeout(900); goview(pg,'livedemo'); pg.click('#ldStartBtn'); pg.wait_for_timeout(2300)
  E("document.getElementById('ldFaultSel').value='disconnect'"); E("demoInjectFault()"); pg.wait_for_timeout(2300)
  s1=E("[DEMO.sensor.state,alerts.filter(a=>a.dq&&!a.resolved).map(a=>a.id)]"); INFO('recovery','after 2 missing minutes',json.dumps(s1))
  C('recovery','2+ missing minutes: sensor STALE and a DATA QUALITY alert is raised',s1[0] in('STALE','DISCONNECTED') and len(s1[1])==1,json.dumps(s1))
  dq2=s1[1][0] if s1[1] else None
  r_=E("(id)=>{resolveAlert(id,'Sensor reconnected and data verified','');return alerts.find(a=>a.id===id).resolved===true}",dq2) if dq2 else None
  C('recovery','DQ alert cannot be resolved as "reconnected" while the sensor is still unavailable',r_ is False,r_)
  E("demoClearFault()"); pg.wait_for_timeout(3200)
  s2=E("[DEMO.sensor.state,DEMO.idx,DEMO.script.length]"); C('recovery','after the link is restored the sensor passes RECOVERING and returns to HEALTHY',s2[0]=='HEALTHY',json.dumps(s2))
  if dq2:
      E("(id)=>{ackAlert(id);addActionTo(id,'Checked the dosimeter link')}",dq2)
      r_=E("(id)=>{resolveAlert(id,'Sensor reconnected and data verified','');return alerts.find(a=>a.id===id).resolved===true}",dq2)
      C('recovery','after reconnection, ack + action + reason lets the DQ alert resolve (OPEN→ACK→ACTION→RESOLVED)',r_ is True,r_)
  C('recovery','no JS errors',len(ERR)==0,ERR[:3])
  # ---- frozen fault
  ERR.clear(); goview(pg,'livedemo'); pg.click('#ldStartBtn'); pg.wait_for_timeout(2500)
  E("document.getElementById('ldFaultSel').value='frozen'"); E("demoInjectFault()")
  for i in range(10): pg.wait_for_timeout(1000)
  pg.screenshot(path=SHOT+'/06_live_demo_frozen_uncertain.png')
  vt=E("document.getElementById('view-livedemo').innerText"); hs=E("document.getElementById('ldHealth').innerText")
  C('frozen','repeated values show a DATA UNCERTAIN / suspected-frozen state, not a hardware-failure claim',('UNCERTAIN' in vt.upper() or 'FROZEN' in hs.upper()),hs)
  C('frozen','no whole-word SAFE displayed during the frozen state',re.search(r'\bSAFE\b',vt) is None)
  # ---- fault injected AFTER the scripted stream has ended
  E("resetLiveDemo(false)"); pg.wait_for_timeout(900); pg.click('#ldStartBtn'); pg.wait_for_timeout(11800)
  before=E("[DEMO.readings.length,!!DEMO.timer,DEMO.sensor&&DEMO.sensor.state,document.getElementById('ldHealth').innerText]")
  E("document.getElementById('ldFaultSel').value='disconnect'"); E("demoInjectFault()"); pg.wait_for_timeout(3500)
  after=E("[DEMO.readings.length,!!DEMO.timer,DEMO.sensor&&DEMO.sensor.state,document.getElementById('ldHealth').innerText,!!DEMO.fault,(document.getElementById('ldInjectBtn')?document.getElementById('ldInjectBtn').disabled:document.getElementById('ldFaultSel').disabled),document.getElementById('ldFaultBox').innerText.slice(0,160)]")   # HARNESS ADAPTATION: the candidate disables the Inject/Restore buttons (+note) instead of the select
  pg.screenshot(path=SHOT+'/06b_live_demo_fault_after_stream_end_inert.png')
  INFO('live demo','fault injected 12 s after start (scripted stream already finished): before / after',json.dumps([before,after]))
  C('live demo','fault control is not silently inert after the scripted stream has ended (state changes or the control is disabled/explained)',(after[2]!=before[2]) or after[5] is True,json.dumps([before,after]))
  # ---- rapid start/stop
  ERR.clear()
  for i in range(8):
      E("startLiveDemo()"); E("resetLiveDemo(false)")
  E("startLiveDemo()"); pg.wait_for_timeout(1500); E("startLiveDemo()"); pg.wait_for_timeout(1500)
  tm=E("[!!DEMO.timer,DEMO.idx,alerts.filter(a=>a.demo&&!a.resolved).length]")
  C('robustness','rapid start/reset x8 and double start: one timer, no JS errors, no duplicated demo alerts',len(ERR)==0 and tm[2]<=1,json.dumps([tm,ERR[:3]]))
  E("resetLiveDemo(false)"); 
  b.close() if False else None
  ctx.close()
  # ======= 4. Simulation Lab / Safety section =======
  ctx,pg=newpage(b,1440,900); E=pg.evaluate; ERR.clear(); goview(pg,'simlab'); pg.wait_for_timeout(400)
  snap0=E("JSON.stringify([typeof snapshotWorld==='function'?snapshotWorld():null])")
  E("SafetyLab.select('S8');SafetyLab.run('S8',1)"); pg.wait_for_timeout(300); E("SafetyLab.setMinute(30)"); pg.wait_for_timeout(300)
  pg.evaluate("document.getElementById('slSafetyCard').scrollIntoView()"); pg.screenshot(path=SHOT+'/07_lab_S8_disconnect_minute30_unknown_historical.png')
  insp=E("document.getElementById('ssDetail').innerText")
  C('lab S8','minute 30 inspector: UNKNOWN — MONITORING UNAVAILABLE, last valid reading HISTORICAL with its timestamp',('UNKNOWN' in insp.upper() and 'HISTORICAL' in insp.upper() and re.search(r'T\+\d+',insp) is not None),insp[:300].replace('\n',' | '))
  C('lab S8','no whole-word SAFE/NORMAL status at an unavailable minute',re.search(r'\b(SAFE|NORMAL)\b',insp.split('LAST VALID')[0] if 'LAST VALID' in insp else insp) is None,insp[:200].replace('\n',' | '))
  E("SafetyLab.select('S10');SafetyLab.run('S10',1)"); pg.wait_for_timeout(300); E("SafetyLab.setMinute(30)"); pg.wait_for_timeout(300)
  pg.evaluate("document.getElementById('slSafetyCard').scrollIntoView()"); pg.screenshot(path=SHOT+'/08_lab_S10_frozen_masked_event.png')
  i10=E("document.getElementById('ssDetail').innerText"); t10=E("document.getElementById('slSafetyCard').innerText")
  INFO('S10','minute-30 inspector text',i10.replace('\n',' | ')[:500])
  C('S10','frozen minute is labelled uncertain/repeated values in the inspector',('UNCERTAIN' in i10.upper() or 'FROZEN' in i10.upper() or 'REPEATED' in i10.upper()),i10[:200].replace('\n',' | '))
  E("SafetyLab.select('S13');SafetyLab.run('S13',1)"); pg.wait_for_timeout(300); E("SafetyLab.setMinute(28)"); pg.wait_for_timeout(300)
  pg.evaluate("document.getElementById('ssTbl')&&document.getElementById('ssTbl').scrollIntoView()"); pg.screenshot(path=SHOT+'/09_lab_S13_simultaneous_incidents.png')
  t13=E("document.getElementById('slSafetyCard').innerText")
  C('S13','radiation and data-quality incidents listed together',('RADIATION' in t13.upper() and 'DATA' in t13.upper()),'')
  # repeated runs, reset, state isolation
  E("SafetyLab.runAll()"); fp1=E("Object.keys(SafetyLab.results()).sort().map(k=>SafetyLab.results()[k].fingerprint).join(',')"); E("SafetyLab.reset()")
  emp=E("Object.keys(SafetyLab.results()).length"); E("SafetyLab.runAll()"); fp2=E("Object.keys(SafetyLab.results()).sort().map(k=>SafetyLab.results()[k].fingerprint).join(',')")
  C('lab','Run all → Reset → Run all: results cleared by reset and fingerprints identical (no retained state)',emp==0 and fp1==fp2,fp1[:80])
  E("SimLab.runAll()"); a=E("Object.keys(SimLab.results()).sort().map(k=>SimLab.results()[k].fingerprint).join(',')"); E("SimLab.reset()"); E("SimLab.runAll()"); b2=E("Object.keys(SimLab.results()).sort().map(k=>SimLab.results()[k].fingerprint).join(',')")
  C('lab','original six scenarios: run/reset/rerun fingerprints identical',a==b2 and len(a)>10,a[:80])
  # selection by real clicks
  ok=True
  for s in ['S7','S8','S9','S10','S11','S12','S13']:
      pg.evaluate("document.getElementById('slSafetyCard').scrollIntoView()")
      loc=pg.locator('#ssTabs button',has_text=re.compile('^\\s*'+s[1:]+'\\b'))
      try: loc.first.click(timeout=2000); pg.wait_for_timeout(120)
      except Exception as e: ok=False
  C('lab','scenario tabs S7–S13 selectable by real clicks',ok)
  C('lab','no JS errors in the Lab flows',len(ERR)==0,ERR[:4])
  # Lab results/metrics visible
  INFO('lab','Safety summary table text',E("document.getElementById('ssTable').innerText").replace('\n',' | ')[:700])
  ctx.close()
  # ======= 5. mobile evidence =======
  ctx,pg=newpage(b,390,844); E=pg.evaluate; goview(pg,'livedemo'); pg.wait_for_timeout(300); pg.screenshot(path=SHOT+'/10_mobile_live_demo.png')
  navok=E("(()=>{const n=document.querySelector('.nav-item[data-view=\"simlab\"]');const r=n.getBoundingClientRect();return [n.offsetParent!==null,Math.round(r.left),Math.round(r.right)]})()")
  INFO('mobile','nav item simlab visible/left/right',navok)
  goview(pg,'simlab'); E("SafetyLab.runAll();SafetyLab.compare();document.getElementById('slSafetyCard').scrollIntoView()"); pg.wait_for_timeout(300); pg.screenshot(path=SHOT+'/11_mobile_safety_lab.png')
  C('mobile','Safety lab at 390 px: no horizontal page overflow',E("document.documentElement.scrollWidth-window.innerWidth")<=2)
  ctx.close()
  b.close()
finally:
  srv.terminate()
json.dump(R,open(OUT,'w'),indent=1)
INFO('environment','Google Fonts requests blocked by the sandbox (external dependency: the page loads fonts from fonts.googleapis.com; system fallback fonts are used when offline)',sorted(set(FONTFAIL))[:3])
json.dump(R,open(OUT,'w'),indent=1)
print('TOTAL',sum(r['result']!='INFO' for r in R),'PASS',sum(r['result']=='PASS' for r in R),'FAIL',sum(r['result']=='FAIL' for r in R))
