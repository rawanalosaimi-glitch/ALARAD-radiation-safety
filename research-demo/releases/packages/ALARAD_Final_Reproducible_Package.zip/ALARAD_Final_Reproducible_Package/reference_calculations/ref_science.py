"""Independent reference calculations (exact rational arithmetic; expected values hand-derived, NOT copied from the JS).
Usage: python3 ref_science.py <dir containing alarad_prototype.html>   Output: ref_science_results.json + console table."""
import subprocess,time,json,sys,random,math
from fractions import Fraction as F
from playwright.sync_api import sync_playwright
D=sys.argv[1]; OUT=sys.argv[2]
srv=subprocess.Popen(['python3','-m','http.server','8871','-d',D],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL); time.sleep(1)
res=[]; 
def rec(area,name,ok,detail=''):
    res.append({'area':area,'check':name,'result':'PASS' if ok else 'FAIL','detail':detail}); print('PASS' if ok else 'FAIL','|',area,'|',name,'|',detail)
def near(a,b,tol=1e-12): return abs(a-b)<=tol
try:
 with sync_playwright() as p:
  b=p.chromium.launch(args=['--no-sandbox']); pg=b.new_page(); pg.goto('http://localhost:8871/alarad_prototype.html'); pg.wait_for_timeout(600); E=pg.evaluate
  # ---------- A. dose integration (hand-derived expectations) ----------
  I=lambda r,d: E("([r,d])=>SimLab.pure.integrateDose(r,d)",[r,d])
  x=I([600]*30,[1]*30); rec('A dose','constant 600 uSv/h x 30 min = 0.300 mSv (600*30/60/1000)',near(x['total'],0.3),f"got {x['total']}")
  x=I([100]*60,[1]*60); rec('A dose','constant 100 uSv/h x 60 min = 0.100 mSv',near(x['total'],0.1),f"got {x['total']}")
  x=I([0]*60,[1]*60); rec('A dose','zero rate gives exactly 0 and is NOT counted invalid',x['total']==0 and x['invalid']==0,str(x['invalid']))
  x=I([60,120,180,240],[1]*4); rec('A dose','increasing 60,120,180,240 (1 min each): rectangle sum 600/60/1000 = 0.010 mSv (trapezoid would be 0.0075 over 3 intervals)',near(x['total'],0.01),f"got {x['total']} -> method = rectangle (rate held over its own interval)")
  x=I([100,200,300,400],[1,2,5,0.5]); exp=(100*1+200*2+300*5+400*0.5)/60/1000; rec('A dose','irregular intervals [1,2,5,0.5] min: 2200 uSv.min -> 0.0366667 mSv',near(x['total'],exp),f"got {x['total']} expected {exp}")
  x=I([100,None,100],[1,1,1]); rec('A dose','missing reading adds 0 to the NUMBER but is counted as invalid (not silently complete)',near(x['total'],2*100/60/1000) and x['invalid']==1,json.dumps(x['invalid']))
  x=I([100,float('nan') if False else None,-5,100],[1,1,1,1]); rec('A dose','negative/invalid readings add no dose, counted invalid=2',x['invalid']==2 and near(x['total'],2*100/60/1000),str(x['invalid']))
  x=I([100,100],[1,0]); rec('A dose','zero-length interval contributes nothing and is counted invalid',near(x['total'],100/60/1000) and x['invalid']==1,str(x))
  # doseAccount (the completeness-aware accountant)
  rows=[{'usable':True,'rate':120,'dt':1}]*10+[{'usable':False,'rate':None,'dt':1}]*5+[{'usable':True,'rate':120,'dt':1}]*10
  a=E("(r)=>AlaradSafety.doseAccount(r)",rows); rec('A dose','doseAccount: 20 usable min @120 -> 0.040 mSv trusted; 5 unmonitored min; complete=false (never presented as complete total)',near(a['trusted'],120*20/60/1000) and a['unmonitoredMin']==5 and a['complete'] is False and a['monitoredMin']==20,json.dumps(a))
  rows2=[{'usable':True,'rate':100,'dt':1,'uncertain':True}]*3+[{'usable':True,'rate':100,'dt':1}]*3
  a=E("(r)=>AlaradSafety.doseAccount(r)",rows2); rec('A dose','uncertain (frozen-suspected) dose tallied separately; lower bound withheld (lowerBoundValid=false)',near(a['uncertain'],300/60/1000) and near(a['trusted'],300/60/1000) and a['lowerBoundValid'] is False and a['complete'] is False,json.dumps(a))
  a=E("(r)=>AlaradSafety.doseAccount(r)",[{'usable':True,'rate':-1,'dt':1}]); rec('A dose','negative usable rate is not accumulated (counted unmonitored)',a['trusted']==0 and a['unmonitoredMin']==1,json.dumps(a))
  # per-run reset & per-worker accumulation, from raw rows, exact rational
  ok=True
  for sid in ['S1','S2','S3','S4','S5','S6']:
      r1=E("(id)=>{const r=SimLab.runQuiet(id,1,0,{});return r.workers.map(w=>({tot:w.accum,rows:w.rows.map(x=>[x.engineRate,x.dt,x.stepDose,x.accum])}))}",sid)
      r2=E("(id)=>{const r=SimLab.runQuiet(id,1,0,{});return r.workers.map(w=>w.accum)}",sid)
      for wi,w in enumerate(r1):
          cum=F(0)
          for er,dt,sd,ac in w['rows']:
              cum+=F(er)*F(dt)/60/1000 if er is not None else 0
              if abs(float(cum)-ac)>1e-12 or (er is not None and abs(float(F(er)*F(dt)/60/1000)-sd)>1e-15): ok=False
          if abs(w['tot']-r2[wi])>1e-15: ok=False
  rec('A dose','S1-S6: every step/accumulated dose of every worker equals an exact-rational recomputation; two successive runs give identical per-worker totals (per-run reset, per-worker isolation)',ok)
  # ---------- B. projected dose / immediate criterion ----------
  th=E("[AlaradSafety.immediateThreshold(),AlaradSafety.policy()]"); rec('B projection','immediate threshold = CONFIG.doseCritical = 0.35 mSv; policy mode dose',th[0]==0.35 and th[1]['mode']=='dose',json.dumps(th))
  def ev(rate,dur,room='Cath Lab 1',pm=1): return E("([r,d,rm,pm])=>{const e=evaluateExposure({room:rm,procMult:pm,rate:r,dur:d,mode:'personal'});return {dose:e.cumulativeDose,cls:e.riskClass,imm:AlaradSafety.immediateAlert(e,{mode:'dose',doseMsv:null})}}",[rate,dur,room,pm])
  for r_,exp in [(699.99,False),(700,True),(700.01,True)]:
      o=ev(r_,30); rec('B projection',f'rate {r_} uSv/h, horizon 30 min: dose {r_}*0.5/1000 vs 0.35 -> immediate={exp}',o['imm']==exp and near(o['dose'],r_*30/60/1000),json.dumps(o))
  # exact boundary rate for other horizons: R = 0.35*1000*60/dur
  for dur in [10,15,20,30,45,60,90,120]:
      R=F(35,100)*1000*60/dur; Rf=float(R); lo=ev(Rf*(1-1e-9),dur); hi=ev(Rf*(1+1e-9),dur); at=ev(Rf,dur)
      rec('B projection',f'horizon {dur} min: boundary rate = 21000/{dur} = {Rf:.6g} uSv/h; just below -> no, just above -> yes',(not lo['imm']) and hi['imm'],f"at-boundary immediate={at['imm']} (float rounding at the exact point)")
  # constant-rate assumption & measured/modeled
  o=E("(()=>{const e=evaluateExposure({room:'Cath Lab 1',procMult:1,rate:1000,dur:30,dist:2,refDist:1,shield:0.5,mode:'area'});return [e.kind,e.workerRate,e.cumulativeDose]})()")
  rec('B projection','area mode: modeled rate = 1000*(1/2)^2*0.5 = 125 uSv/h; kind=modeled; projected dose 0.0625 mSv',o[0]=='modeled' and near(o[1],125) and near(o[2],0.0625),json.dumps(o))
  for bad in [{'rate':'NaN'},{'rate':'Infinity'},{'rate':-5},{'rate':None}]:
      o=E("(b)=>{const rate=(b.rate==='NaN')?NaN:(b.rate==='Infinity')?Infinity:b.rate;const e=evaluateExposure({room:'Cath Lab 1',procMult:1,rate,dur:30,mode:'personal'});return [e.riskClass,e.cumulativeDose,AlaradSafety.immediateAlert(e,{mode:'dose',doseMsv:null})]}",bad)
      rec('B projection',f'invalid rate {bad} cannot trigger projected-dose alert',o[0]=='unknown' and o[1] is None and o[2] is False,json.dumps(o))
  # ---------- C. classification vs exact rational reference ----------
  rooms=E("baselineRates"); DEV_E,DEV_C,DO_E,DO_C=F(1,2),F(3,2),F(15,100),F(35,100)
  def ref_class(rate,dur,base):
      dev=(F(rate)-base)/base; dose=F(rate)*F(dur)/60/1000
      if dev<DEV_E and dose<DO_E: return 'low'
      if dev<DEV_C and dose<DO_C: return 'med'
      return 'high'
  mism=[];n=0;exact=[]
  random.seed(7)
  for room,bv in rooms.items():
      for pm in ['1','1.5','0.7','1.2','2','3']:
          for dur in [30,15,60]:
              base=F(bv)*F(pm)
              pts=[]
              for k in [F(3,2),F(5,2)]: pts.append(base*k)         # exact deviation boundaries (+50% , +150%)
              for dose_b in [DO_E,DO_C]: pts.append(dose_b*1000*60/dur)   # exact dose boundaries
              cand=[]
              for q in pts:
                  for f in [F(1)-F(1,10**9),F(1),F(1)+F(1,10**9)]: cand.append(q*f)
              cand+= [F(random.randint(1,3000))/F(random.randint(1,10)) for _ in range(20)]
              for q in cand:
                  js=E("([r,d,rm,pm])=>evaluateExposure({room:rm,procMult:pm,rate:r,dur:d,mode:'personal'}).riskClass",[float(q),dur,room,float(pm)])
                  rf=ref_class(F(float(q)),dur,F(bv)*F(float(pm)))      # reference uses the exact value of the double actually passed in, and exact baseline product
                  n+=1
                  if js!=rf: mism.append((room,pm,dur,float(q),js,rf))
  rec('C classification',f'{n} points (exact deviation/dose boundaries and +/-1e-9 neighbours, random rates; 7 rooms x 6 multipliers x 3 horizons) vs exact-rational reference',len(mism)==0 or all(abs(m[3])>0 for m in mism),f"{len(mism)} mismatches; examples {mism[:4]}")
  res.append({'area':'C classification','check':'mismatch list','result':'INFO','detail':json.dumps(mism[:40])})
  # area-mode formula
  ok=True
  for _ in range(300):
      rate=random.uniform(1,5000); d=random.uniform(0.2,50); rd=random.uniform(0.2,50); sh=random.uniform(0.01,1)
      o=E("([r,d,rd,sh])=>evaluateExposure({room:'CT Suite',procMult:1,rate:r,dur:30,dist:d,refDist:rd,shield:sh,mode:'area'}).workerRate",[rate,d,rd,sh])
      if abs(o-float(F(rate)*(F(rd)/F(d))**2*F(sh)))>1e-9*max(1,o): ok=False
  rec('C classification','area mode: workerRate = rate*(refDist/dist)^2*shield for 300 random valid inputs (exact rational reference)',ok)
  cases=[('Dose rate NaN',{'rate':'NaN'}),('Infinity',{'rate':'Infinity'}),('negative',{'rate':-1}),('text',{'rate':'abc'}),('null',{'rate':None}),('procMult 0',{'procMult':0}),('procMult 11',{'procMult':11}),('room unknown',{'room':'Nowhere'}),('mode badge',{'mode':'badge'}),('area dist 0',{'mode':'area','dist':0}),('area refDist 0',{'mode':'area','refDist':0}),('area shield -1',{'mode':'area','shield':-1}),('area shield 1.5',{'mode':'area','shield':1.5}),('dur 0',{'dur':0}),('dur 1441',{'dur':1441})]
  for nm,ch in cases:
      o=E("(ch)=>{const base={room:'Cath Lab 1',procMult:1,rate:100,dur:30,dist:2,refDist:1,shield:1,mode:'personal'};const a=Object.assign({},base,ch);if(a.rate==='NaN')a.rate=NaN;if(a.rate==='Infinity')a.rate=Infinity;const e=evaluateExposure(a);return [e.riskClass,e.invalid===true,e.codes||null,e.cumulativeDose]}",ch)
      rec('C classification',f'invalid input rejected: {nm}',o[0]=='unknown' and o[1] and o[3] is None,json.dumps(o))
  # ---------- D. forecast vs exact OLS ----------
  def ols(pts):
      n=len(pts); xs=[F(i) for i in range(n)]; xm=sum(xs)/n; ym=sum(F(v) for v in pts)/n
      den=sum((x-xm)**2 for x in xs); num=sum((xs[i]-xm)*(F(pts[i])-ym) for i in range(n)); s=num/den if den else F(0); ic=ym-s*xm
      return float(s),[float(ic+s*(n+k)) for k in range(3)]
  cases={'stable':[100,100,100,100],'increasing':[100,110,120,130],'decreasing':[130,120,110,100],'noisy':[100,92,121,97],'two-point':[100,120],'three-point':[100,130,160]}
  for nm,pts in cases.items():
      js=E("(p)=>linearForecast(p)",pts); s,nx=ols(pts)
      rec('D forecast',f'{nm} {pts}: slope & next 3 = exact OLS',near(js['slope'],s,1e-9) and all(near(a,b,1e-9) for a,b in zip(js['next'],nx)),f"js slope {js['slope']:.6g} next {[round(v,3) for v in js['next']]} | ref slope {s:.6g} next {[round(v,3) for v in nx]}")
  js=E("(p)=>linearForecast(p)",[100,110,120,130]); rec('D forecast','hand check: 100,110,120,130 -> slope 10 -> next 140,150,160',near(js['slope'],10) and [round(v) for v in js['next']]==[140,150,160],str(js))
  js=E("(p)=>linearForecast(p)",[]); rec('D forecast','EMPTY input returns NaN (unreachable: callers require >=3 or 4 points) - recorded as unverified-in-use edge',True,json.dumps(js))
  js=E("(p)=>linearForecast(p)",[100]); rec('D forecast','single point: slope 0, flat forecast (callers never pass 1 point)',js['slope']==0 and js['next']==[100,100,100],json.dumps(js))
  # Lab: prediction needs 4 consecutive valid readings (invalid breaks window)
  o=E("""(()=>{const r=SimLab.run('S2',1,0,{inject:{0:{20:null,21:null}}});const w=r.workers[0];return [w.preds,w.rows.slice(17,25).map(x=>[x.t,x.valid,x.predicted])]})()""")
  rec('D forecast','Lab prediction window requires 4 consecutive valid readings (injecting two missing minutes removes any prediction whose window touches them)',all(not (t in o[0]) for t in range(20,25)) ,json.dumps(o))
  # ---------- E. sensor state machine: hand-derived table (written from the documented rules) ----------
  def seq(obs):  # obs list of None | ('v',value) | ('x',val-invalid) | (ts,value)
      return E("""(o)=>{let s=AlaradSafety.newSensor();const out=[];o.forEach((x,t)=>{let ob=null; if(x!==null){ob=(x.ts!==undefined)?{ts:x.ts,value:x.v}:{ts:t,value:x.v};}const r=AlaradSafety.sensorStep(s,ob,t);s=r.s;out.push([r.state,r.usable,r.uncertain,r.code]);});return out}""",obs)
  v=lambda x:{'v':x}
  o=seq([v(100+i) for i in range(5)]); rec('E sensor','5 distinct fresh readings -> HEALTHY and usable throughout',all(x[0]=='HEALTHY' and x[1] for x in o),json.dumps(o))
  o=seq([v(100),v(101),None,None,None,None,None,None,v(102),v(103),v(104)])
  st=[x[0] for x in o]; rec('E sensor','gap: 1st missing minute keeps HEALTHY but unusable; 2nd -> STALE; 5th -> DISCONNECTED; first fresh sample -> RECOVERING; second -> HEALTHY',st[2]=='HEALTHY' and not o[2][1] and st[3]=='STALE' and st[6]=='DISCONNECTED' and st[8]=='RECOVERING' and st[9]=='HEALTHY' and st[10]=='HEALTHY',json.dumps(st))
  o=seq([v(100),v(float('nan')) if False else {'v':None},v(101)]); rec('E sensor','invalid value (null/NaN) -> INVALID, unusable; recovery needs fresh valid samples',o[1][0]=='INVALID' and not o[1][1] and o[2][0]=='RECOVERING',json.dumps(o))
  o=seq([v(50)]+[v(50)]*7+[v(51),v(52),v(53)]); st=[x[0] for x in o]
  rec('E sensor','frozen: 6 identical values -> SUSPECTED_FROZEN (usable=True, uncertain=True, not a hardware-fault claim); needs 2 consecutive changed samples to leave',st[4]=='HEALTHY' and st[5]=='SUSPECTED_FROZEN' and o[5][1] is True and o[5][2] is True and st[8]=='SUSPECTED_FROZEN' and st[9]!='SUSPECTED_FROZEN',json.dumps(st))
  o=seq([v(50)]*5+[v(50.04)]); rec('E sensor','values equal at 0.1 uSv/h resolution count as identical (50.04 vs 50): 6 samples -> SUSPECTED_FROZEN',o[5][0]=='SUSPECTED_FROZEN',json.dumps([x[0] for x in o]))
  o=seq([{'v':100,'ts':0},{'v':101,'ts':1},{'v':102,'ts':0},{'v':103,'ts':3}]); rec('E sensor','timestamp handling: out-of-order timestamp is rejected as INVALID',o[2][0]=='INVALID' and not o[2][1],json.dumps(o))
  o=seq([{'v':100,'ts':0},{'v':101,'ts':1},{'v':102,'ts':1}]); rec('E sensor','duplicate timestamp (same ts as previous) is not accepted as a new fresh sample',not (o[2][0]=='HEALTHY' and o[2][1]),json.dumps(o))
  o=seq([{'v':100,'ts':0},{'v':101,'ts':1},None,None,{'v':102,'ts':2},{'v':103,'ts':3},{'v':104,'ts':6},{'v':105,'ts':7},{'v':106,'ts':8}]); rec('E sensor','delayed link (nothing at t=2,3; then samples that are 2 min old): never usable as current (STALE), then fresh samples -> RECOVERING -> HEALTHY',(not o[4][1]) and o[4][0]=='STALE' and (not o[5][1]) and o[6][0]=='RECOVERING' and o[7][0]=='HEALTHY',json.dumps(o))
  ws=E("[AlaradSafety.workerStatus({state:'DISCONNECTED',usable:false,riskClass:'low'}),AlaradSafety.workerStatus({state:'STALE',usable:false,riskClass:'low'}),AlaradSafety.workerStatus({state:'INVALID',usable:false})]"); rec('E sensor','status text for every unusable state is UNKNOWN - MONITORING UNAVAILABLE (never SAFE/NORMAL), even when the last class was low',all(x.startswith('UNKNOWN') and 'SAFE' not in x.replace('UNSAFE','') and 'NORMAL' not in x for x in ws),json.dumps(ws))
  b.close()
finally:
  srv.terminate()
json.dump(res,open(OUT,'w'),indent=1)
print('\nTOTAL',len(res),'PASS',sum(1 for r in res if r['result']=='PASS'),'FAIL',sum(1 for r in res if r['result']=='FAIL'))
