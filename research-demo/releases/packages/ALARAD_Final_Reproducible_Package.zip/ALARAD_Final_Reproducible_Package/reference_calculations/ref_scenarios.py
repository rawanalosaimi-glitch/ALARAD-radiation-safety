"""Independent scenario / metric recomputation. Regenerates all 13 scenarios from the pristine HTML, then recomputes TP/FP/FN, latency, precision/recall/F1,
dose totals and unmonitored minutes in Python from the RAW per-minute CSV rows with its own matcher. Compares with the app's summary CSV, the packaged CSVs and Phase-2 CSVs."""
import subprocess,time,json,sys,csv,io,hashlib
from fractions import Fraction as F
from playwright.sync_api import sync_playwright
HTML_DIR,PKG,P2,OUT=sys.argv[1:5]
srv=subprocess.Popen(['python3','-m','http.server','8873','-d',HTML_DIR],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL); time.sleep(1)
res=[];
def rec(a,n,ok,d=''):
    res.append({'area':a,'check':n,'result':'PASS' if ok else 'FAIL','detail':d}); print('PASS' if ok else 'FAIL','|',a,'|',n,'|',d)
sha=lambda s:hashlib.sha256(s.encode()).hexdigest()[:16]
with sync_playwright() as p:
    b=p.chromium.launch(args=['--no-sandbox']); pg=b.new_page(); pg.goto('http://localhost:8873/alarad_prototype.html'); pg.wait_for_timeout(600); E=pg.evaluate
    d=E("""()=>{SimLab.runAll();SafetyLab.runAll();return {s12:SimLab.stepsCsv(),sum12:SimLab.summaryCsv(),s7:SafetyLab.stepsCsv(),sum7:SafetyLab.summaryCsv(),def:SafetyLab.SC.map(s=>({id:s.id,w:s.workers}))}}""")
    b.close()
srv.terminate()
open(OUT+'/regen_scenario_steps_S1-S6.csv','w').write(d['s12']); open(OUT+'/regen_scenario_summary_S1-S6.csv','w').write(d['sum12'])
open(OUT+'/regen_safety_steps_S7-S13.csv','w').write(d['s7']); open(OUT+'/regen_safety_summary_S7-S13.csv','w').write(d['sum7'])
rd=lambda f:open(f,encoding='utf-8').read()
rec('regression','S1-S6 steps CSV regenerated from Phase-3 build == Phase-2 package scenario_steps.csv (byte-identical)',d['s12']==rd(P2+'/scenario_steps.csv'),f"{sha(d['s12'])} vs {sha(rd(P2+'/scenario_steps.csv'))}")
rec('regression','S1-S6 summary CSV regenerated == Phase-2 package scenario_summary.csv (byte-identical)',d['sum12']==rd(P2+'/scenario_summary.csv'),f"{sha(d['sum12'])} vs {sha(rd(P2+'/scenario_summary.csv'))}")
rec('reproducibility','S7-S13 steps CSV regenerated == Phase-3 package data/safety_steps.csv (byte-identical)',d['s7']==rd(PKG+'/data/safety_steps.csv'))
rec('reproducibility','S7-S13 summary CSV regenerated == Phase-3 package data/safety_summary.csv (byte-identical)',d['sum7']==rd(PKG+'/data/safety_summary.csv'))
# ---------- own matcher (written from the documented rule) ----------
GRACE=2
def runs(bits):
    out=[];i=0
    while i<len(bits):
        if bits[i]:
            j=i
            while j+1<len(bits) and bits[j+1]: j+=1
            out.append((i,j)); i=j+1
        else: i+=1
    return out
def match(events,alerts):            # events [(on,off_excl)], alerts [first_minute]; one-to-one greedy by onset; earliest unused alert in [onset, end+GRACE]
    used=set(); m=[]
    for (on,off) in sorted(events):
        pick=None
        for k,a in enumerate(sorted(alerts)):
            if k in used: continue
            if on<=a<=off+GRACE: pick=k;break
        if pick is None: m.append(None)
        else: used.add(pick); m.append(sorted(alerts)[pick])
    # documented rule (Phase-2 audit report finding 7): later alerts inside a MATCHED event window are repeats (not counted, not FP)
    sa=sorted(alerts)
    for k,a in enumerate(sa):
        if k in used: continue
        for (on,off),mm in zip(sorted(events),m):
            if mm is not None and on<=a<=off+GRACE: used.add(k); break
    return m,used
def prf(TP,FP,FN):
    pr=TP/(TP+FP) if TP+FP else None; rc=TP/(TP+FN) if TP+FN else None; f1=2*TP/(2*TP+FP+FN) if 2*TP+FP+FN else None
    return pr,rc,f1
# ---------- S1-S6 ----------
steps=list(csv.DictReader(io.StringIO(d['s12']))); summ={r['scenario']:r for r in csv.DictReader(io.StringIO(d['sum12']))}
tab=[]
for sid in ['S1','S2','S3','S4','S5','S6']:
    rows=[r for r in steps if r['scenario']==sid]; ws=sorted(set(r['worker'] for r in rows)); TP=FP=FN=0; lats=[]; maxd=F(0)
    for w in ws:
        rr=[r for r in rows if r['worker']==w]; rr.sort(key=lambda r:int(r['t_min']))
        ev=[(a,b+1) for a,b in runs([r['ground_truth_abnormal']=='1' for r in rr])]
        al=[a for a,b in runs([r['alert_active']=='1' for r in rr])]
        m,used=match(ev,al); TP+=sum(x is not None for x in m); FN+=sum(x is None for x in m); FP+=len(al)-len(used)
        lats+=[x-e[0] for x,e in zip(m,sorted(ev)) if x is not None]
        # dose: exact
        cum=F(0)
        for r in rr:
            if r['reading_valid']=='1': cum+=F(r['engine_input_rate_uSv_h'])*F(r['dt_min'])/60/1000
        maxd=max(maxd,cum)
    s=summ[sid]; pr,rc,f1=prf(TP,FP,FN)
    ok=(TP,FP,FN)==(int(s['TP']),int(s['FP']),int(s['FN']))
    pr_c=(s['precision']=='' and pr is None) or (s['precision']!='' and pr is not None and abs(float(s['precision'])-pr)<0.006)
    rc_c=(s['recall']=='' and rc is None) or (s['recall']!='' and rc is not None and abs(float(s['recall'])-rc)<0.006)
    f_c=(s['F1']=='' and f1 is None) or (s['F1']!='' and f1 is not None and abs(float(s['F1'])-f1)<0.006)
    lat_ok=(s['mean_latency_min']=='' and not lats) or (s['mean_latency_min']!='' and lats and abs(float(s['mean_latency_min'])-sum(lats)/len(lats))<0.06)
    dose_ok=abs(float(s['max_worker_accumulated_dose_mSv'])-float(maxd))<1.5e-6   # CSV rounds the engine rate to 6 dp
    rec('metrics '+sid,f"{sid}: independent TP/FP/FN/P/R/F1/latency/max-dose from raw rows == app summary",ok and pr_c and rc_c and f_c and lat_ok and dose_ok,f"mine TP{TP} FP{FP} FN{FN} lat{(sum(lats)/len(lats)) if lats else None} P{pr} R{rc} F1{f1} dose{float(maxd):.6f} | app TP{s['TP']} FP{s['FP']} FN{s['FN']} lat{s['mean_latency_min']} dose{s['max_worker_accumulated_dose_mSv']}")
    tab.append((sid,len(ws),TP,FP,FN,pr,rc,f1,(sum(lats)/len(lats)) if lats else None,float(maxd)))
# ---------- S7-S13 ----------
st=list(csv.DictReader(io.StringIO(d['s7']))); sm={r['scenario']:r for r in csv.DictReader(io.StringIO(d['sum7']))}
defs={x['id']:x['w'] for x in d['def']}
UNAV={'STALE','DISCONNECTED','INVALID'}
for sid in ['S7','S8','S9','S10','S11','S12','S13']:
    rows=[r for r in st if r['scenario']==sid]; ws=defs[sid]; s=sm[sid]
    TP=FP=FN=0;lat=[];dq_tp=dq_fp=dq_fn=0;dql=[];trusted=F(0);unc=F(0);unmon=0;true=F(0);cnt_state={}
    for w in ws:
        rr=sorted([r for r in rows if r['worker']==w['id']],key=lambda r:int(r['t_min']))
        ev=[(e['start'],e['end']) for e in w['truth']]; al=[a for a,b in runs([r['alert_active']=='1' for r in rr])]
        m,used=match(ev,al); TP+=sum(x is not None for x in m); FN+=sum(x is None for x in m); FP+=len(al)-len(used)
        lat+=[x-e[0] for x,e in zip(m,sorted(ev)) if x is not None]
        # data-quality: a fault window is detected if sensor_state leaves HEALTHY/RECOVERING-usable i.e. unavailable or SUSPECTED_FROZEN within [from, to+GRACE]
        dqmin=[int(r['t_min']) for r in rr if r['sensor_state'] in UNAV or r['sensor_state']=='SUSPECTED_FROZEN']
        dqruns=runs([ (r['sensor_state'] in UNAV or r['sensor_state']=='SUSPECTED_FROZEN') for r in rr])
        fl=[(f['from'],f['to']) for f in w['faults']]
        # merge faults that overlap as the app does per distinct window
        mm,usd=match(fl,[a for a,b in dqruns])
        dq_tp+=sum(x is not None for x in mm); dq_fn+=sum(x is None for x in mm); dq_fp+=len(dqruns)-len(usd)
        dql+=[x-f[0] for x,f in zip(mm,sorted(fl)) if x is not None]
        for r in rr:
            tr=F(r['true_signal_uSv_h_SIMULATION_ONLY']); true+=tr/60/1000
            if r['data_usable']=='1':
                rate=F(r['received_value'])
                if r['uncertain']=='1': unc+=rate/60/1000
                else: trusted+=rate/60/1000
            else: unmon+=1
    ok_rad=(TP,FP,FN)==(int(s['rad_TP']),int(s['rad_FP']),int(s['rad_FN']))
    ok_dq=(dq_tp,dq_fp,dq_fn)==(int(s['dq_TP']),int(s['dq_FP']),int(s['dq_FN']))
    ok_d=abs(float(trusted)-float(s['observed_trusted_dose_mSv']))<2e-6 and abs(float(unc)-float(s['observed_uncertain_dose_mSv']))<2e-6 and unmon==int(s['unmonitored_min']) and abs(float(true)-float(s['true_simulated_dose_mSv']))<2e-5
    rec('metrics '+sid,f"{sid}: independent radiation TP/FP/FN, DQ TP/FP/FN, observed/uncertain dose, unmonitored min, true dose from raw rows == app summary",ok_rad and ok_dq and ok_d,f"mine rad {TP}/{FP}/{FN} dq {dq_tp}/{dq_fp}/{dq_fn} trusted {float(trusted):.6f} unc {float(unc):.6f} unmon {unmon} true {float(true):.6f} | app rad {s['rad_TP']}/{s['rad_FP']}/{s['rad_FN']} dq {s['dq_TP']}/{s['dq_FP']}/{s['dq_FN']} trusted {s['observed_trusted_dose_mSv']} unc {s['observed_uncertain_dose_mSv']} unmon {s['unmonitored_min']} true {s['true_simulated_dose_mSv']}")
    # the invariant: never a dose from an unusable minute
    bad=[r for r in rows if r['data_usable']=='0' and (float(r['step_dose_trusted_mSv'] or 0)!=0 or float(r['step_dose_uncertain_mSv'] or 0)!=0)]
    rec('fail-safe '+sid,f"{sid}: every unusable minute has zero dose, no flag, no immediate criterion, and status UNKNOWN",not bad and all(r['flagged']=='0' and r['immediate_criterion']=='0' and r['worker_status'].startswith('UNKNOWN') for r in rows if r['data_usable']=='0'),f"{sum(r['data_usable']=='0' for r in rows)} unusable minutes")
# matcher semantics on constructed cases (app's pure matcher)
srv=subprocess.Popen(['python3','-m','http.server','8874','-d',HTML_DIR],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL); time.sleep(1)
with sync_playwright() as p:
    b=p.chromium.launch(args=['--no-sandbox']); pg=b.new_page(); pg.goto('http://localhost:8874/alarad_prototype.html'); pg.wait_for_timeout(500); E=pg.evaluate
    ev=lambda evs,eps:E("([a,c])=>{const e=a.map(x=>({start:x[0],end:x[1],matched:false}));const ep=c.map(x=>({det:x}));const m=SimLab.pure.matchEvents(e,ep,2);return {matches:m.matches,fp:m.fp,repeats:m.repeats}}",[evs,eps])
    o=ev([[10,20],[22,30]],[12]); rec('matcher','one alert cannot match two events (2 events, 1 alert -> 1 TP + 1 FN)',sum(x is not None for x in o['matches'])==1,json.dumps(o))
    o=ev([[10,20]],[11,13]); rec('matcher','two alerts in one event: one TP, second is a repeat (NOT an independent detection, not FP)',sum(x is not None for x in o['matches'])==1 and len(o['repeats'])==1 and len(o['fp'])==0,json.dumps(o))
    o=ev([[10,20]],[5]); rec('matcher','alert before onset is FP, event FN',o['matches']==[None] and len(o['fp'])==1,json.dumps(o))
    o=ev([[10,20]],[22]); rec('matcher','alert at end+2 (grace) matches; at end+3 does not',o['matches']!=[None],json.dumps(o)); o=ev([[10,20]],[23]); rec('matcher','alert at end+3 is FP',o['matches']==[None] and len(o['fp'])==1,json.dumps(o))
    o=ev([[10,20]],[]); rec('matcher','missed event counted as FN',o['matches']==[None],json.dumps(o))
    m=lambda a,b_,c:E("([a,b,c])=>SimLab.pure.metrics(a,b,c)",[a,b_,c])
    x=m(0,0,0); rec('metrics','TP=FP=FN=0: precision, recall, F1 are n/a (null), not 0 or 1',all(x[k] is None for k in ('precision','recall','f1')) if isinstance(x,dict) else True,json.dumps(x))
    x=m(3,1,1); rec('metrics','TP3 FP1 FN1: P=0.75 R=0.75 F1=0.75',abs(x['precision']-.75)<1e-12 and abs(x['recall']-.75)<1e-12 and abs(x['f1']-.75)<1e-12,json.dumps(x))
    b.close()
srv.terminate()
json.dump({'res':res,'table':tab},open(OUT+'/ref_scenarios_results.json','w'),indent=1)
print('TOTAL',len(res),'PASS',sum(r['result']=='PASS' for r in res),'FAIL',sum(r['result']=='FAIL' for r in res))
