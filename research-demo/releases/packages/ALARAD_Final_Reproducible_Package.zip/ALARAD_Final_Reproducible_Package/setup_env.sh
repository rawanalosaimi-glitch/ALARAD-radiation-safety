#!/bin/bash
# Creates env/ (the directories the test runners serve) from the tracked HTML files. Safe to re-run.
set -e; cd "$(dirname "$0")"
rm -rf env; mkdir -p env/new env/base env/p1 env/p2 logs evidence
cp candidate/ALARAD_Prototype_Final_Release_Candidate.html env/new/alarad_prototype.html     # the build under test
cp baseline/ALARAD_Prototype_Phase3.html env/base/alarad_prototype.html                      # untouched Phase-3 baseline (used only to prove the new tests detect the defects)
cp reference_builds/phase1_base.html env/p1/phase1_base.html                                 # Phase-1 reference build (legacy-behaviour comparison)
cp reference_builds/ALARAD_Prototype_Validation.html env/p2/ALARAD_Prototype_Validation.html # Phase-2 reference build (legacy engine / before-after)
sha256sum -c SHA256SUMS.txt
