import os as _os
ROOT=_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))   # package root: all paths are relative to it
"""Independent validation suite for the ALARAD Simulation Lab.
Reference values come from hand calculations and from a SEPARATE Python re-implementation that works only from
the exported CSV files (not from the JavaScript functions under test)."""
import subprocess,time,json,re,csv,io,math,random,sys,hashlib
from playwright.sync_api import sync_playwright
PORT_NEW,PORT_OLD=8842,8843
srv1=subprocess.Popen(['python3','-m','http.server',str(PORT_NEW),'-d',ROOT+'/env/new'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
srv2=subprocess.Popen(['python3','-m','http.server',str(PORT_OLD),'-d',ROOT+'/env/p1'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
time.sleep(1)
R=[];errs=[]
def T(name,cond,detail=''):
    R.append((name,'PASS' if cond else 'FAIL',detail)); print(('PASS' if cond else 'FAIL'),'-',name,detail)
def close(a,b,tol=1e-9): return abs(a-b)<=tol
# ---------------- independent Python references ----------------
M32=0xFFFFFFFF
def imul(a,b): return (a*b)&M32
def mulberry(seed):
    st=[seed&M32]
    def f():
        st[0]=(st[0]+0x6D2B79F5)&M32; a=st[0]
        t=imul(a^(a>>15),1|a)
        t=((t+imul(t^(t>>7),61|t))&M32)^t
        return ((t^(t>>14))&M32)/4294967296
    return f
BASE={'Cath Lab 1':90,'Cath Lab 2':85,'Cath Lab 3':92,'Fluoroscopy Suite':70,'Nuclear Medicine':35,'PET/CT Suite':45,'CT Suite':55}
def m_ramp(t,s,pk,hold,peak): return 1 if t<s else (1+(peak-1)*(t-s)/(pk-s) if t<pk else (peak if t<hold else 1))
def m_step(t,s,e,m): return m if s<=t<e else 1
def m_spk(t,sp): return max([m for (a,l,m) in sp if a<=t<a+l]+[1])
# scenario table: id -> (seed, [(worker,room,fn(t)->mult)] ) for personal-mode ones
PERS={'S1':(20260601,[('ST-04','Cath Lab 1',lambda t:1)]),
 'S2':(20260602,[('ST-11','Fluoroscopy Suite',lambda t:m_ramp(t,15,45,50,4.0))]),
 'S3':(20260603,[('ST-06','Cath Lab 3',lambda t:m_step(t,20,30,4.0))]),
 'S5':(20260605,[('ST-09','CT Suite',lambda t:m_spk(t,[(30,1,5.0),(44,2,3.2)]))]),
 'S6':(20260606,[('ST-04','Cath Lab 1',lambda t:max(1,m_spk(t,[(40,1,4.0)]))),('ST-11','Fluoroscopy Suite',lambda t:m_step(t,15,35,3.5)),('ST-13','PET/CT Suite',lambda t:m_ramp(t,25,50,55,3.0))])}
def py_personal(sid,offset=0,noise=0.05):
    seed,ws=PERS[sid]; out={}
    for wi,(wid,room,fn) in enumerate(ws):
        r=mulberry(seed+offset+wi*1000); base=BASE[room]; rows=[]
        for t in range(60):
            n1=1+(r()*2-1)*noise; n2=1+(r()*2-1)*noise
            rows.append(base*fn(t)*n1)
        out[wid]=(base,rows)
    return out
def py_flag(rate,base,de=0.5,dc=1.5,doe=0.15,doc=0.35):
    dev=(rate-base)/base; dose=rate*(30/60)/1000
    return not (dev<de and dose<doe)
def py_episodes(flags,K):
    eps=[];i=0;n=len(flags)
    while i<n:
        if flags[i]:
            j=i
            while j+1<n and flags[j+1]: j+=1
            if j-i+1>=K: eps.append((i,j,i+K-1))
            i=j+1
        else: i+=1
    return eps
def py_match(events,eps,grace=2):
    order=sorted(range(len(events)),key=lambda i:(events[i][0],events[i][1],i)); used=set(); mt=[None]*len(events)
    e_order=sorted(range(len(eps)),key=lambda i:(eps[i][2],eps[i][0],i))
    for ei in order:
        s,e=events[ei]
        for pi in e_order:
            if pi in used: continue
            if s<=eps[pi][2]<=e+grace: mt[ei]=pi; used.add(pi); break
    fp=0
    for pi in e_order:
        if pi in used: continue
        d=eps[pi][2]
        if any(mt[ei] is not None and events[ei][0]<=d<=events[ei][1]+grace for ei in range(len(events))): continue
        fp+=1
    return mt,fp
def py_metrics(TP,FP,FN):
    P=TP/(TP+FP) if TP+FP>0 else None; Rr=TP/(TP+FN) if TP+FN>0 else None; F=2*TP/(2*TP+FP+FN) if 2*TP+FP+FN>0 else None
    return P,Rr,F
def py_eval_csv(rows_by_worker,K,grace=2,win=10):
    """re-derive TP/FP/FN/TN/latency per scenario from exported step rows only"""
    TP=FP=FN=TN=0; lats=[]
    for w,rows in rows_by_worker.items():
        flags=[int(r['flagged'])==1 for r in rows]
        truth=[int(r['ground_truth_abnormal'])==1 for r in rows]
        events=[];i=0
        while i<60:
            if truth[i]:
                j=i
                while j+1<60 and truth[j+1]: j+=1
                events.append((i,j+1)); i=j+1
            else: i+=1
        eps=py_episodes(flags,K); mt,fp=py_match(events,eps,grace)
        tp=sum(1 for m in mt if m is not None); TP+=tp; FP+=fp; FN+=len(events)-tp
        for ei,m in enumerate(mt):
            if m is not None: lats.append(eps[m][2]-events[ei][0])
        alert=[False]*60
        for (a,b,d) in eps:
            for k in range(d,b+1): alert[k]=True
        for k in range(6):
            a0,a1=k*win,k*win+win
            if not any(a0<e+grace and a1>s for (s,e) in events):
                if not any(alert[a0:a1]): TN+=1
    return TP,FP,FN,TN,lats
def parse_csv(text): return list(csv.DictReader(io.StringIO(text)))
def group(rows):
    g={}
    for r in rows: g.setdefault((r['scenario'],r['worker']),[]).append(r)
    return g
try:
  with sync_playwright() as p:
    b=p.chromium.launch(args=['--no-sandbox']); ctx=b.new_context(viewport={'width':1400,'height':1000},accept_downloads=True); pg=ctx.new_page()
    pg.on('pageerror',lambda e:errs.append('PAGEERROR '+str(e)))
    pg.on('console',lambda m: errs.append('CONSOLE '+m.text) if m.type=='error' and 'ERR_TUNNEL' not in m.text and 'font' not in m.text.lower() else None)
    pg.on('dialog',lambda d:(errs.append('DIALOG '+d.message),d.dismiss()))
    pg.goto(f'http://localhost:{PORT_NEW}/alarad_prototype.html'); pg.wait_for_timeout(500)
    E=pg.evaluate
    # ===== 1-2. dose-rate-to-dose conversion and cumulative integration (hand-computed references)
    ID=lambda r,d:E("([r,d])=>SimLab.pure.integrateDose(r,d)",[r,d])
    x=ID([120],[1]); T('Dose conversion: 120 µSv/h for 1 min = 0.002 mSv (hand calc)',close(x['total'],0.002,1e-15))
    x=ID([1000],[60]); T('Dose conversion: 1000 µSv/h for 60 min = 1.000 mSv',close(x['total'],1.0,1e-15))
    x=ID([600],[30]); T('Dose conversion: 600 µSv/h for 30 min = 0.300 mSv',close(x['total'],0.3,1e-15))
    x=ID([0,0],[1,1]); T('Zero dose rate gives exactly zero dose and is valid (not rejected)',x['total']==0 and x['invalid']==0)
    x=ID([100,200,400],[1,2.5,0.5]); ref=(100*1+200*2.5+400*0.5)/60/1000
    T('Irregular intervals (1, 2.5, 0.5 min): total = (100·1+200·2.5+400·0.5)/60/1000 mSv',close(x['total'],ref,1e-15) and close(x['accum'][1],(100*1+200*2.5)/60000,1e-15),f"{x['total']:.8f}")
    rnd=random.Random(7); ok=True
    for _ in range(50):
        n=rnd.randint(1,40); rr=[rnd.uniform(0,900) for _ in range(n)]; dd=[rnd.choice([0.5,1,1,2,3.25]) for _ in range(n)]
        out=ID(rr,dd); refc=0; good=True
        for i in range(n):
            refc+=rr[i]*dd[i]/60/1000
            good=good and close(out['accum'][i],refc,1e-12)
        ok=ok and good and close(out['total'],refc,1e-12)
    T('Cumulative integration equals independent running sum (50 random series, random intervals)',ok)
    x=ID([float('nan'),-5,None,float('inf'),2e6,100],[1,1,1,1,1,1])
    T('Invalid readings (NaN, negative, missing, Infinity, >1e6) are rejected: only the valid 100 µSv/h minute adds dose',x['invalid']==5 and close(x['total'],100/60000,1e-15),str(x['invalid']))
    x=ID([100,100,100],[0,-1,float('nan')]); T('Non-positive or invalid time intervals add no dose and are counted',x['total']==0 and x['invalid']==3)
    VR=lambda v:E("(v)=>SimLab.pure.validReading(v)",v)
    T('Reading validity boundaries: 0 valid, 1e6 valid, 1e6+1 invalid, string "100" invalid, -0.0001 invalid',VR(0) and VR(1e6) and not VR(1e6+1) and not VR("100") and not VR(-0.0001))
    # ===== 3. deterministic reproduction against an independent PRNG implementation
    E("SimLab.SCEN.forEach(s=>SimLab.run(s.id,1,0))")
    steps=parse_csv(E("SimLab.stepsCsv()")); g=group(steps)
    ok=True; worst=0
    for sid in PERS:
        ref=py_personal(sid)
        for wid,(base,rates) in ref.items():
            rows=g[(sid,wid)]
            for t,r in enumerate(rates):
                d=abs(float(rows[t]['engine_input_rate_uSv_h'])-r); worst=max(worst,d); ok=ok and d<2e-6
    T('Independent Python mulberry32 + pattern re-implementation reproduces every personal-mode reading (5 scenarios, 7 workers, 420 rows) to 1e-6 µSv/h',ok,f'max abs diff {worst:.2e}')
    # area-mode S4 reference
    r=mulberry(20260604); base=BASE['Cath Lab 2']; rows=g[('S4','ST-02')]; ok=True
    for t in range(60):
        n1=1+(r()*2-1)*0.05; n2=1+(r()*2-1)*0.05
        srcM=4.0 if t>=10 else 1.0; dist=1.0 if t<25 else 2.5
        reading=base*srcM*(1.0/1.0)**1.7*n1; modeled=reading*(1.0/dist)**2; measured=base*srcM*(1.0/dist)**1.7*n2
        ok=ok and close(float(rows[t]['engine_input_rate_uSv_h']),modeled,2e-6) and close(float(rows[t]['modeled_area_estimate_uSv_h']),modeled,2e-6) and close(float(rows[t]['measured_personal_rate_uSv_h']),measured,2e-6) and float(rows[t]['worker_distance_m'])==dist
    T('Area-monitor scenario 4: modeled estimate = reading×(1.0/d)², measured series = independent d^-1.7 field; distances as documented',ok)
    T('Distance/shielding applied only where physical: personal-dosimeter rows export no worker distance',all(r['worker_distance_m']=='' for r in steps if r['reading_kind']=='measured') and all(r['worker_distance_m']!='' for r in steps if r['reading_kind']=='modeled'))
    a1=E("SimLab.run('S2',1,0).fingerprint"); a2=E("SimLab.run('S2',1,0).fingerprint")
    T('Same seed reproduces identical fingerprint; seed offset 1 differs',a1==a2 and E("SimLab.run('S2',1,1).fingerprint")!=a1)
    # cross-version regression: numeric rows identical to the Phase-1 file
    pg2=ctx.new_page(); pg2.goto(f'http://localhost:{PORT_OLD}/phase1_base.html'); pg2.wait_for_timeout(400)
    JS="""()=>{const o={};SimLab.SCEN.forEach(s=>{const r=SimLab.run(s.id,1,0);o[s.id]=r.workers.map(w=>w.rows.map(x=>[x.t,+x.engineRate.toFixed(9),+x.measured.toFixed(9),x.modeled==null?null:+x.modeled.toFixed(9),x.riskClass,x.flagged,x.alert,x.predicted,+x.stepDose.toFixed(12),+x.accum.toFixed(12)]));o[s.id+'_c']=[r.agg.TP,r.agg.FP,r.agg.FN,r.agg.TN]});return o}"""
    T('Regression: all six scenarios give numerically identical rows, alerts and counts as the Phase-1 file (default settings)',pg2.evaluate(JS)==E(JS)); pg2.close()
    # ===== 4. detection logic independent reference (flags, episodes, matching, metrics) from exported rows
    ok=True
    for r in steps:
        base=float(r['baseline_uSv_h']); rate=float(r['engine_input_rate_uSv_h'])
        ok=ok and (py_flag(rate,base)==(r['flagged']=='1'))
    T('Independent re-derivation of the risk flag (deviation ≥ +50 % or projected dose ≥ 0.15 mSv) matches the engine flag on all 480 exported rows',ok)
    for K in (1,3):
        E(f"SimLab.SCEN.forEach(s=>SimLab.run(s.id,{K},0))")
        st=parse_csv(E("SimLab.stepsCsv()")); sm=parse_csv(E("SimLab.summaryCsv()")); gg=group(st); ok=True; bad=[]
        for srow in sm:
            sid=srow['scenario']; rows_by={w:rows for (s,w),rows in gg.items() if s==sid}
            TP,FP,FN,TN,lats=py_eval_csv(rows_by,K)
            P,Rr,F=py_metrics(TP,FP,FN)
            got=(int(srow['TP']),int(srow['FP']),int(srow['FN']),int(srow['TN']))
            exp=(TP,FP,FN,TN)
            okm=(got==exp)
            okm=okm and ((srow['precision']=='')==(P is None)) and ((srow['recall']=='')==(Rr is None)) and ((srow['F1']=='')==(F is None))
            if P is not None: okm=okm and close(float(srow['precision']),P,1e-4)
            if Rr is not None: okm=okm and close(float(srow['recall']),Rr,1e-4)
            if F is not None: okm=okm and close(float(srow['F1']),F,1e-4)
            if lats: okm=okm and close(float(srow['mean_latency_min']),sum(lats)/len(lats),1e-2)
            else: okm=okm and srow['mean_latency_min']==''
            ok=ok and okm
            if not okm: bad.append((sid,got,exp))
        T(f'Independent Python re-implementation of episodes, matching, TP/FP/FN/TN, precision, recall, F1 and latency from the exported step rows agrees with the app (confirmation {K}, all 6 scenarios)',ok,str(bad))
    # ===== 5-8. event matching, duplicates, FP/FN, latency with crafted cases
    MT=lambda ev,ep,gr=2:E("([e,p,g])=>SimLab.pure.matchEvents(e,p,g)",[ev,ep,gr])
    ep=lambda det,rs=None,re_=None:{'det':det,'runStart':det if rs is None else rs,'runEnd':det if re_ is None else re_}
    m=MT([{'start':10,'end':20}],[ep(10),ep(12),ep(15)])
    T('Duplicate alerts: one event with three alert episodes → exactly one TP, two repeats, zero FP',sum(1 for x in m['matches'] if x is not None)==1 and len(m['repeats'])==2 and len(m['fp'])==0 and m['matches'][0]==0)
    m=MT([{'start':10,'end':13},{'start':12,'end':15}],[ep(12),ep(14)])
    T('One-to-one matching: an alert inside two overlapping windows is used once (event 1 gets it, event 2 gets the later alert)',m['matches']==[0,1])
    m=MT([{'start':10,'end':13},{'start':12,'end':15}],[ep(12)])
    T('One alert cannot create two TPs: second overlapping event becomes a false negative',m['matches']==[0,None])
    m=MT([{'start':10,'end':20}],[ep(8,8,12)])
    T('Alert before the onset is not a valid detection: FP, event FN, flagged as "early alert persisting into event"',m['matches']==[None] and m['fp']==[0] and m['early']==1)
    m=MT([{'start':10,'end':20}],[ep(22)]); m2=MT([{'start':10,'end':20}],[ep(23)])
    T('Matching window boundary: alert at end+grace (22) matches; one minute later (23) is FP and the event FN',m['matches']==[0] and m2['matches']==[None] and m2['fp']==[0])
    m=MT([{'start':10,'end':20}],[ep(10)]); T('Alert exactly at onset matches (latency 0)',m['matches']==[0])
    m=MT([{'start':10,'end':20}],[ep(9)]); T('Alert one minute before onset does not match',m['matches']==[None] and len(m['fp'])==1)
    m=MT([],[ep(3),ep(30),ep(41)]); T('Unmatched alerts with no events are all counted as FP',len(m['fp'])==3 and m['matches']==[])
    m=MT([{'start':10,'end':20},{'start':30,'end':40}],[]); T('Events without any alert are both FN',m['matches']==[None,None])
    ev=[{'start':30,'end':40,'k':'b'},{'start':10,'end':20,'k':'a'}]; eps=[ep(32),ep(11),ep(60)]
    m1=MT(ev,eps); m2=MT(list(reversed(ev)),eps); res1={ev[i]['k']:m1['matches'][i] for i in range(2)}; res2={list(reversed(ev))[i]['k']:m2['matches'][i] for i in range(2)}
    T('Matching is deterministic and independent of input order of events',res1==res2 and all(MT(ev,eps)==m1 for _ in range(5)))
    rnd=random.Random(11); ok=True
    for _ in range(300):
        ne=rnd.randint(0,3); evs=[]; 
        for _i in range(ne):
            s=rnd.randint(0,50); evs.append({'start':s,'end':s+rnd.randint(1,10)})
        nep=rnd.randint(0,5); eps=[]
        for _i in range(nep):
            a=rnd.randint(0,58); b_=a+rnd.randint(0,4); k=rnd.randint(1,3); d=min(a+k-1,b_); eps.append({'runStart':a,'runEnd':b_,'det':d})
        r1=MT(evs,eps); mt,fp=py_match([(e['start'],e['end']) for e in evs],[(e['runStart'],e['runEnd'],e['det']) for e in eps])
        ok=ok and r1['matches']==mt and len(r1['fp'])==fp
    T('Matching agrees with an independent Python greedy reference on 300 random event/alert sets',ok)
    EP=lambda f,k:E("([f,k])=>SimLab.pure.buildEpisodes(f,k)",[f,k])
    rnd=random.Random(5); ok=True
    for _ in range(200):
        fl=[rnd.random()<0.4 for _i in range(rnd.randint(1,60))]; K=rnd.randint(1,5)
        j=EP(fl,K); refE=py_episodes(fl,K); sup=0; i=0
        while i<len(fl):
            if fl[i]:
                jj=i
                while jj+1<len(fl) and fl[jj+1]: jj+=1
                if jj-i+1<K: sup+=1
                i=jj+1
            else: i+=1
        ok=ok and [(e['runStart'],e['runEnd'],e['det']) for e in j['episodes']]==refE and j['suppressed']==sup
    T('Alert-episode builder (confirmation window) agrees with the independent reference on 200 random flag sequences',ok)
    # metrics + zero denominators
    MX=lambda a,b_,c:E("([a,b,c])=>SimLab.pure.metrics(a,b,c)",[a,b_,c])
    x=MX(0,0,0); T('Zero-denominator case TP=FP=FN=0: precision, recall, F1 are all n/a (null), not 0 or 1',x['precision'] is None and x['recall'] is None and x['f1'] is None)
    x=MX(3,1,2); T('Metrics TP=3, FP=1, FN=2: precision 0.75, recall 0.6, F1 = 2·3/(6+1+2) = 0.6667',close(x['precision'],.75) and close(x['recall'],.6) and close(x['f1'],2/3))
    T('F1 equals the harmonic mean 2PR/(P+R) when both are defined',close(x['f1'],2*x['precision']*x['recall']/(x['precision']+x['recall'])))
    x=MX(0,2,0); T('TP=0, FP=2, FN=0: precision 0, recall n/a, F1 0',x['precision']==0 and x['recall'] is None and x['f1']==0)
    x=MX(0,0,2); T('TP=0, FP=0, FN=2: precision n/a, recall 0, F1 0',x['precision'] is None and x['recall']==0 and x['f1']==0)
    x=MX(5,0,0); T('Perfect case TP=5: precision = recall = F1 = 1',x['precision']==1 and x['recall']==1 and x['f1']==1)
    # false positives / negatives in actual scenarios and latency
    E("SimLab.SCEN.forEach(s=>SimLab.run(s.id,1,0))")
    cnt=E("(()=>{const o={};['S1','S2','S3','S4','S5','S6'].forEach(i=>{const a=SimLab.results()[i].agg;o[i]=[a.TP,a.FP,a.FN,a.TN,a.latencyFirst,a.firstAbnormal,a.firstDetection]});return o})()")
    T('False positives identified: S5 transients = 2 FP; S6 spike on the normal worker = 1 FP; S1 = 0',cnt['S5'][1]==2 and cnt['S6'][1]==1 and cnt['S1'][1]==0)
    j=E("SimLab.run('S3W',1,0,{},{devElevated:1.0,devCritical:1.5}).agg"); j2=E("SimLab.run('S3B',5,0).agg")
    T('False negatives identified: weak ×1.8 event with +100 % threshold = 1 FN, 0 TP; 3-minute event with confirmation 5 = 1 FN',j['FN']==1 and j['TP']==0 and j2['FN']==1 and j2['TP']==0)
    T('Detection latency = alert minute − documented onset: S3 0, S2 = first flagged minute − 15',cnt['S3'][4]==0 and cnt['S2'][4]==cnt['S2'][6]-cnt['S2'][5])
    # latency independent: S2 first flagged from CSV
    s2=[r for r in group(parse_csv(E("SimLab.stepsCsv()")))[('S2','ST-11')]]; ff=[int(r['t_min']) for r in s2 if r['flagged']=='1'][0]
    T('S2 latency equals first flagged exported minute − onset (independent from CSV)',cnt['S2'][4]==ff-15,f'first flagged {ff}')
    lagcheck=E("(()=>{const e=SimLab.run('S2',1,0).workers[0].events[0];return [e.latency,e.ideal,e.lagIdeal]})()")
    T('Ideal-crossing reference: noise-free ramp 1+3(t−15)/30 reaches +50 % at minute 20; lag vs ideal = latency − 5',lagcheck[1]==20 and lagcheck[2]==lagcheck[0]-5,str(lagcheck))
    # ===== 9. threshold boundary conditions (engine used by the Lab, probed directly)
    EV=lambda rate,pm=1,room='Cath Lab 1':E("([r,pm,room])=>evaluateExposure({room,procMult:pm,rate:r,dur:30,dist:1,refDist:1,shield:1,mode:'personal'}).riskClass",[rate,pm,room])
    T('Boundary: deviation exactly +50 % (135 vs baseline 90) is ELEVATED; just below is LOW',EV(135)=='med' and EV(134.999)=='low')
    T('Boundary: deviation exactly +150 % (225) is CRITICAL; just below is ELEVATED',EV(225)=='high' and EV(224.99)=='med')
    T('Boundary: projected dose exactly 0.15 mSv (300 µSv/h × 0.5 h, baseline high) is ELEVATED; just below is LOW',EV(300,10)=='med' and EV(299.99,10)=='low')
    T('Boundary: projected dose exactly 0.35 mSv (700 µSv/h) is CRITICAL; just below is ELEVATED',EV(700,10)=='high' and EV(699.99,10)=='med')
    # ===== 10. missing / invalid data end-to-end through the Lab
    inj={0:{10:float('nan'),11:-5,12:None,13:float('inf'),14:5e6,5:0,40:900000}}
    jj=E("([inj])=>{const r=SimLab.run('S3',1,0,{inject:inj});const w=r.workers[0];return {inv:w.invalid,rows:w.rows.map(x=>[x.t,x.valid,x.riskClass,x.flagged,x.stepDose,x.alert,x.engineRate]),acc:w.accum,eps:w.episodes.map(e=>[e.runStart,e.runEnd,e.det]),tl:w.timeline.filter(x=>x.m.indexOf('INVALID')>=0).length}}",[json.loads(json.dumps(inj).replace('NaN','null').replace('Infinity','null'))]) if False else None
    # (NaN/Infinity cannot cross the JSON bridge, so build the injection inside the page)
    jj=E("""()=>{const inj={0:{10:NaN,11:-5,12:null,13:Infinity,14:5e6,5:0,40:900000}};const r=SimLab.run('S3',1,0,{inject:inj});const w=r.workers[0];
        return {inv:w.invalid,rows:w.rows.map(x=>[x.t,x.valid,x.riskClass,x.flagged,x.stepDose,x.alert,x.engineRate]),acc:w.accum,eps:w.episodes.map(e=>[e.runStart,e.runEnd,e.det]),tl:w.timeline.filter(x=>x.m.indexOf('INVALID')>=0).length,csv:SimLab.pure?null:null}}""")
    rws=jj['rows']
    T('Invalid minutes (NaN, negative, missing, Infinity, 5e6 µSv/h) are marked invalid, not flagged, add 0 mSv and never raise an alert',jj['inv']==5 and all((not rws[t][1]) and rws[t][2]=='invalid' and (not rws[t][3]) and rws[t][4]==0 and not rws[t][5] for t in range(10,15)))
    # PHASE 3 INTENTIONAL CHANGE (re-baselined): before Phase 3 the raw engine returned CRITICAL ('high') for NaN; it now rejects the input and returns 'unknown'.
    T('NaN no longer produces a silent CRITICAL: the Lab rejects it first AND the engine itself now returns "unknown" (was "high" before Phase 3)',rws[10][2]=='invalid' and E("evaluateExposure({room:'Cath Lab 1',procMult:1,rate:NaN,dur:30,dist:1,refDist:1,shield:1,mode:'personal'}).riskClass")=='unknown')
    T('A zero reading is valid (deviation −100 %, LOW, 0 dose)',rws[5][1] and rws[5][2]=='low' and rws[5][4]==0)
    T('An extreme but plausible reading (900,000 µSv/h) is accepted and flagged CRITICAL',rws[40][1] and rws[40][2]=='high' and rws[40][3])
    valid_sum=sum(r[6]/60/1000 for r in rws if r[1]); T('Total dose with rejected readings = sum over valid minutes only (lower bound, independent sum)',close(jj['acc'],valid_sum,1e-12))
    T('Invalid readings appear in the timeline',jj['tl']==5)
    # ===== 11. invalid readings interrupt an alert run
    kk=E("""()=>{const inj={0:{23:NaN}};const r=SimLab.run('S3',1,0,{inject:inj});return r.workers[0].episodes.map(e=>[e.runStart,e.runEnd,e.det])}""")
    T('An invalid minute inside an alert run splits it (conservative): episodes [20–22] and [24–29] instead of one run',kk==[[20,22,20],[24,29,24]],str(kk))
    # ===== 12. multi-worker isolation
    base_run=E("SimLab.run('S6',1,0).workers.map(w=>w.rows.map(x=>[x.engineRate,x.riskClass,x.alert,x.accum]))")
    pert=E("""()=>{const inj={0:{20:NaN,21:1e9,22:-1,30:999999}};return SimLab.run('S6',1,0,{inject:inj}).workers.map(w=>w.rows.map(x=>[x.engineRate,x.riskClass,x.alert,x.accum]))}""")
    T('Multi-worker isolation: perturbing worker 1 changes only worker 1; workers 2 and 3 are bit-identical',pert[1]==base_run[1] and pert[2]==base_run[2] and pert[0]!=base_run[0])
    mw=E("SimLab.run('S6',1,0).workers.map(w=>[w.id,w.TP,w.FP,w.FN])")
    T('Per-worker metrics: ST-04 (0,1,0), ST-11 (1,0,0), ST-13 (1,0,0); aggregate equals their sum',mw==[['ST-04',0,1,0],['ST-11',1,0,0],['ST-13',1,0,0]] and E("(()=>{const a=SimLab.run('S6',1,0).agg;return [a.TP,a.FP,a.FN]})()")==[2,1,0])
    # ===== 13. displayed metrics = simulation results = exports
    pg.click('.nav-item[data-view="simlab"]'); pg.click('#slRunAllBtn'); pg.wait_for_timeout(300)
    sm=parse_csv(E("SimLab.summaryCsv()")); cmp=E("[...document.querySelectorAll('#slCmpTbl tbody tr')].map(r=>[...r.cells].map(c=>c.innerText))")
    ok=True
    for i,row in enumerate(sm):
        c=cmp[i]; ok=ok and c[7]==row['TP'] and c[8]==row['FP'] and c[9]==row['FN'] and c[10]==row['TN'] and (c[11]==('n/a' if row['precision']=='' else '%.2f'%float(row['precision']))) and (c[12]==('n/a' if row['recall']=='' else '%.2f'%float(row['recall']))) and (c[13]==('n/a' if row['F1']=='' else '%.2f'%float(row['F1'])))
    T('Comparison table cells (TP, FP, FN, TN, precision, recall, F1) equal the exported summary CSV for all six scenarios',ok)
    vt=E("[...document.querySelectorAll('#slValTbl tbody tr')].map(r=>[...r.cells].map(c=>c.innerText))")
    T('Validation & Results scenario table matches the summary CSV (GT events, TP, FP, FN, F1)',len(vt)==6 and all(vt[i][2]==sm[i]['TP'] and vt[i][3]==sm[i]['FP'] and vt[i][4]==sm[i]['FN'] and vt[i][1]==sm[i]['ground_truth_events'] for i in range(6)))
    pg.click('#slTabs .sl-tab[data-sc="S5"]'); pg.wait_for_timeout(150)
    kv=pg.inner_text('#slKv').replace('\n',' ')
    w=E("(()=>{const w=SimLab.results().S5.workers[0];return [w.TP,w.FP,w.FN,w.TN,w.maxRate.toFixed(1),w.accum.toFixed(4)]})()")
    T('Metric cards on the page equal the simulation result (S5: TP/FP/FN/TN, max rate, dose)',f'{w[0]} / {w[1]} / {w[2]} / {w[3]}' in kv and w[4] in kv and w[5] in kv,kv[:140])
    st=parse_csv(E("SimLab.stepsCsv()")); acc=sum(float(r['step_dose_mSv']) for r in st if r['scenario']=='S5')
    T('Exported accumulated dose (last row) equals the sum of exported step doses (S5)',close(float([r for r in st if r['scenario']=='S5'][-1]['accumulated_dose_mSv']),acc,1e-7))
    T('Summary CSV max dose equals the CSV step-dose sum for each single-worker scenario',all(close(float(r['max_worker_accumulated_dose_mSv']),sum(float(x['step_dose_mSv']) for x in st if x['scenario']==r['scenario']),2e-6) for r in sm if r['workers']=='1'))
    with pg.expect_download() as dl: pg.click('text=Export summary (CSV)')
    T('Downloaded summary file equals the in-page summary CSV',open(dl.value.path(),encoding='utf-8').read()==E("SimLab.summaryCsv()"))
    with pg.expect_download() as dl: pg.click('text=Download simulation report')
    rep=open(dl.value.path(),encoding='utf-8').read(); res_s5=E("SimLab.results().S5.agg")
    T('Report table row for scenario 5 shows the same TP/FP/FN/TN/precision/F1 as the results',re.search(r'\| 5 Short transient spike[^\n]*\| %d \| %d \| %d \| %d \| %s \| %s \| %s \|'%(res_s5['TP'],res_s5['FP'],res_s5['FN'],res_s5['TN'],'0.00','n/a','0.00'),rep) is not None)
    # ===== 14. charts vs data vs tables
    pg.click('#slTabs .sl-tab[data-sc="S2"]'); pg.wait_for_timeout(200)
    r2=E("(()=>{const w=SimLab.results().S2.workers[0];return {n:w.rows.length,imax:w.rows.reduce((m,x,i)=>x.engineRate>w.rows[m].engineRate?i:m,0),eps:w.episodes.length,fl:w.rows.filter(x=>x.flagged).length}})()")
    ch=E("""(()=>{const svg=document.querySelectorAll('#slResults .sl-chart svg')[0];const pts=[...svg.querySelector('path').getAttribute('d').matchAll(/[ML]([\\d.]+) ([\\d.]+)/g)].map(m=>[+m[1],+m[2]]);
      const tri=[...svg.querySelectorAll('path')].filter(p=>(p.getAttribute('d')||'').startsWith('M')&&/Z/.test(p.getAttribute('d'))).length;let imin=0;pts.forEach((p,i)=>{if(p[1]<pts[imin][1]) imin=i});return {n:pts.length,imin,tri}})()""")
    T('Dose-rate chart: one vertex per simulated minute, its highest vertex is the run\'s maximum-rate minute, one ▲ per alert',ch['n']==r2['n'] and ch['imin']==r2['imax'] and ch['tri']==r2['eps'],str(ch))
    c3=E("""(()=>{const svg=document.querySelectorAll('#slResults .sl-chart svg')[2];return svg.querySelectorAll('circle[style*="fill:var(--red)"], circle[style*="fill:var(--amber)"]').length})()""")
    T('Threshold chart: number of flagged-minute dots equals the number of flagged rows',c3==r2['fl'],f'{c3} vs {r2["fl"]}')
    c4=E("""(()=>{const svg=document.querySelectorAll('#slResults .sl-chart svg')[3];return svg.querySelectorAll('rect').length})()""")
    T('Expected-vs-detected chart: bars = labelled events + alert episodes',c4==1+r2['eps'])
    c2=E("""(()=>{const svg=document.querySelectorAll('#slResults .sl-chart svg')[1];const pts=[...svg.querySelector('path').getAttribute('d').matchAll(/[ML]([\\d.]+) ([\\d.]+)/g)].map(m=>+m[2]);let mono=true;for(let i=1;i<pts.length;i++) if(pts[i]>pts[i-1]+1e-6) mono=false;return [pts.length,mono]})()""")
    T('Accumulated-dose chart is monotonically non-decreasing with 60 points',c2[0]==60 and c2[1] is True)
    ov=pg.locator('#slValCard .sl-chart svg').count(); T('Validation section charts (overview, latency) are drawn from the runs',ov>=2)
    # ===== 15. sensitivity analysis
    pg.click('#slSweepBtn'); pg.wait_for_function("SimLab.sweepState()!==null",timeout=60000); pg.wait_for_timeout(300)
    sw=E("(()=>{const s=SimLab.sweepState();return {cells:s.cells.length,runs:s.runs.length}})()")
    T('Sensitivity grid size: 9 scenarios × 3 thresholds × 4 confirmations × 4 noise conditions = 432 cells, × 20 seeds = 8,640 runs',sw['cells']==432 and sw['runs']==8640,str(sw))
    gcsv=parse_csv(E("SimLab.sweepCsv()")); rcsv=parse_csv(E("SimLab.sweepRunsCsv()"))
    ok=True
    bycell={}
    for r in rcsv: bycell.setdefault((r['scenario'],r['dev_elevated'],r['confirmation_min'],r['noise_id']),[]).append(r)
    for c in gcsv:
        rs=bycell[(c['scenario'],c['dev_elevated'],c['confirmation_min'],c['noise_id'])]
        TP=sum(int(x['TP']) for x in rs);FP=sum(int(x['FP']) for x in rs);FN=sum(int(x['FN']) for x in rs);TN=sum(int(x['TN']) for x in rs);ev=sum(int(x['ground_truth_events']) for x in rs)
        P,Rr,F=py_metrics(TP,FP,FN)
        ok=ok and (int(c['TP']),int(c['FP']),int(c['FN']),int(c['TN']),int(c['ground_truth_events']))==(TP,FP,FN,TN,ev) and len(rs)==20 and ((c['pooled_precision']=='')==(P is None)) and (P is None or close(float(c['pooled_precision']),P,1e-4)) and (F is None or close(float(c['pooled_F1']),F,1e-4))
    T('Grid CSV re-aggregates exactly from the per-run CSV (independent Python pooling of TP/FP/FN/TN, precision, F1)',ok)
    one=E("""(()=>{let TP=0,FP=0,FN=0;for(let o=0;o<20;o++){const a=SimLab.run('S5',2,o,{noiseModel:'gaussian',noiseLevel:0.10},{devElevated:0.25,devCritical:1.5}).agg;TP+=a.TP;FP+=a.FP;FN+=a.FN}const c=SimLab.sweepState().cells.find(c=>c.sc==='S5'&&c.devElev===0.25&&c.K===2&&c.noise==='G10');return [TP,FP,FN,c.TP,c.FP,c.FN]})()""")
    T('Spot check: a grid cell equals 20 independent direct runs with the same parameters',one[:3]==one[3:],str(one))
    st1=E("[CONFIG.devElevated,CONFIG.devCritical,CONFIG.doseElevated,CONFIG.doseCritical]"); T('Sweep leaves the live thresholds (CONFIG) untouched',st1==[0.5,1.5,0.15,0.35])
    T('Sweep does not alter stored scenario results or the rest of the app',len(E("Object.keys(SimLab.results())"))==6 and E("snapshotWorld()")==E("WORLD0"))
    h1=hashlib.sha256(E("SimLab.sweepCsv()").encode()).hexdigest(); E("SimLab.sweep()"); h2=hashlib.sha256(E("SimLab.sweepCsv()").encode()).hexdigest()
    T('Sensitivity analysis is reproducible: re-running gives a byte-identical grid CSV',h1==h2)
    rowsA=pg.locator('#slValCard h4:has-text("A · Default") + .sl-tw tbody tr').count(); rowsB=pg.locator('#slValCard h4:has-text("B · Detection threshold") + .sl-tw tbody tr').count()
    rowsC=pg.locator('#slValCard h4:has-text("C · Alert confirmation") + .sl-tw tbody tr').count(); rowsD=pg.locator('#slValCard h4:has-text("D · Noise level") + .sl-tw tbody tr').count()
    T('Sensitivity tables A–D rendered with 9, 27, 36 and 36 rows (all scenarios, all levels, favourable or not)',(rowsA,rowsB,rowsC,rowsD)==(9,27,36,36),str((rowsA,rowsB,rowsC,rowsD)))
    # unfavourable results are visible: find a cell with FN>0 and one with FP>0 in the page table
    hasFN=E("SimLab.sweepState().cells.some(c=>c.FN>0)"); hasFP=E("SimLab.sweepState().cells.some(c=>c.FP>0)")
    T('Grid reports unfavourable configurations too (cells with missed events and with false alarms exist)',hasFN and hasFP)
    rngchk=E("(()=>{const a=SimLab.run('S5',1,3,{noiseModel:'gaussian',noiseLevel:0.2}).fingerprint,b=SimLab.run('S5',1,4,{noiseModel:'gaussian',noiseLevel:0.2}).fingerprint;return a!==b})()")
    T('Different seeds give different noise realisations (Gaussian σ 20 %)',rngchk)
    gs=E("(()=>{const r=SimLab.pure.rng(123);const v=[];for(let i=0;i<20000;i++)v.push(SimLab.pure.noiseFactor(r,'gaussian',0.1));const m=v.reduce((a,b)=>a+b,0)/v.length;const sd=Math.sqrt(v.reduce((a,b)=>a+(b-m)**2,0)/v.length);return [m,sd,Math.min(...v)]})()")
    T('Gaussian noise factor has mean ≈1, σ ≈ requested level (0.10) and is never negative',abs(gs[0]-1)<0.01 and abs(gs[1]-0.10)<0.01 and gs[2]>=0,str(gs))
    un=E("(()=>{const r=SimLab.pure.rng(9);let mn=9,mx=0;for(let i=0;i<20000;i++){const v=SimLab.pure.noiseFactor(r,'uniform',0.05);mn=Math.min(mn,v);mx=Math.max(mx,v)}return [mn,mx]})()")
    T('Uniform ±5 % noise stays within [0.95, 1.05]',un[0]>=0.95-1e-12 and un[1]<=1.05+1e-12)
    # ===== 16. reset / rerun
    E("SimLab.runAll()"); fpA=E("SimLab.overallFp()"); pg.click('#slResetBtn'); pg.wait_for_timeout(150)
    T('Reset Lab clears results, sensitivity data, form fields; Validation section returns to its empty state',E("Object.keys(SimLab.results()).length")==0 and E("SimLab.sweepState()")is None and 'Not run yet' in pg.inner_text('#slValCard') and pg.input_value('#slSeed')=='0')
    pg.click('#slRunAllBtn'); T('Rerun after reset reproduces the earlier overall fingerprint and metrics',E("SimLab.overallFp()")==fpA)
    E("SimLab.run('S2',1,0)"); a1=E("SimLab.results().S2.workers[0].accum"); E("SimLab.run('S2',1,0)"); a2=E("SimLab.results().S2.workers[0].accum")
    T('Cumulative dose is re-initialised to zero on every run (re-running does not accumulate)',a1==a2 and E("SimLab.results().S2.workers[0].rows[0].accum")==E("SimLab.results().S2.workers[0].rows[0].stepDose"))
    # ===== 17. UI input validation
    ok=True
    for badv in ['1.5','-1','100000','']:
        pg.fill('#slSeed',badv); pg.click('#slRunBtn'); ok=ok and ('whole number' in pg.inner_text('#slFormErr'))
    pg.fill('#slSeed','99999'); pg.click('#slRunBtn'); ok2=pg.inner_text('#slFormErr')==''; pg.fill('#slSeed','0'); pg.click('#slRunBtn')
    T('Seed offset validation: 1.5, −1, 100000, empty rejected; 99999 accepted',ok and ok2)
    # ===== 18. Validation & Results section content
    pg.click('#slRunAllBtn'); pg.wait_for_timeout(200)
    vt=pg.text_content('#slValCard')
    for k in ['Verified computational correctness','Simulation performance','Real-world clinical performance','NOT ESTABLISHED','Evaluation unit: the event','one-to-one','never</b> a valid detection' if False else 'never a valid detection','F1 = 2TP/(2TP+FP+FN)','n/a','Latency:','Test execution status','Scientific limitations','Reproducibility','Sensitivity and robustness','IMPLEMENTED','FUTURE WORK','SIMULATED','NOT ESTABLISHED','not machine learning','no real hardware']:
        T(f'Validation section states: "{k}"',k.lower() in vt.lower())
    T('Evaluation explanation is visible without expanding anything (not inside a closed <details>)',pg.locator('#slValCard h4:has-text("How detection is evaluated")').is_visible() and pg.locator('#slValCard p:has-text("Evaluation unit")').is_visible())
    st=E("typeof SL_TEST_STATUS!=='undefined'&&SL_TEST_STATUS")
    if st:
        rowsT=E("[...document.querySelectorAll('#slValCard h4')].find(h=>h.textContent.includes('Test execution')).nextElementSibling.querySelectorAll('tbody tr').length")
        T('Embedded test-status table lists every suite plus a total row',rowsT==len(st['suites'])+1 and st['failed']==0)
        T('Embedded totals are internally consistent (sum of suites)',sum(s['total'] for s in st['suites'])==st['total'] and sum(s['passed'] for s in st['suites'])==st['passed'])
    else:
        T('Test status block present (null build)',True,'status not embedded in this build pass')
    # ===== 19. claims audit
    allv=E("[...document.querySelectorAll('.view')].map(v=>v.textContent.replace(/\\s+/g,' ')).join(' ')+' '+document.querySelector('.sidebar, aside, nav').textContent.replace(/\\s+/g,' ')")
    T('Claims audit: "AI risk detection" no longer appears (dashboard now says rule-based risk detection)','AI risk detection' not in allv and 'rule-based risk detection' in allv)
    T('Claims audit: no "AI-Powered" claim remains in the sidebar','AI-Powered' not in allv and 'AI-ready Radiation Safety Concept' in allv)
    T('Claims audit: AI Recommendations page is tagged RULE-BASED TEMPLATES','RULE-BASED TEMPLATES' in allv)
    T('Claims audit: Policy Mapping states "no trained model" and the security flow says rule-based','no trained model' in allv and 'prototype: rule-based risk + linear forecast' in allv)
    bad=[]
    for m_ in re.finditer(r'(clinically validated|clinically proven|regulatory[- ]compliant|certified|FDA|NRRC[- ]approved|SDAIA[- ]approved|trained model|machine learning model|deep learning)',allv,re.I):
        ctx=allv[max(0,m_.start()-70):m_.end()+20].lower()
        if not re.search(r"\bnot\b|\bno\b|n't|never|without|future|would|nor |isn|isn't|claim|rather than|does not|cannot|can't",ctx): bad.append(allv[max(0,m_.start()-60):m_.end()+20])
    T('Claims audit: every mention of validated/certified/compliant/trained-model terms is negated or marked future work',len(bad)==0,str(bad[:3]))
    # ===== 20. navigation + mobile
    views=pg.eval_on_selector_all('.nav-item','e=>e.map(x=>x.dataset.view)'); ok=True
    for v in views:
        pg.click(f'.nav-item[data-view="{v}"]'); ok=ok and pg.locator(f'#view-{v}.active').count()==1
    T('Navigation: all 13 views open (Simulation Lab included)',ok and len(views)==13)
    pg.click('.nav-item[data-view="simlab"]'); pg.set_viewport_size({'width':390,'height':800}); pg.wait_for_timeout(300)
    T('Mobile 390 px: Simulation Lab incl. Validation section has no horizontal page overflow',E("document.documentElement.scrollWidth")<=392,str(E("document.documentElement.scrollWidth")))
    pg.evaluate("document.getElementById('slValCard').scrollIntoView()"); pg.screenshot(path='/tmp/val_mobile.png')
    wide=E("[...document.querySelectorAll('#slValCard table')].every(t=>t.closest('.sl-tw'))")
    T('All Validation tables sit inside horizontally scrolling wrappers',wide is True)
    pg.set_viewport_size({'width':1400,'height':1000})
    nol=E("[...document.querySelectorAll('#view-simlab input,#view-simlab select')].filter(e=>!(document.querySelector('label[for=\"'+e.id+'\"]'))).map(e=>e.id)")
    T('All Lab inputs/selects are labelled',nol==[],str(nol))
    T('Charts in the Validation section have accessible names',E("[...document.querySelectorAll('#slValCard svg')].every(s=>s.getAttribute('role')==='img'&&s.getAttribute('aria-label'))") is True)
    b.close()
finally:
    srv1.terminate(); srv2.terminate()
T('No JavaScript errors / console errors / dialogs during the whole validation run',len(errs)==0,str(errs[:5]))
json.dump(R,open(ROOT+'/logs/results_validation_v2.json','w'))
print('\n',sum(1 for r in R if r[1]=='PASS'),'passed,',sum(1 for r in R if r[1]=='FAIL'),'failed')


# ---- exit-code footer (M-01): added in the Final Candidate; no assertion changed
import sys as _sys
_sys.exit(1 if any(r[1]=='FAIL' for r in R) else 0)
