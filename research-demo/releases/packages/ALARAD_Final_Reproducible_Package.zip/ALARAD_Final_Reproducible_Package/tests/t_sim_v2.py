import os as _os
ROOT=_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))   # package root: all paths are relative to it
import subprocess,time,json,re,csv,io
from playwright.sync_api import sync_playwright
srv=subprocess.Popen(['python3','-m','http.server','8783','-d',ROOT+'/env/new'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);time.sleep(1)
R=[];errs=[]
def T(name,cond,detail=''):
    R.append((name,'PASS' if cond else 'FAIL',detail)); print(('PASS' if cond else 'FAIL'),'-',name,detail)
def close(a,b,tol=1e-9): return abs(a-b)<=tol
try:
  with sync_playwright() as p:
    b=p.chromium.launch(args=['--no-sandbox']); ctx=b.new_context(viewport={'width':1400,'height':1000},accept_downloads=True); pg=ctx.new_page()
    pg.on('pageerror',lambda e:errs.append('PAGEERROR '+str(e)))
    pg.on('console',lambda m: errs.append('CONSOLE '+m.text) if m.type=='error' and 'ERR_TUNNEL' not in m.text and 'font' not in m.text.lower() else None)
    pg.on('dialog',lambda d:(errs.append('DIALOG '+d.message),d.dismiss()))
    pg.goto('http://localhost:8783/alarad_prototype.html'); pg.wait_for_timeout(400)
    E=lambda js:pg.evaluate(js)
    # ---------- navigation
    T('Nav item "Simulation Lab" exists',pg.locator('.nav-item[data-view="simlab"]').count()==1)
    pg.click('.nav-item[data-view="simlab"]')
    T('Simulation Lab view opens and is marked current',pg.locator('#view-simlab.active').count()==1 and pg.get_attribute('.nav-item[data-view="simlab"]','aria-current')=='page')
    pg.click('.nav-item[data-view="dashboard"]'); pg.focus('.nav-item[data-view="simlab"]'); pg.keyboard.press('Enter')
    T('Simulation Lab opens from the keyboard (Enter)',pg.locator('#view-simlab.active').count()==1)
    views=pg.eval_on_selector_all('.nav-item','e=>e.map(x=>x.dataset.view)'); ok=True
    for v in views:
        pg.click(f'.nav-item[data-view="{v}"]'); ok=ok and pg.locator(f'#view-{v}.active').count()==1
    T('All 13 views still open from the nav (incl. all 12 original)',ok and len(views)==13 and 'livedemo' in views)
    pg.click('.nav-item[data-view="simlab"]')
    T('Six scenario tabs are listed',pg.locator('#slTabs .sl-tab').count()==6)
    T('Before any run: results area states nothing is shown, comparison says "not run" x6',('Nothing is shown until real simulation output exists' in pg.inner_text('#slResults')) and pg.inner_text('#slCompare').count('not run')==6)
    txt=pg.text_content('#view-simlab')
    for k in ['SIMULATED DATA ONLY','not a validated AI model','RSO review remains the human decision point','Inverse-square scaling is only a limited point-source approximation','Dose (mSv) = Dose Rate (µSv/h) × Duration (h) / 1000','No hospital testing','annual cumulative dose is not','not regulatory dose limits']:
        T(f'Lab page states "{k}"',k.lower() in txt.lower().replace('\n',' '))
    # ---------- calculations
    world0=E('snapshotWorld()'); badge0=pg.inner_text('#alertCountBadge')
    pg.click('#slRunAllBtn'); pg.wait_for_timeout(300)
    res=E("""()=>{const R=SimLab.results();const o={};for(const k in R){const r=R[k];o[k]={seed:r.seed,K:r.K,fp:r.fingerprint,match:r.match,agg:r.agg,w:r.workers.map(w=>({id:w.id,TP:w.TP,FP:w.FP,FN:w.FN,TN:w.TN,sup:w.suppressed,pred:w.preds.length,predOut:w.predOutside,eps:w.episodes.length,ev:w.events.map(e=>({m:e.matched,d:e.delay,det:e.det})),tl:w.timeline.map(x=>x.c+'|'+x.m),acc:w.accum,macc:w.measAccum,rows:w.rows.map(x=>({t:x.t,k:x.kind,er:x.engineRate,me:x.measured,mo:x.modeled,sd:x.stepDose,ac:x.accum,al:x.alert,fl:x.flagged,pc:x.projDose,rc:x.riskClass,b:x.baseline,dist:x.dist}))}))}}return o}""")
    sd_ok=all(close(x['sd'],x['er']*(1/60)/1000,1e-12) for k in res for w in res[k]['w'] for x in w['rows'])
    T('Step dose = rate (µSv/h) × duration (h) / 1000 on all 480 simulated rows',sd_ok)
    acc_ok=all(close(w['acc'],sum(x['sd'] for x in w['rows']),1e-9) for k in res for w in res[k]['w'])
    T('Accumulated dose equals the sum of step doses',acc_ok)
    T('Independent hand calculation: 600 µSv/h for 0.5 h = 0.300 mSv (engine projection)',close(E("evaluateExposure({room:'Cath Lab 1',procMult:1,rate:600,dur:30,mode:'personal'}).cumulativeDose"),0.3,1e-12))
    T('S1 final dose matches independent sum (60 × rate/60/1000)',close(res['S1']['w'][0]['acc'],sum(x['er'] for x in res['S1']['w'][0]['rows'])/60/1000,1e-12))
    # engine reuse: count calls + identical output
    cnt=E("""()=>{const orig=window.evaluateExposure;let n=0;window.evaluateExposure=function(a){n++;return orig(a)};SimLab.run('S6',1,0);window.evaluateExposure=orig;return n}""")
    T('Lab calls the existing evaluateExposure() once per worker-minute (S6: 3×60=180)',cnt==180,str(cnt))
    same=E("""()=>{const r=SimLab.results().S3.w?0:0;const R=SimLab.run('S3',1,0).workers[0].rows[25];const e=evaluateExposure({room:'Cath Lab 3',procMult:1,rate:R.engineRate,dur:30,dist:1,refDist:1,shield:1,mode:'personal'});return e.riskClass===R.riskClass&&Math.abs(e.deviation-R.deviation)<1e-12}""")
    T('Lab row risk class and deviation equal a direct engine call on the same input',same is True)
    E("SimLab.runAll()")
    T('Measured vs modeled kept apart: S4 engine input is MODELED, personal series is separate',res['S4']['w'][0]['rows'][5]['k']=='modeled' and res['S4']['w'][0]['rows'][5]['mo'] is not None and abs(res['S4']['w'][0]['rows'][30]['me']-res['S4']['w'][0]['rows'][30]['mo'])>1)
    T('Other scenarios use MEASURED personal readings with no modeled value',all(res[k]['w'][0]['rows'][5]['k']=='measured' and res[k]['w'][0]['rows'][5]['mo'] is None for k in ['S1','S2','S3','S5']))
    r4=res['S4']['w'][0]['rows']; base=r4[0]['b']
    T('S4 modeled estimate = monitor × (1.0 m ÷ 2.5 m)² after relocation (within noise)',abs(r4[40]['mo']/(base*4)-0.16)<0.16*0.07,f"{r4[40]['mo']/(base*4):.3f}")
    T('S4: simulated measured dose exceeds the modeled estimate (inverse-square under-estimates by design)',res['S4']['w'][0]['macc']>res['S4']['w'][0]['acc'])
    # ---------- scenario results
    a=lambda k:res[k]['agg']
    T('S1 normal: 0 alerts, TP/FP/FN=0, TN=6, precision & recall undefined (null)',a('S1')['TP']==0 and a('S1')['FP']==0 and a('S1')['FN']==0 and a('S1')['TN']==6 and a('S1')['precision'] is None and a('S1')['recall'] is None and res['S1']['w'][0]['eps']==0)
    T('S2 gradual: 1 TP, detection delay > 0 and < event length',a('S2')['TP']==1 and 0<a('S2')['delayFirst']<35,f"delay={a('S2')['delayFirst']}")
    T('S2 first abnormal=15, first detection=21',a('S2')['firstAbnormal']==15 and a('S2')['firstDetection']==21)
    T('S3 sudden: 1 TP with detection delay 0',a('S3')['TP']==1 and a('S3')['delayFirst']==0)
    T('S4 relocation: 1 TP; alerts clear after relocation (no alert rows after T+25)',a('S4')['TP']==1 and not any(x['al'] for x in r4 if x['t']>=25))
    T('S5 transient (confirmation 1): 0 TP, 2 FP, precision 0.0, recall undefined',a('S5')['TP']==0 and a('S5')['FP']==2 and a('S5')['precision']==0 and a('S5')['recall'] is None)
    T('S6 multiple workers: 3 workers, aggregate 2 TP / 1 FP / 0 FN',len(res['S6']['w'])==3 and a('S6')['TP']==2 and a('S6')['FP']==1 and a('S6')['FN']==0)
    T('S6 per-worker patterns differ (ST-04 FP only; ST-11 and ST-13 TP)',[ (w['TP'],w['FP']) for w in res['S6']['w']]==[(0,1),(1,0),(1,0)])
    T('S6 precision = 2/3 and recall = 1',close(a('S6')['precision'],2/3) and a('S6')['recall']==1)
    T('All six results meet their documented expectation at confirmation 1',all(res[k]['match'] is True for k in res))
    r=E("""()=>{const o={};['S3','S5'].forEach(id=>{const s=SimLab.run(id,3,0);o[id]={FP:s.agg.FP,TP:s.agg.TP,d:s.agg.delayFirst,sup:s.workers[0].suppressed,match:s.match}});return o}""")
    T('False-alarm test: confirmation 3 suppresses both S5 spikes (FP 0, 2 flags suppressed)',r['S5']['FP']==0 and r['S5']['sup']==2)
    T('Confirmation 3 delays S3 detection by exactly 2 minutes',r['S3']['TP']==1 and r['S3']['d']==2)
    T('Documented expectation is reported as not applicable when confirmation ≠ 1',r['S3']['match'] is None)
    tl=' '.join(res['S5']['w'][0]['tl'])
    T('Timeline separates PREDICTION, DETECTION, ALERT and RSO REVIEW entries',all(k in tl for k in ['t-pred','t-det','t-alert','t-rso']) and 'not simulated' in tl)
    T('Predictions are listed but not counted in the confusion matrix (S5: 2 flags, TP+FP still 2)',res['S5']['w'][0]['pred']==2 and a('S5')['TP']+a('S5')['FP']==2)
    T('Incident response is not simulated: Lab created no incidents/alerts (world snapshot and badge unchanged)',E('snapshotWorld()')==world0 and pg.inner_text('#alertCountBadge')==badge0)
    # ---------- config linkage
    d=E("""()=>{const a=SimLab.run('S2',1,0).agg.delayFirst;CONFIG.devElevated=2.5;const b=SimLab.run('S2',1,0).agg.delayFirst;CONFIG.devElevated=CONFIG_DEFAULT.devElevated;const c=SimLab.run('S2',1,0).agg.delayFirst;return [a,b,c]}""")
    T('Lab follows the live CONFIG thresholds (raising the elevated threshold delays detection; restored afterwards)',d[1]>d[0] and d[2]==d[0],str(d))
    # ---------- reproducibility
    rp=E("""()=>{const x=SimLab.run('S3',1,0),y=SimLab.run('S3',1,0),z=SimLab.run('S3',1,7);SimLab.runAll();const f1=SimLab.overallFp();SimLab.runAll();const f2=SimLab.overallFp();return {same:x.fingerprint===y.fingerprint&&JSON.stringify(x.workers[0].rows)===JSON.stringify(y.workers[0].rows),diff:x.fingerprint!==z.fingerprint,all:f1===f2,seeds:SimLab.SCEN.map(s=>s.seed)}}""")
    T('Same seed twice → identical rows and fingerprint',rp['same'])
    T('Different seed offset → different fingerprint',rp['diff'])
    T('Running all six twice → identical overall fingerprint',rp['all'])
    T('Documented fixed seeds 20260601…20260606',rp['seeds']==[20260601+i for i in range(6)])
    pg.fill('#slSeed','0'); pg.select_option('#slK','1'); pg.click('#slRunAllBtn')
    fpA=E('SimLab.overallFp()'); pg.reload(); pg.wait_for_timeout(400); pg.click('.nav-item[data-view="simlab"]'); pg.click('#slRunAllBtn'); fpB=E('SimLab.overallFp()')
    T('Fingerprint identical after a full page reload (cross-session reproducibility)',fpA==fpB,fpA)
    # ---------- charts / tables from real output
    pg.click('#slTabs .sl-tab[data-sc="S2"]'); pg.click('#slRunBtn'); pg.wait_for_timeout(200)
    T('Four scientific charts rendered for the selected scenario',pg.locator('#slResults .sl-chart svg').count()==4)
    dpts=E("[...document.querySelectorAll('#slResults .sl-chart svg')][0].querySelector('path').getAttribute('d').split(/(?=[ML])/).length")
    T('Dose-rate chart path has one vertex per simulated minute (60), i.e. it is drawn from the run output',dpts==60,str(dpts))
    heads=pg.inner_text('#slResults .sl-chart >> nth=0')+pg.inner_text('#slResults .sl-chart >> nth=1')+pg.inner_text('#slResults .sl-chart >> nth=2')+pg.inner_text('#slResults .sl-chart >> nth=3')
    for k in ['Dose rate vs. time','Accumulated dose vs. time','Detection thresholds and alert events','Expected vs. detected events']: T(f'Chart present: {k}',k in heads)
    T('Accumulated-dose chart carries no annual-limit line and says so',('annual' in heads.lower()) and 'not an instantaneous threshold' in heads)
    cmp=E("[...document.querySelectorAll('#slCmpTbl tbody tr')].map(r=>[...r.cells].map(c=>c.innerText))")
    T('Comparison table lists all six scenarios with 16 columns (F1 added)',len(cmp)==6 and all(len(r)==16 for r in cmp))
    T('Comparison table values equal the run output (S5: FP=2, S6: TP=2)',cmp[4][8]=='2' and cmp[5][7]=='2' and cmp[1][6]=='6 min',str(cmp[4]))
    # multi-worker view
    pg.click('#slTabs .sl-tab[data-sc="S6"]'); pg.click('#slRunBtn'); pg.click('#slResults .sl-wk .sl-tab >> nth=2'); pg.wait_for_timeout(150)
    T('Multi-worker scenario offers per-worker views',pg.locator('#slResults .sl-wk .sl-tab').count()==3 and 'ST-13' in pg.inner_text('#slResults'))
    # ---------- exports
    with pg.expect_download() as dl: pg.click('text=Export step data (CSV)')
    d1=dl.value; p1=d1.path(); body=open(p1,encoding='utf-8').read()
    rows=list(csv.reader(io.StringIO(body)))
    T('Step CSV downloads with header + 480 data rows × 21 columns (reading_valid, dt_min added)',d1.suggested_filename=='alarad_simlab_steps.csv' and len(rows)==481 and all(len(r)==21 for r in rows),f'{len(rows)-1} rows')
    s2=[r for r in rows if r[0]=='S2' and r[2]=='30'][0]
    T('CSV row equals simulation state (S2, t=30 engine rate)',close(float(s2[7]),E("SimLab.results().S2.workers[0].rows[30].engineRate"),1e-5))
    T('CSV marks ground truth, reading kind and keeps measured/modeled in separate columns',rows[0][4]=='ground_truth_abnormal' and 'modeled_area_estimate_uSv_h' in rows[0] and 'measured_personal_rate_uSv_h' in rows[0])
    with pg.expect_download() as dl: pg.click('text=Export summary (CSV)')
    d2=dl.value; srows=list(csv.reader(io.StringIO(open(d2.path(),encoding='utf-8').read())))
    T('Summary CSV: header + 6 scenario rows incl. fingerprint',len(srows)==7 and srows[0][-1]=='fingerprint' and all(len(r[-1])==8 for r in srows[1:]))
    with pg.expect_download() as dl: pg.click('text=Download simulation report')
    d3=dl.value; rep=open(d3.path(),encoding='utf-8').read()
    T('Report downloads as .md',d3.suggested_filename=='alarad_simlab_report.md')
    for k in ['## 1. Parameters','## 2. Calculation methods','## 3. Event-level evaluation rules','## 4. Results','## 6. Limitations','## 7. Reproducibility','ALL DATA IN THIS REPORT IS SIMULATED','Dose (mSv) = Dose Rate (µSv/h) × Duration (h) / 1000','limited point-source approximation','not regulatory limits','RSO review remains the human decision point','mulberry32','20260602']:
        T(f'Report contains "{k}"',k.lower() in rep.lower())
    T('Report states no clinical accuracy / validated AI / compliance claim',('does not show clinical accuracy, a validated AI model, or regulatory compliance' in rep))
    # ---------- validation
    keep=E("Object.keys(SimLab.results()).length")
    ok=True
    for bad in ['1.5','-1','100000','']:
        pg.fill('#slSeed',bad); pg.click('#slRunBtn'); ok=ok and ('whole number' in pg.inner_text('#slFormErr'))
    T('Invalid seed offsets (1.5, -1, 100000, empty) rejected with a message; results unchanged',ok and E("Object.keys(SimLab.results()).length")==keep)
    pg.fill('#slSeed','5'); pg.click('#slRunBtn'); T('Valid seed offset accepted and shown (seed 20260602+5 = 20260607 shown in results)',pg.inner_text('#slFormErr')=='' )
    # ---------- reset behaviour
    pg.click('#slResetBtn'); pg.wait_for_timeout(150)
    T('Reset Lab clears all results, form fields and comparison',E("Object.keys(SimLab.results()).length")==0 and pg.input_value('#slSeed')=='0' and pg.input_value('#slK')=='1' and pg.inner_text('#slCompare').count('not run')==6 and 'Nothing is shown' in pg.inner_text('#slResults'))
    T('Reset Lab leaves the rest of the app untouched',E('snapshotWorld()')==world0)
    pg.click('text=Export summary (CSV)'); pg.wait_for_timeout(300)
    T('Export with no results shows a notice instead of an empty file',E("SimLab.report()")=='' and 'nothing to export' in pg.inner_text('#toastHost').lower())
    pg.click('#slRunAllBtn'); fpC=E('SimLab.overallFp()')
    T('After Lab reset a re-run reproduces the earlier fingerprint',fpC==fpA)
    # reset demo interplay
    E("startLiveDemo()"); pg.wait_for_timeout(300); E("resetLiveDemo(false)"); pg.wait_for_timeout(200)
    T('Reset Demo still restores the world after Lab use and does not wipe Lab results (independent states)',E('snapshotWorld()')==world0 and E("Object.keys(SimLab.results()).length")==6)
    # ---------- mobile
    pg.set_viewport_size({'width':390,'height':800}); pg.click('.nav-item[data-view="simlab"]'); pg.wait_for_timeout(200)
    T('Mobile 390px: Simulation Lab has no horizontal page overflow',E("document.documentElement.scrollWidth")<=392,str(E("document.documentElement.scrollWidth")))
    pg.set_viewport_size({'width':1400,'height':1000})
    pg.click('#slTabs .sl-tab[data-sc="S4"]'); pg.click('#slRunBtn'); pg.wait_for_timeout(200)
    nol=E("[...document.querySelectorAll('#view-simlab input,#view-simlab select')].filter(e=>!(document.querySelector('label[for=\"'+e.id+'\"]'))).map(e=>e.id)")
    T('Lab inputs/selects are labelled',nol==[],str(nol))
    T('Charts have accessible names and tabs/lists have aria labels',E("[...document.querySelectorAll('#slResults .sl-chart svg')].every(s=>s.getAttribute('role')==='img'&&s.getAttribute('aria-label'))") is True)
    T('No Arabic text in the Lab UI',re.search('[؀-ۿ]',pg.inner_text('#view-simlab')) is None)
    b.close()
finally: srv.terminate()
T('No JavaScript errors / console errors / dialogs during the whole Lab test run',len(errs)==0,str(errs[:5]))
json.dump(R,open(ROOT+'/logs/results_sim.json','w'))
print('\n',sum(1 for r in R if r[1]=='PASS'),'passed,',sum(1 for r in R if r[1]=='FAIL'),'failed')


# ---- exit-code footer (M-01): added in the Final Candidate; no assertion changed
import sys as _sys
_sys.exit(1 if any(r[1]=='FAIL' for r in R) else 0)
