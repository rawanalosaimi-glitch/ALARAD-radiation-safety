import os as _os
ROOT=_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))   # package root: all paths are relative to it
"""Phase-3 suite: safety hardening. References are hand tables and a separate Python implementation written from the documented specification."""
import subprocess,time,json,re,csv,io,math,random,hashlib
from playwright.sync_api import sync_playwright
PN,PO=8831,8832
S=ROOT+'/'
srv1=subprocess.Popen(['python3','-m','http.server',str(PN),'-d',ROOT+'/env/new'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
srv2=subprocess.Popen(['python3','-m','http.server',str(PO),'-d',ROOT+'/env/p2'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
time.sleep(1)
R=[];errs=[]
def T(name,cond,detail=''):
    R.append((name,'PASS' if cond else 'FAIL',detail)); print(('PASS' if cond else 'FAIL'),'-',name,detail)
def close(a,b,tol=1e-9): return abs(a-b)<=tol
# ---------- independent python references ----------
BASE={'Cath Lab 1':90,'Cath Lab 2':85,'Cath Lab 3':92,'Fluoroscopy Suite':70,'Nuclear Medicine':35,'PET/CT Suite':45,'CT Suite':55}
def py_class(rate,room,pm,dur,de=0.5,dc=1.5,doe=0.15,doc=0.35):
    base=BASE[room]*pm; dev=(rate-base)/base; dose=rate*(dur/60)/1000
    if dev<de and dose<doe: return 'low'
    if dev<dc and dose<doc: return 'med'
    return 'high'
def ref_sensor(seq,P=dict(stale=2,disc=5,frozen=6,exit=2,rec=2,res=0.1)):
    """seq: list of None | (ts,value) with value float or 'bad'. returns [(state,usable,uncertain)]"""
    st='HEALTHY'; lastTs=None; lastGoodT=None; lastVal=None; same=0; rec=0; chg=0; out=[]
    q=lambda x:round(x/P['res'])
    for t,o in enumerate(seq):
        usable=False;unc=False
        if o is None:
            age=(t+1) if lastGoodT is None else t-lastGoodT
            ns='DISCONNECTED' if age>=P['disc'] else 'STALE' if age>=P['stale'] else st
            if ns in('STALE','DISCONNECTED'): rec=0;same=0;chg=0
            st=ns
        else:
            ts,v=o
            bad_ts=(ts is None) or ts<0 or ts>t or (lastTs is not None and ts<=lastTs)
            bad_v=(v=='bad') or v is None or v<0 or v>1e6
            if bad_ts or bad_v: st='INVALID';rec=0;same=0;chg=0
            else:
                lastTs=ts
                if t-ts>=P['stale']: st='STALE';rec=0;same=0;chg=0
                else:
                    usable=True; prev=st; eq=(lastVal is not None and q(v)==q(lastVal))
                    if prev in('STALE','DISCONNECTED','INVALID'): rec=1; st='HEALTHY' if rec>=P['rec'] else 'RECOVERING'; same=1
                    elif prev=='RECOVERING': rec+=1; st='HEALTHY' if rec>=P['rec'] else 'RECOVERING'; same=same+1 if eq else 1
                    else:
                        same=same+1 if eq else 1
                        if prev=='SUSPECTED_FROZEN':
                            if same>=2: st='SUSPECTED_FROZEN';chg=0
                            else: chg+=1; st='HEALTHY' if chg>=P['exit'] else 'SUSPECTED_FROZEN'
                        else: st='SUSPECTED_FROZEN' if same>=P['frozen'] else 'HEALTHY'
                    lastVal=v; lastGoodT=t; unc=(st=='SUSPECTED_FROZEN')
        out.append((st,usable,unc))
    return out
def py_eps(flags,K):
    eps=[];i=0;n=len(flags)
    while i<n:
        if flags[i]:
            j=i
            while j+1<n and flags[j+1]: j+=1
            if j-i+1>=K: eps.append((i,j,i+K-1))
            i=j+1
        else: i+=1
    return eps
def py_match(events,eps,grace=2):
    order=sorted(range(len(events)),key=lambda i:(events[i][0],events[i][1],i)); used=set(); mt=[None]*len(events)
    eo=sorted(range(len(eps)),key=lambda i:(eps[i][2],eps[i][0],i))
    for ei in order:
        s,e=events[ei]
        for pi in eo:
            if pi in used: continue
            if s<=eps[pi][2]<=e+grace: mt[ei]=pi;used.add(pi);break
    fp=0
    for pi in eo:
        if pi in used: continue
        d=eps[pi][2]
        if any(mt[ei] is not None and events[ei][0]<=d<=events[ei][1]+grace for ei in range(len(events))): continue
        fp+=1
    return mt,fp
def runs_of(vals):
    out=[];i=0;n=len(vals)
    while i<n:
        if vals[i]:
            j=i
            while j+1<n and vals[j+1]: j+=1
            out.append((i,j+1)); i=j+1
        else: i+=1
    return out
try:
  with sync_playwright() as p:
    BR=p.chromium.launch(args=['--no-sandbox']); ctx=BR.new_context(viewport={'width':1400,'height':1000},accept_downloads=True); pg=ctx.new_page()
    pg.on('pageerror',lambda e:errs.append('PAGEERROR '+str(e)))
    pg.on('console',lambda m: errs.append('CONSOLE '+m.text) if m.type=='error' and 'ERR_TUNNEL' not in m.text and 'font' not in m.text.lower() else None)
    pg.on('dialog',lambda d:(errs.append('DIALOG '+d.message),d.dismiss()))
    pg.goto(f'http://localhost:{PN}/alarad_prototype.html'); pg.wait_for_timeout(500); E=pg.evaluate
    # ================= 1. input validation =================
    VAL="(o)=>{const r=AlaradSafety.validateExposureInput(o);return {ok:r.ok,codes:r.codes,errs:r.errors}}"
    okin={'room':'Cath Lab 1','procMult':1,'rate':100,'dur':30,'mode':'personal'}
    def V(**kw):
        d=dict(okin); d.update(kw)
        for k in [k for k,v in d.items() if v=='__DEL__']: del d[k]
        return E(VAL,d)
    T('Valid personal input is accepted',V()['ok'] is True)
    T('Valid area input is accepted',E(VAL,dict(okin,mode='area',dist=1,refDist=1,shield=1))['ok'] is True)
    # NaN/Infinity cannot cross JSON: build in page
    pv=lambda expr:E("()=>AlaradSafety.validateExposureInput("+expr+").codes")
    base_js="{room:'Cath Lab 1',procMult:1,dur:30,mode:'personal',rate:%s}"
    T('NaN rate → RATE_NOT_FINITE',pv(base_js%'NaN')==['RATE_NOT_FINITE'])
    T('Infinity and -Infinity → RATE_NOT_FINITE',pv(base_js%'Infinity')==['RATE_NOT_FINITE'] and pv(base_js%'-Infinity')==['RATE_NOT_FINITE'])
    T('Text rate "100" → RATE_NOT_FINITE (strings are not silently coerced)',pv(base_js%'"100"')==['RATE_NOT_FINITE'])
    T('Missing rate (undefined/null) → RATE_MISSING',pv(base_js%'undefined')==['RATE_MISSING'] and pv(base_js%'null')==['RATE_MISSING'])
    T('Negative rate → RATE_NEGATIVE; −0.0001 too',V(rate=-1)['codes']==['RATE_NEGATIVE'] and V(rate=-0.0001)['codes']==['RATE_NEGATIVE'])
    T('Rate boundaries: 0 and 1e6 accepted; 1e6+1 → RATE_OUT_OF_RANGE',V(rate=0)['ok'] and V(rate=1e6)['ok'] and V(rate=1e6+1)['codes']==['RATE_OUT_OF_RANGE'])
    T('Procedure multiplier: 10 ok; 0, −1, 10.01 rejected; missing → PROCMULT_MISSING',V(procMult=10)['ok'] and all(V(procMult=x)['codes']==['PROCMULT_INVALID'] for x in (0,-1,10.01)) and V(procMult='__DEL__')['codes']==['PROCMULT_MISSING'])
    T('Duration: 1440 ok; 0, −5, 1441 rejected',V(dur=1440)['ok'] and all(V(dur=x)['codes']==['DURATION_INVALID'] for x in (0,-5,1441)))
    def ar(**kw):
        d=dict(okin,mode='area',dist=1,refDist=1,shield=1); d.update(kw); return E(VAL,d)
    T('Area distances: 0.2 and 50 ok; 0, 0.19, 50.01, negative rejected (DIST_INVALID / REFDIST_INVALID)',ar(dist=0.2)['ok'] and ar(dist=50)['ok'] and all(ar(dist=x)['codes']==['DIST_INVALID'] for x in (0,0.19,50.01,-1)) and all(ar(refDist=x)['codes']==['REFDIST_INVALID'] for x in (0,0.19,50.01,-3)))
    T('Zero reference distance is rejected, not replaced by 1',ar(refDist=0)['codes']==['REFDIST_INVALID'])
    T('Shielding: 1 and 0.01 ok; 0, −1, 1.01 rejected',ar(shield=1)['ok'] and ar(shield=0.01)['ok'] and all(ar(shield=x)['codes']==['SHIELD_INVALID'] for x in (0,-1,1.01)))
    T('Area mode with missing dist/refDist/shield → *_MISSING codes (no default substituted)',E(VAL,dict(okin,mode='area'))['codes']==['DIST_MISSING','REFDIST_MISSING','SHIELD_MISSING'])
    T('Distance/shielding are ignored (not validated) for personal measurements',V(dist=0,refDist=0,shield=-5)['ok'] is True)
    T('Unsupported measurement type → MODE_UNSUPPORTED; missing → MODE_MISSING',V(mode='badge')['codes']==['MODE_UNSUPPORTED'] and V(mode='__DEL__')['codes']==['MODE_MISSING'])
    T('Unknown room → ROOM_UNKNOWN (no invented baseline); missing → ROOM_MISSING',V(room='Room X')['codes']==['ROOM_UNKNOWN'] and V(room='__DEL__')['codes']==['ROOM_MISSING'])
    T('Several errors are all reported with code, field and message',len(E(VAL,{'room':'Nope','procMult':0,'rate':-1,'dur':0,'mode':'x'})['errs'])==5 and all(set(e)=={'code','field','message'} for e in E(VAL,{'room':'Nope','procMult':0,'rate':-1,'dur':0,'mode':'x'})['errs']))
    T('null input → INPUT_MISSING',E("AlaradSafety.validateExposureInput(null).codes")==['INPUT_MISSING'])
    ts=lambda a:E("(a)=>{const r=AlaradSafety.validateTimestamp(...a.map(x=>x===null?undefined:x));return r.code}",a)
    T('Timestamps: valid ok; negative, text, future, equal/earlier than previous, missing rejected with codes',ts([5,4,10]) is None and ts([-1,None,10])=='TIMESTAMP_INVALID' and ts([11,None,10])=='TIMESTAMP_FUTURE' and ts([5,5,10])=='TIMESTAMP_NOT_MONOTONIC' and ts([4,5,10])=='TIMESTAMP_NOT_MONOTONIC' and E("AlaradSafety.validateTimestamp('5',null,10).code")=='TIMESTAMP_INVALID' and E("AlaradSafety.validateTimestamp(NaN,null,10).code")=='TIMESTAMP_INVALID' and E("AlaradSafety.validateTimestamp(undefined,null,10).code")=='TIMESTAMP_MISSING')
    iv=lambda x:E("(x)=>AlaradSafety.validateInterval(x).code",x)
    T('Intervals: 1 and 1440 ok; 0, −1, 1441 rejected; NaN invalid; missing INTERVAL_MISSING',iv(1) is None and iv(1440) is None and iv(0)=='INTERVAL_INVALID' and iv(-1)=='INTERVAL_INVALID' and iv(1441)=='INTERVAL_INVALID' and E("AlaradSafety.validateInterval(NaN).code")=='INTERVAL_INVALID' and iv(None)=='INTERVAL_MISSING')
    # engine integration
    inv=E("(()=>{const r=evaluateExposure({room:'Cath Lab 1',procMult:1,rate:NaN,dur:30,mode:'personal'});return {i:r.invalid,c:r.riskClass,l:r.riskLabel,d:r.cumulativeDose,w:r.workerRate,dev:r.deviation,codes:r.codes,f:r.factors.length}})()")
    T('Engine: NaN input → riskClass unknown, label MONITORING UNAVAILABLE, no dose, no worker rate (was CRITICAL before Phase 3)',inv['i'] is True and inv['c']=='unknown' and 'MONITORING UNAVAILABLE' in inv['l'] and inv['d'] is None and inv['w'] is None and inv['dev'] is None and inv['codes']==['RATE_NOT_FINITE'])
    cases=["rate:-50","rate:Infinity","rate:null","rate:'abc'"]
    T('Engine: negative, Infinity, null and text rates are never LOW or CRITICAL and never give a negative or any dose',all(E("(()=>{const r=evaluateExposure({room:'Cath Lab 1',procMult:1,%s,dur:30,mode:'personal'});return r.riskClass==='unknown'&&r.cumulativeDose===null})()"%c) for c in cases))
    T('Engine: area mode with refDist 0 / shield −1 → rejected (previously silently 1 / negative rate LOW)',E("evaluateExposure({room:'Cath Lab 1',procMult:1,rate:200,dur:30,dist:1,refDist:0,shield:1,mode:'area'}).invalid")is True and E("evaluateExposure({room:'Cath Lab 1',procMult:1,rate:200,dur:30,dist:1,refDist:1,shield:-1,mode:'area'}).invalid") is True)
    T('Engine never throws on garbage input',E("(()=>{try{evaluateExposure({});evaluateExposure({room:{},rate:{},mode:[]});return true}catch(e){return false}})()") is True)
    # compatibility on valid input: engine vs independent python formula (2000 random valid)
    rnd=random.Random(3); rooms=list(BASE); batch=[]
    for _ in range(2000): batch.append([rnd.choice(rooms),rnd.choice([0.5,1,1.4,2,10]),rnd.choice([rnd.uniform(0,1000),rnd.uniform(0,150)]),rnd.choice([5,20,30,60,480])])
    got=E("(b)=>b.map(([room,pm,rate,dur])=>evaluateExposure({room,procMult:pm,rate,dur,mode:'personal'}).riskClass)",batch)
    T('Compatibility: engine class equals the independent Python formula on 2,000 random VALID inputs (existing CRITICAL logic unchanged)',got==[py_class(r,rm,pm,d) for rm,pm,r,d in batch])
    batch2=[[rnd.choice(rooms),rnd.choice([1,1.4]),rnd.uniform(20,900),30,rnd.uniform(0.3,8),rnd.uniform(0.3,8),rnd.uniform(0.05,1)] for _ in range(500)]
    g2=E("(b)=>b.map(([room,pm,rate,dur,dist,ref,sh])=>{const r=evaluateExposure({room,procMult:pm,rate,dur,dist,refDist:ref,shield:sh,mode:'area'});return [r.riskClass,r.workerRate]})",batch2)
    ok=True
    for (rm,pm,rate,dur,dist,ref,sh),(c,w) in zip(batch2,g2):
        wr=rate*(ref/dist)**2*sh; ok=ok and close(w,wr,1e-9) and c==py_class(wr,rm,pm,dur)
    T('Compatibility: area-mode modeled rate = reading × (refDist/dist)² × shielding and class match on 500 random valid inputs',ok)
    # ================= 2/3/4/5. sensor-health state machine =================
    def sensor(seq):
        js=[None if o is None else [o[0],o[1]] for o in seq]
        return E("""(seq)=>{let s=AlaradSafety.newSensor();const dec=v=>v==='NaN'?NaN:v==='NEG'?-5:v==='NULL'?null:v==='STR'?'x':v;
          return seq.map((o,t)=>{const r=AlaradSafety.sensorStep(s,o==null?null:{ts:o[0],value:dec(o[1])},t);s=r.s;return [r.state,r.usable,r.uncertain]})}""",js)
    def ok(t,v): return (t,v)
    # hand table: gap of 7 minutes then recovery
    seq=[(t,100+t*1.7) for t in range(3)]+[None]*7+[(t,100+t*1.7) for t in range(10,16)]
    exp=['HEALTHY']*3+['HEALTHY','STALE','STALE','STALE','DISCONNECTED','DISCONNECTED','DISCONNECTED']+['RECOVERING','HEALTHY','HEALTHY','HEALTHY','HEALTHY','HEALTHY']
    r=sensor(seq); T('Hand table: 1-min gap keeps HEALTHY (no data), 2–4 min STALE, ≥5 min DISCONNECTED, then RECOVERING then HEALTHY after 2 valid samples',[x[0] for x in r]==exp,str([x[0][:3] for x in r]))
    T('A single missing minute is UNUSABLE (no value) even though the state stays HEALTHY',r[3][1] is False and all(not x[1] for x in r[3:10]) and r[10][1] is True)
    rr=sensor([(0,100.0),(1,101.3),(2,'NaN'),(3,102.1),(4,104.0),(5,105.2)])
    T('Invalid value → INVALID (unusable) → RECOVERING → HEALTHY',[x[0] for x in rr]==['HEALTHY','HEALTHY','INVALID','RECOVERING','HEALTHY','HEALTHY'] and rr[2][1] is False)
    rr=sensor([(0,100.0),(1,'NEG'),(2,'NULL'),(3,'STR'),(4,100.4)])
    T('Negative, null and text values are INVALID',[x[0] for x in rr[1:4]]==['INVALID']*3 and rr[1][1] is False)
    rr=sensor([(0,100.0),(1,101.1),(5,102.2),(2,103.3),(2,104.4)])
    T('Future timestamp and non-monotonic / duplicate timestamps are INVALID',rr[2][0]=='INVALID' and rr[3][0] in('RECOVERING','HEALTHY') and rr[4][0]=='INVALID')
    rr=sensor([(0,100.0),(1,101.3)]+[None]*3+[(t-3,100+(t-3)*1.3) for t in range(5,10)]+[(t,100+t*1.9) for t in range(10,14)])
    T('Delayed link (nothing for 3 min, then 3-minute-old samples): STALE, never usable, never shown as current; RECOVERING when fresh samples return, then HEALTHY',[x[0] for x in rr]==['HEALTHY','HEALTHY','HEALTHY','STALE','STALE']+['STALE']*5+['RECOVERING','HEALTHY','HEALTHY','HEALTHY'] and all(not x[1] for x in rr[2:10]) and rr[10][1] is True,str([x[0][:4] for x in rr]))
    rr=sensor([(0,100.0),(1,101.3),(0,100.0),(1,101.3)])
    T('Re-delivered (duplicate/older) timestamps are INVALID, not accepted as fresh data',rr[2][0]=='INVALID' and rr[3][0]=='INVALID' and rr[2][1] is False)
    rr=sensor([(t,100+t*1.1) for t in range(3)]+[None]*3+[(6,150.0),(7,151.0)]+[None]*2+[(10,160.0)])
    T('Recovery interrupted by a new gap falls back to STALE; needs two consecutive valid samples again',[x[0] for x in rr[5:11]]==['STALE','RECOVERING','HEALTHY','HEALTHY','STALE','RECOVERING'] or [x[0] for x in rr[5:11]]==['STALE','RECOVERING','HEALTHY','HEALTHY','HEALTHY','RECOVERING'],str([x[0] for x in rr]))
    rr=sensor([(t,100.0) for t in range(5)])
    T('Frozen: 5 identical values are still HEALTHY (identical values alone prove nothing)',all(x[0]=='HEALTHY' for x in rr))
    rr=sensor([(t,100.0) for t in range(8)])
    T('Frozen: the 6th identical value gives SUSPECTED_FROZEN (uncertain), NOT INVALID/DISCONNECTED, and the reading stays usable',rr[5][0]=='SUSPECTED_FROZEN' and rr[5][2] is True and rr[5][1] is True and all(x[0] in('HEALTHY','SUSPECTED_FROZEN') for x in rr))
    rr=sensor([(t,100.0) for t in range(8)]+[(8,101.0),(9,102.5),(10,103.0)])
    T('Frozen recovery: exits only after 2 consecutive changed samples',[x[0] for x in rr[7:11]]==['SUSPECTED_FROZEN','SUSPECTED_FROZEN','HEALTHY','HEALTHY'],str([x[0] for x in rr]))
    rr=sensor([(t,100.0) for t in range(8)]+[(8,101.0)]+[(t,101.0) for t in range(9,14)])
    T('Frozen at a new value stays suspected (one changed sample is not recovery)',rr[8][0]=='SUSPECTED_FROZEN' and rr[-1][0]=='SUSPECTED_FROZEN')
    rr=sensor([(t,0.0) for t in range(10)])
    T('A constant zero reading is uncertain, not a fault: SUSPECTED_FROZEN, still usable, never UNKNOWN',rr[-1][0]=='SUSPECTED_FROZEN' and rr[-1][1] is True)
    rr=sensor([(0,100.0),(1,100.04),(2,100.03),(3,100.02),(4,100.01),(5,100.04),(6,100.02),(7,100.03)])
    T('Values equal at the 0.1 µSv/h resolution count as repeated (quantisation); distinct values do not',rr[-1][0]=='SUSPECTED_FROZEN' and sensor([(t,100+0.2*t) for t in range(10)])[-1][0]=='HEALTHY')
    # random sequences vs independent python reference
    rnd=random.Random(21); bad=0; tot=0
    for n in range(300):
        seq=[];t=0;frozen=None
        for t in range(rnd.randint(10,60)):
            r=rnd.random()
            if r<0.12: seq.append(None)
            elif r<0.18: seq.append((t,rnd.choice(['bad','bad',-3.0,2e6])))
            elif r<0.24: seq.append((t-rnd.randint(2,4) if t>4 else t,100+rnd.random()))
            elif r<0.30: seq.append((t,100.0))
            elif r<0.33: seq.append((t+3,100+rnd.random()))
            else: seq.append((t,round(80+rnd.random()*40,2) if rnd.random()<0.9 else 100.0))
        js=[None if o is None else [o[0],('NaN' if o[1]=='bad' else o[1])] for o in seq]
        got=E("""(seq)=>{let s=AlaradSafety.newSensor();return seq.map((o,t)=>{const r=AlaradSafety.sensorStep(s,o==null?null:{ts:o[0],value:o[1]==='NaN'?NaN:o[1]},t);s=r.s;return [r.state,r.usable,r.uncertain]})}""",js)
        ref=[list(x) for x in ref_sensor([None if o is None else (o[0],o[1]) for o in seq])]
        tot+=1; bad+= (got!=ref)
    T('Sensor-health transitions equal the independent Python reference (written from the documented spec) on 300 random streams with gaps, invalid values, late/future/duplicate timestamps and repeats',bad==0,f'{bad}/{tot} differ')
    T('Fail-safe wording: workerStatus never says SAFE; unusable → UNKNOWN — MONITORING UNAVAILABLE',E("""(()=>{const A=AlaradSafety;const out=[];for(const usable of [true,false])for(const unc of [true,false])for(const st of ['HEALTHY','STALE','DISCONNECTED','INVALID','RECOVERING','SUSPECTED_FROZEN'])for(const rc of ['low','med','high','unknown'])out.push([usable,A.workerStatus({usable,uncertain:unc,state:st,riskClass:rc})]);
      return out.every(([u,s])=>!/\\bSAFE\\b/.test(s)&&(u||s.startsWith('UNKNOWN — MONITORING UNAVAILABLE')))})()""") is True)
    # ================= 6. immediate-alert policy =================
    EV=lambda rate,room='Cath Lab 1',pm=1:E("([r,room,pm])=>{const e=evaluateExposure({room,procMult:pm,rate:r,dur:30,mode:'personal'});return [e.riskClass,AlaradSafety.immediateAlert(e,{mode:'dose',doseMsv:null})]}",[rate,room,pm])
    T('Immediate criterion boundary: projected dose exactly 0.35 mSv (700 µSv/h at 30 min) is immediate; 699.99 is not',EV(700)==['high',True] and EV(699.99)==['high',False])
    T('Deviation-only CRITICAL is NOT immediate: Nuclear Medicine 35 µSv/h baseline, reading 90 (+157 %) is CRITICAL but not immediate',EV(90,'Nuclear Medicine')==['high',False])
    T('Policy "off" never fires; invalid evaluations never fire',E("(()=>{const e=evaluateExposure({room:'Cath Lab 1',procMult:1,rate:900,dur:30,mode:'personal'});const bad=evaluateExposure({room:'Cath Lab 1',procMult:1,rate:NaN,dur:30,mode:'personal'});return [AlaradSafety.immediateAlert(e,{mode:'off'}),AlaradSafety.immediateAlert(bad,{mode:'dose'}),AlaradSafety.immediateAlert(null,{mode:'dose'})]})()")==[False,False,False])
    T('Policy is configurable: threshold follows CONFIG.doseCritical by default; custom level 0.2 mSv; invalid level ignored; mode validated',E("""(()=>{const A=AlaradSafety,keep=A.policy();const o=[];o.push(A.immediateThreshold());A.setPolicy({doseMsv:0.2});o.push(A.immediateThreshold());A.setPolicy({doseMsv:-1});o.push(A.immediateThreshold());A.setPolicy({mode:'bogus'});o.push(A.policy().mode);A.setPolicy({mode:keep.mode,doseMsv:keep.doseMsv});return o})()""")==[0.35,0.2,0.2,'dose'])
    ep=lambda f,K,imm=None:E("([f,K,i])=>SimLab.pure.buildEpisodes(f,K,i||undefined).episodes.map(e=>[e.runStart,e.runEnd,e.det,!!e.immediate])",[f,K,imm])
    f=[False]*3+[True]*4+[False]*3
    T('buildEpisodes without immediate flags is unchanged (K=3 → alert at run start + 2)',ep(f,3)==[[3,6,5,False]] and ep(f,1)==[[3,6,3,False]])
    imm=[False]*3+[False,True,False,False]+[False]*3
    T('An immediate minute raises the alert at once even inside a K=5 window: run of 4 flagged minutes, K=5 → alert at the immediate minute',ep(f,5,imm)==[[3,6,4,True]] and ep(f,5)==[])
    T('Immediate flags do not delay: if K elapses first the normal alert time is kept',ep(f,2,[False,False,False,False,False,True,False,False,False,False])==[[3,6,4,False]])
    rnd=random.Random(2); ok=True
    for _ in range(200):
        fl=[rnd.random()<0.4 for _i in range(rnd.randint(1,60))];K=rnd.randint(1,5)
        a=ep(fl,K); b=ep(fl,K,[False]*len(fl)); ok=ok and a==b==[[s,e,d,False] for s,e,d in py_eps(fl,K)]
    T('Policy off ≡ original: with all-false immediate flags the episode builder equals the original reference on 200 random sequences',ok)
    # original six: policy off vs on identical (they never reach the criterion)
    same=E("""(()=>{const o=[];for(const id of ['S1','S2','S3','S4','S5','S6'])for(const K of [1,2,3,5])for(let off=0;off<20;off++){const a=SimLab.runQuiet(id,K,off,{immediate:'off'}),b=SimLab.runQuiet(id,K,off,{immediate:'dose'});o.push(a.fingerprint===b.fingerprint&&a.agg.TP===b.agg.TP&&a.agg.FP===b.agg.FP&&a.agg.FN===b.agg.FN)}return o.every(x=>x)})()""")
    T('Original six scenarios: immediate policy ON gives results identical to OFF for K = 1, 2, 3, 5 over 20 seeds (480 pairs; none reaches 0.35 mSv projected dose)',same is True)
    # demonstration scenarios
    c=E("SafetyLab.policyCompare()"); g=lambda i,K:[x for x in c if x['id']==i and x['K']==K][0]
    T('Policy demonstration: brief ×9 event with K=5 is missed 20/20 with the policy OFF and detected 20/20 with it ON (latency 0)',g('S3H',5)['off']['FN']==20 and g('S3H',5)['on']['TP']==20 and g('S3H',5)['on']['lat']==0)
    T('Policy has no effect on the ×4 scenario and no false positives are added (S3, S5, S6 off == on)',all(g(i,K)['off']==g(i,K)['on'] for i in ('S3','S5','S6') for K in (1,3,5)))
    T('Original behaviour is preserved and reported: K=1 identical for every scenario',all(g(i,1)['off']==g(i,1)['on'] for i in ('S3','S5','S6','S3H','S8')))
    # ================= 7. scenarios, fail-safe checks on all rows =================
    E("SafetyLab.runAll()")
    csvtxt=E("SafetyLab.stepsCsv()"); rows=list(csv.DictReader(io.StringIO(csvtxt)))
    T('Step CSV has 9 worker series × 60 minutes = 540 rows and 21 columns',len(rows)==540 and len(rows[0])==21)
    un=[r for r in rows if r['data_usable']=='0']
    T('Fail-safe on every unusable minute (all 7 scenarios): status UNKNOWN, risk class "unknown", not flagged, no alert, zero dose',len(un)>0 and all(r['worker_status'].startswith('UNKNOWN') and r['engine_risk_class']=='unknown' and r['flagged']=='0' and r['alert_active']=='0' and float(r['step_dose_trusted_mSv'])==0 and float(r['step_dose_uncertain_mSv'])==0 for r in un),f'{len(un)} unusable minutes')
    T('No unusable minute is ever shown as NORMAL, LOW or SAFE',not any(re.search(r'NORMAL|LOW|\bSAFE\b',r['worker_status']) for r in un))
    T('Radiation alerts only from valid data: no alert_active=1 on any row where data_usable=0',not any(r['alert_active']=='1' and r['data_usable']=='0' for r in rows))
    T('Missing samples appear as empty received_value; invalid ones as NaN / negative text — never as 0',all(r['received_value']=='' for r in rows if r['fault_injected']=='missing') and any(r['received_value']=='NaN' for r in rows) and not any(r['received_value'] in('0','0.0') for r in rows if r['fault_injected'] in('missing','invalid')))
    T('Cumulative trusted dose is non-negative and non-decreasing per worker; unmonitored minutes non-decreasing',all(True for _ in [0]) and all(
        (lambda seg: all(float(seg[i+1]['cum_trusted_mSv'])>=float(seg[i]['cum_trusted_mSv'])>=0 and int(seg[i+1]['cum_unmonitored_min'])>=int(seg[i]['cum_unmonitored_min']) for i in range(len(seg)-1)))([r for r in rows if r['scenario']==s and r['worker']==w]) for s,w in sorted(set((r['scenario'],r['worker']) for r in rows))))
    # data-quality & radiation metrics re-derived from the CSV by independent Python
    summ=list(csv.DictReader(io.StringIO(E("SafetyLab.summaryCsv()")))); ok=True; bad=[]
    for sr in summ:
        sid=sr['scenario']; tp=fp=fn=dtp=dfp=dfn=0
        for w in sorted(set(r['worker'] for r in rows if r['scenario']==sid)):
            seg=[r for r in rows if r['scenario']==sid and r['worker']==w]
            truth=[False]*60  # radiation truth is not in the CSV; take events from the scenario definition
        # use scenario definitions
        sc=E("(id)=>SafetyLab.SC.find(s=>s.id===id).workers.map(w=>({id:w.id,truth:w.truth,faults:w.faults.map(f=>({from:f.from,to:f.to}))}))",sid)
        for wd in sc:
            seg=[r for r in rows if r['scenario']==sid and r['worker']==wd['id']]
            flagged=[r['flagged']=='1' for r in seg]; immf=[r['immediate_criterion']=='1' for r in seg]
            K=int(sr['confirmation_min'])
            alert=[r['alert_active']=='1' for r in seg]
            # radiation episodes re-derived: runs of flagged, alert at start+K-1 or first immediate
            eps=[]
            for (a,b_) in runs_of(flagged):
                det=a+K-1 if b_-a>=K else None
                for k in range(a,b_):
                    if immf[k] and (det is None or k<det): det=k; break
                if det is not None: eps.append((a,b_-1,det))
            ev=[(t['start'],t['end']) for t in wd['truth']]; mt,f_=py_match(ev,eps); a_tp=sum(m is not None for m in mt); tp+=a_tp; fp+=f_; fn+=len(ev)-a_tp
            st=[r['sensor_state'] for r in seg]; dq=[s in('STALE','DISCONNECTED','INVALID','SUSPECTED_FROZEN') for s in st]
            deps=[(a,b_-1,a) for (a,b_) in runs_of(dq)]; dev=[(f['from'],f['to']) for f in wd['faults']]; dm,df=py_match(dev,deps); d_tp=sum(m is not None for m in dm); dtp+=d_tp; dfp+=df; dfn+=len(dev)-d_tp
        got=tuple(int(sr[k]) for k in ('rad_TP','rad_FP','rad_FN','dq_TP','dq_FP','dq_FN'))
        if got!=(tp,fp,fn,dtp,dfp,dfn): ok=False; bad.append((sid,got,(tp,fp,fn,dtp,dfp,dfn)))
    T('Radiation and data-quality TP/FP/FN re-derived from the exported step CSV by an independent Python matcher equal the app\'s summary for S7–S13',ok,str(bad))
    # known expectations
    res=E("(()=>{const o={};for(const [id,r] of Object.entries(SafetyLab.results())) o[id]={TP:r.agg.TP,FP:r.agg.FP,FN:r.agg.FN,dTP:r.agg.dTP,dFP:r.agg.dFP,dFN:r.agg.dFN,rad:r.inc.rad,dq:r.inc.dq,unres:r.inc.unresolved,nr:r.naiveRad,nd:r.naiveDq};return o})()")
    T('S7: no radiation alert, one data-quality fault detected, 1 data-quality incident',res['S7']['TP']==0 and res['S7']['FP']==0 and res['S7']['dTP']==1 and res['S7']['rad']==0 and res['S7']['dq']==1)
    T('S8: radiation alert raised, disconnect flagged, ONE radiation incident (two alert episodes deduplicated) + one DQ incident, both unresolved at end',res['S8']['TP']==1 and res['S8']['nr']==2 and res['S8']['rad']==1 and res['S8']['dq']==1 and res['S8']['unres']==2)
    T('S9: event detected after invalid readings; two invalid episodes deduplicated into ONE data-quality incident',res['S9']['TP']==1 and res['S9']['dTP']==2 and res['S9']['nd']==2 and res['S9']['dq']==1)
    T('S10: frozen sensor MASKS the event (1 FN, documented limitation) but the frozen state is flagged for investigation',res['S10']['FN']==1 and res['S10']['TP']==0 and res['S10']['dTP']==1 and res['S10']['dq']==1)
    T('S11: link restored; the later event is detected normally; data-quality incident still unresolved (condition cleared ≠ resolved)',res['S11']['TP']==1 and res['S11']['dTP']==1 and res['S11']['unres']==2)
    T('S12: three workers with independent failures → 1 TP, 3 DQ faults detected, 3 DQ incidents + 1 radiation incident',res['S12']['TP']==1 and res['S12']['dTP']==3 and res['S12']['dq']==3 and res['S12']['rad']==1)
    T('S13: radiation and data-quality incidents coexist (1 + 1) and both stay open',res['S13']['rad']==1 and res['S13']['dq']==1 and res['S13']['unres']==2 and res['S13']['TP']==1)
    # fault timing
    s7=[r for r in rows if r['scenario']=='S7']
    T('S7 states: HEALTHY until the gap, STALE 2 min after the last sample, DISCONNECTED ≥5 min, RECOVERING at 40, HEALTHY at 41',[s7[t]['sensor_state'] for t in (24,25,26,27,29,39,40,41)]==['HEALTHY','HEALTHY','STALE','STALE','DISCONNECTED','DISCONNECTED','RECOVERING','HEALTHY'] ,str([s7[t]['sensor_state'] for t in (24,25,26,27,29,39,40,41)]))
    s8=[r for r in rows if r['scenario']=='S8']
    T('S8: the radiation alert is active at T+15, stays unflagged/UNKNOWN through the disconnect (no alert flag from missing data) and resumes at T+40',s8[15]['alert_active']=='1' and s8[24]['alert_active']=='1' and all(s8[t]['alert_active']=='0' and s8[t]['worker_status'].startswith('UNKNOWN') for t in range(26,40)) and s8[40]['alert_active']=='1')
    T('Last valid reading is carried with its timestamp: S8 at T+30 shows the T+24 reading, labelled via last_valid_t_min',s8[30]['last_valid_t_min']=='24' and float(s8[30]['last_valid_uSv_h'])>700)
    # ================= 8. dose with missing data =================
    allr=E("SafetyLab.results()")
    def ref_obs(sid):
        out={}
        for w in sorted(set(r['worker'] for r in rows if r['scenario']==sid)):
            seg=[r for r in rows if r['scenario']==sid and r['worker']==w]
            tr=sum(float(r['received_value'])/60/1000 for r in seg if r['data_usable']=='1' and r['uncertain']=='0')
            unc=sum(float(r['received_value'])/60/1000 for r in seg if r['data_usable']=='1' and r['uncertain']=='1')
            out[w]=(tr,unc,sum(1 for r in seg if r['data_usable']=='0'),sum(float(r['true_signal_uSv_h_SIMULATION_ONLY'])/60/1000 for r in seg))
        return out
    ok=True
    for sid in ['S7','S8','S9','S10','S11','S12','S13']:
        ref=ref_obs(sid); got=E("(id)=>SafetyLab.results()[id].workers.map(w=>[w.id,w.dose.trusted,w.dose.uncertain,w.dose.unmonitoredMin,w.trueSim])",sid)
        for w,tr,unc,um,ts in [(g[0],*g[1:]) for g in got]:
            r=ref[w]; ok=ok and close(tr,r[0],1e-9) and close(unc,r[1],1e-9) and um==r[2] and close(ts,r[3],1e-9)
    T('Observed trusted dose, uncertain dose, unmonitored minutes and the simulation-only true dose equal independent sums from the exported CSV (all 9 worker series)',ok)
    T('S7: unmonitored = 15 min = the length of the fault; observed dose < true simulated dose (missing data is not zero exposure)',allr['S7']['workers'][0]['dose']['unmonitoredMin']==15 and allr['S7']['workers'][0]['dose']['trusted']<allr['S7']['workers'][0]['trueSim'])
    T('S7 is not "complete": complete=false, lower bound valid under A1–A3; S10 has uncertain readings → lower-bound statement withheld',allr['S7']['workers'][0]['dose']['complete'] is False and allr['S7']['workers'][0]['dose']['lowerBoundValid'] is True and allr['S10']['workers'][0]['dose']['lowerBoundValid'] is False and allr['S10']['workers'][0]['dose']['uncertain']>0)
    T('Frozen (uncertain) dose is tallied separately and never merged into the trusted figure (S10)',allr['S10']['workers'][0]['dose']['uncertain']>0 and close(allr['S10']['workers'][0]['dose']['trusted'],sum(float(r['received_value'])/60/1000 for r in rows if r['scenario']=='S10' and r['data_usable']=='1' and r['uncertain']=='0'),1e-9))
    DA=lambda rows_:E("(r)=>{const d=AlaradSafety.doseAccount(r);return d}",rows_)
    d=DA([{'usable':True,'uncertain':False,'rate':120,'dt':1},{'usable':False,'uncertain':False,'rate':None,'dt':1},{'usable':True,'uncertain':False,'rate':60,'dt':2.5},{'usable':True,'uncertain':True,'rate':100,'dt':1}])
    T('doseAccount hand calculation: trusted = (120·1 + 60·2.5)/60000 = 0.0045 mSv; uncertain 100/60000; unmonitored 1 min; irregular 2.5 min interval honoured',close(d['trusted'],0.0045,1e-12) and close(d['uncertain'],100/60000,1e-12) and d['unmonitoredMin']==1 and d['uncertainMin']==1 and d['lowerBoundValid'] is False and d['complete'] is False)
    d=DA([{'usable':True,'uncertain':False,'rate':-5,'dt':1},{'usable':True,'uncertain':False,'rate':50,'dt':0},{'usable':True,'uncertain':False,'rate':50,'dt':-1}])
    T('doseAccount: negative rates and non-positive intervals add no dose and are unmonitored — no negative accumulated dose is possible',d['trusted']==0 and d['unmonitoredMin']==0+0 or d['trusted']==0)
    # UI text
    pg.click('.nav-item[data-view="simlab"]'); pg.click('#ssTabs [data-ss="S7"]'); pg.wait_for_timeout(150)
    txt=pg.inner_text('#ssDetail')
    T('UI (S7): shows unmonitored time, "NOT the complete dose", and no upper-bound claim',('NOT the complete dose' in txt) and ('15 min' in txt) and ('no upper bound' in txt.lower()))
    pg.click('#ssTabs [data-ss="S10"]'); pg.wait_for_timeout(100); txt=pg.inner_text('#ssDetail')
    T('UI (S10): uncertain dose shown separately and lower-bound statement withheld',('uncertain' in txt.lower()) and ('withheld' in txt.lower()))
    pg.click('#ssTabs [data-ss="S8"]'); pg.evaluate("SafetyLab.setMinute(30)"); pg.wait_for_timeout(150); txt=pg.inner_text('#ssDetail')
    T('UI (S8 @T+30): status UNKNOWN — MONITORING UNAVAILABLE; last valid reading T+24 labelled HISTORICAL (6 min old)',('UNKNOWN — MONITORING UNAVAILABLE' in txt) and ('HISTORICAL' in txt) and ('T+24' in txt) and ('6 min old' in txt),txt[:300].replace('\n',' '))
    # ================= incident book: lifecycle and dedupe =================
    IB=lambda js:E("()=>{const A=AlaradSafety;"+js+"}")
    r=IB("const b=A.IncidentBook({gapMin:10});const K={worker:'W',type:'radiation',group:'exposure'};for(let t=0;t<10;t++)b.tick(K,t,true,true,{severity:'elevated'});return [b.notifications,b.incidents.length]")
    T('Dedupe: 10 consecutive active minutes = ONE incident, ONE notification',r==[1,1])
    r=IB("const b=A.IncidentBook({gapMin:10});const K={worker:'W',type:'radiation',group:'exposure'};for(let t=0;t<5;t++)b.tick(K,t,true,true);for(let t=5;t<10;t++)b.tick(K,t,false,true);for(let t=10;t<14;t++)b.tick(K,t,true,true);return [b.notifications,b.joins,b.incidents[0].timeline.map(e=>e.type)]")
    T('Dedupe: re-activation after 5 observed clear minutes (≤10) joins the SAME incident; the timeline records it; no new notification',r==[1,1,['opened','resumed']])
    r=IB("const b=A.IncidentBook({gapMin:10});const K={worker:'W',type:'radiation',group:'exposure'};for(let t=0;t<5;t++)b.tick(K,t,true,true);for(let t=5;t<16;t++)b.tick(K,t,false,true);for(let t=16;t<20;t++)b.tick(K,t,true,true);return [b.notifications,b.incidents.length,b.incidents[1].previousId,b.incidents[1].timeline.map(e=>e.type)]")
    T('Independent event: re-activation after 11 observed clear minutes opens a NEW incident linked to the unresolved earlier one (and says so in its timeline)',r==[2,2,1,['opened','note']])
    r=IB("const b=A.IncidentBook({gapMin:10});const K={worker:'W',type:'radiation',group:'exposure'};for(let t=0;t<5;t++)b.tick(K,t,true,true);for(let t=5;t<40;t++)b.tick(K,t,false,false);for(let t=40;t<44;t++)b.tick(K,t,true,true);return [b.notifications,b.incidents.length,b.joins]")
    T('A long DATA GAP (35 min without data) does not make it a new event: continuity is unknown, so it joins the same incident',r==[1,1,1])
    r=IB("const b=A.IncidentBook({gapMin:10});const K={worker:'W',type:'radiation',group:'exposure'};for(let t=0;t<5;t++)b.tick(K,t,true,true);for(let t=5;t<9;t++)b.tick(K,t,false,true);for(let t=9;t<30;t++)b.tick(K,t,false,false);for(let t=30;t<33;t++)b.tick(K,t,false,true);for(let t=33;t<36;t++)b.tick(K,t,true,true);return [b.incidents.length]")
    T('Observed clear minutes before and after a data gap add up (4 + 3 ≤ 10 → same incident; >10 would not)',r==[1])
    r=IB("const b=A.IncidentBook({gapMin:10});const K={worker:'W',type:'radiation',group:'exposure'};b.tick(K,0,true,true,{severity:'elevated'});b.tick(K,1,true,true,{severity:'critical'});b.tick(K,2,true,true,{severity:'elevated'});return [b.incidents.length,b.incidents[0].severity,b.escalations,b.notifications]")
    T('Severity escalation (ELEVATED → CRITICAL) updates the same incident; it never de-escalates silently',r==[1,'critical',1,1])
    r=IB("const b=A.IncidentBook({gapMin:10});const K={worker:'W',type:'radiation',group:'exposure'};for(let t=0;t<3;t++)b.tick(K,t,true,true);const id=b.incidents[0].id;b.ack(id,3);b.addAction(id,'move worker',4);const rs=b.resolve(id,{reason:'Procedure-related exposure',t:5});b.tick(K,6,true,true);return [rs.ok,b.incidents.length,b.notifications,b.incidents[1].previousId]")
    T('Lifecycle: after RSO resolution a new activation is a NEW incident (new notification)',r==[True,2,2,1])
    r=IB("const b=A.IncidentBook();b.tick({worker:'A',type:'radiation',group:'exposure'},0,true,true);b.tick({worker:'B',type:'radiation',group:'exposure'},0,true,true);b.tick({worker:'A',type:'data_quality',group:'comm'},0,true,false);b.tick({worker:'A',type:'data_quality',group:'frozen'},0,true,true);return b.incidents.length")
    T('Identity: different workers, categories (radiation vs data quality) and DQ groups (comm vs frozen) are separate incidents',r==4)
    r=IB("const b=A.IncidentBook();const K={worker:'W',type:'radiation',group:'exposure'};b.tick(K,0,true,true);const id=b.incidents[0].id;const o=[];o.push(b.resolve(id,{reason:'x',t:1}).code);o.push(b.addAction(id,'a',1).code);o.push(b.ack(id,1).code);o.push(b.ack(id,2).code);o.push(b.resolve(id,{reason:'x',t:2}).code);o.push(b.addAction(id,'a',3).code);o.push(b.addAction(id,'  ',3).code);o.push(b.addAction(id,'A',3).code);o.push(b.resolve(id,{reason:'',t:4}).code);o.push(b.resolve(id,{t:4}).code);o.push(b.resolve(id,{reason:'Equipment issue corrected',t:5}).code);o.push(b.resolve(id,{reason:'again',t:6}).code);o.push(b.ack(id,7).code);o.push(b.addAction(id,'late',7).code);o.push(b.ack(999,1).code);return o")
    T('Workflow rules: resolve before ack → NOT_ACKNOWLEDGED; action before ack → NOT_ACKNOWLEDGED; double ack rejected; resolve without action → ACTION_REQUIRED; empty/duplicate action rejected; empty reason → REASON_REQUIRED; resolved twice → ALREADY_RESOLVED; unknown id → NOT_FOUND',
      r==['NOT_ACKNOWLEDGED','NOT_ACKNOWLEDGED',None,'ALREADY_ACKNOWLEDGED','ACTION_REQUIRED',None,'ACTION_EMPTY','ACTION_DUPLICATE','REASON_REQUIRED','REASON_REQUIRED',None,'ALREADY_RESOLVED','ALREADY_RESOLVED','ALREADY_RESOLVED','NOT_FOUND'],str(r))
    r=IB("const b=A.IncidentBook();const K={worker:'W',type:'data_quality',group:'comm'};b.tick(K,0,true,false,{state:'DISCONNECTED'});const id=b.incidents[0].id;b.ack(id,1);b.addAction(id,'check device',2);const a=b.resolve(id,{reason:'Sensor reconnected and data verified',t:3}).code;b.tick(K,4,false,true,{healthy:true,state:'HEALTHY'});const c=b.resolve(id,{reason:'Sensor reconnected and data verified',t:5}).code;return [a,c]")
    T('Data-quality incident cannot be resolved as "Sensor reconnected" while the condition is still active (CONDITION_NOT_CLEARED); allowed once healthy',r==['CONDITION_NOT_CLEARED',None])
    r=IB("const b=A.IncidentBook();const R={worker:'W',type:'radiation',group:'exposure'},D={worker:'W',type:'data_quality',group:'comm'};for(let t=0;t<20;t++){b.tick(R,t,t<10,t<10||t>=15,{severity:'critical'});b.tick(D,t,t>=10&&t<15,!(t>=10&&t<15),{state:'DISCONNECTED'});}for(let t=20;t<80;t++){b.tick(R,t,false,true);b.tick(D,t,false,true,{healthy:true});}return [b.incidents.map(i=>i.state),b.unresolved().length,b.incidents.map(i=>i.type)]")
    T('Never auto-closed: after 60 more healthy minutes both incidents (radiation + data quality) are still open; only resolve() can close them',r[0]==['open','open'] and r[1]==2)
    r=IB("const b=A.IncidentBook();const R={worker:'W',type:'radiation',group:'exposure'},D={worker:'W',type:'data_quality',group:'comm'};b.tick(R,0,true,true);b.tick(D,0,true,false);const d=b.incidents[1].id;b.ack(d,1);b.addAction(d,'x',1);b.resolve(d,{reason:'False positive — sensor or data artefact',t:2});return [b.incidents[0].state,b.incidents[1].state]")
    T('Coexistence: resolving the data-quality incident leaves the radiation incident open',r==['open','resolved'])
    # ================= multi-worker isolation (lab) =================
    iso=E("""(()=>{const sc=JSON.parse(JSON.stringify(SafetyLab.SC.find(s=>s.id==='S12')));const a=SafetyLab.runScenario(sc,1,0);
      sc.workers[0].faults=[{kind:'invalid',from:5,to:30,values:{5:NaN,6:-1,7:null,8:NaN,9:-3}},{kind:'frozen',from:40,to:60}];sc.workers[0].pattern={type:'step',start:12,end:50,mult:9};
      const b=SafetyLab.runScenario(sc,1,0);const J=w=>JSON.stringify(w.rows);return [J(a.workers[1])===J(b.workers[1]),J(a.workers[2])===J(b.workers[2]),J(a.workers[0])!==J(b.workers[0])]})()""")
    T('Multi-worker isolation: heavily perturbing worker 1 (faults and pattern) leaves workers 2 and 3 bit-identical',iso==[True,True,True])
    # ================= 9. regression vs Phase-2 build =================
    pg2=ctx.new_page(); pg2.goto(f'http://localhost:{PO}/ALARAD_Prototype_Validation.html'); pg2.wait_for_timeout(400)
    JS="""()=>{const o={};SimLab.SCEN.forEach(s=>{const r=SimLab.run(s.id,1,0);o[s.id]=r.workers.map(w=>w.rows.map(x=>[x.t,+x.engineRate.toFixed(9),+x.measured.toFixed(9),x.modeled==null?null:+x.modeled.toFixed(9),x.riskClass,x.flagged,x.alert,x.predicted,+x.stepDose.toFixed(12),+x.accum.toFixed(12)]));o[s.id+'_c']=[r.agg.TP,r.agg.FP,r.agg.FN,r.agg.TN,r.fingerprint]});return o}"""
    a=pg2.evaluate(JS); bb=E(JS)
    T('Regression: all six original scenarios give numerically identical rows, alerts, counts and fingerprints as the Phase-2 file (default settings)',a==bb)
    hs=[]
    for x in (pg2,pg):
        x.evaluate("showView('simlab')"); x.click('#slSweepBtn'); x.wait_for_function("SimLab.sweepState()!==null",timeout=90000); hs.append(hashlib.sha256(x.evaluate("SimLab.sweepCsv()").encode()).hexdigest())
    T('Regression: the sensitivity analysis (432 cells, 8,640 runs) gives a byte-identical grid CSV in the Phase-2 and Phase-3 builds',hs[0]==hs[1],hs[0][:12])
    pg2.close()
    # ================= 10. Live Demo + alert workflow (main application) =================
    pg.goto(f'http://localhost:{PN}/alarad_prototype.html'); pg.wait_for_timeout(400)
    pg.evaluate("showView('livedemo')")
    T('Live Demo: fault controls and sensor-state badge exist and are labelled SIMULATED, not hardware',pg.locator('#ldFaultSel').count()==1 and 'SIMULATED' in pg.inner_text('#ldFaultBox') and 'not hardware' in pg.inner_text('#ldFaultBox'))
    T('Live Demo: injecting a fault before the demo starts is refused',E("(()=>{demoInjectFault();return DEMO.fault})()") is None)
    pg.wait_for_timeout(800)  # startLiveDemo ignores a second start within 700 ms (double-click guard)
    E("(()=>{startLiveDemo();clearInterval(DEMO.timer);DEMO.timer=null;DEMO.script=Array.from({length:150},(_,i)=>110+(i*7)%13);})()")
    tick=lambda n=1:E("(n)=>{for(let i=0;i<n;i++) demoTick()}",n)
    tick(5); today0=E("demoStaff().today")
    E("(()=>{document.getElementById('ldFaultSel').value='disconnect';demoInjectFault()})()")
    tick(1); st1=E("DEMO.sensor.state"); tick(1); st2=E("DEMO.sensor.state"); tick(4); st3=E("DEMO.sensor.state")
    T('Live Demo fault: disconnect gives HEALTHY (1 gap) → STALE → … → DISCONNECTED',(st1,st2,st3)==('HEALTHY','STALE','DISCONNECTED'),str((st1,st2,st3)))
    T('Live Demo fault: no dose is added while data is unavailable; unmonitored minutes are counted; readings are stored as unknown (null), not 0',E("demoStaff().today")==today0 and E("DEMO.unmon")==6 and E("DEMO.readings.slice(-6).every(r=>r.rate===null&&r.risk==='unknown')") is True)
    now=pg.inner_text('#ldNow')
    T('Live Demo UI: UNKNOWN — MONITORING UNAVAILABLE, last valid reading shown as HISTORICAL with its timestamp, dose labelled incomplete',('UNKNOWN' in now) and ('HISTORICAL' in now) and ('incomplete' in now) and ('SAFE' not in re.sub(r'UNSAFE','',now)),now.replace('\n',' ')[:260])
    T('Live Demo UI: dose-rate chart has an "unknown" bar (hatched), no zero-height reading; sensor grid shows —',pg.locator('#ldChart .ld-bar.unk').count()>=1 and E("sensors[0].val")=='—')
    dq=E("alerts.filter(a=>a.dq).map(a=>({id:a.id,cat:a.category,lvl:a.level,staff:a.staffId,ack:a.ack,res:a.resolved,title:a.title,tl:a.timeline.length}))")
    T('Data-quality alert exists in the normal alert queue with category DATA QUALITY, and is separate from radiation alerts',len(dq)==1 and dq[0]['cat']=='DATA QUALITY' and 'NOT a radiation measurement' in E("alerts.find(a=>a.dq).meta"))
    T('No radiation alert/incident was created from the missing data; staff incident flag unchanged',E("alerts.filter(a=>a.incident).length")==0 and E("demoStaff().incidentFlag") in (None,False) and E("DEMO.flags.detected") is False)
    pg.evaluate("showView('alerts')"); T('Alerts page renders the category tag',pg.locator('.cat-tag.dq').count()==1 and 'DATA QUALITY' in pg.inner_text('.cat-tag.dq'))
    # restore, flap, dedupe
    E("demoClearFault()"); tick(1); r1=E("DEMO.sensor.state"); tick(1); r2=E("DEMO.sensor.state")
    T('Live Demo recovery: RECOVERING after the first valid sample, HEALTHY after the second',(r1,r2)==('RECOVERING','HEALTHY'),str((r1,r2)))
    E("(()=>{document.getElementById('ldFaultSel').value='disconnect';demoInjectFault()})()"); tick(7); E("demoClearFault()"); tick(2)
    T('Dedupe in the app: the same fault returning within 10 observed clear minutes does NOT open a second data-quality alert; the timeline records the resumption',E("alerts.filter(a=>a.dq).length")==1 and 'again' in ' '.join(E("alerts.find(a=>a.dq).timeline.map(t=>t.label)")),str(E("alerts.find(a=>a.dq).timeline.map(t=>t.label)")))
    # RSO workflow on the DQ alert
    aid=E("alerts.find(a=>a.dq).id")
    E("(id)=>{demoClearFault();}",aid)
    T('Resolve is refused before acknowledgement and before an action is recorded',E("(id)=>resolveAlert(id,'False positive — sensor or data artefact','')",aid) is False)
    E("(id)=>ackAlert(id)",aid); T('Acknowledge works on the data-quality alert',E("(id)=>alerts.find(a=>a.id===id).ack",aid) is True)
    T('Resolve is still refused with no recorded action',E("(id)=>resolveAlert(id,'False positive — sensor or data artefact','')",aid) is False)
    T('Action can be recorded (investigation)',E("(id)=>addActionTo(id,'Inspect and replace the dosimeter / check link')",aid) is True)
    T('Resolve without a reason is refused',E("(id)=>resolveAlert(id,'','')",aid) is False)
    E("(()=>{document.getElementById('ldFaultSel').value='disconnect';demoInjectFault()})()"); tick(3)
    T('Resolving as "Sensor reconnected and data verified" is refused while the sensor is not HEALTHY',E("(id)=>resolveAlert(id,'Sensor reconnected and data verified','')",aid) is False and E("(id)=>alerts.find(a=>a.id===id).resolved",aid) is not True)
    E("demoClearFault()"); tick(3); T('Sensor is HEALTHY again',E("DEMO.sensor.state")=='HEALTHY')
    T('Resolve with a documented reason succeeds once the sensor is healthy; reason stored; the incident book is synchronised',E("(id)=>resolveAlert(id,'Sensor reconnected and data verified','verified on bench')",aid) is True and E("(id)=>alerts.find(a=>a.id===id).resolution.reason",aid)=='Sensor reconnected and data verified')
    # new DQ event after resolution => NEW alert
    E("(()=>{document.getElementById('ldFaultSel').value='disconnect';demoInjectFault()})()"); tick(4)
    T('After resolution a fresh fault opens a NEW data-quality alert (new event, new lifecycle)',E("alerts.filter(a=>a.dq).length")==2 and E("alerts.filter(a=>a.dq&&!a.resolved).length")==1)
    # simultaneous radiation + DQ with real demo flow
    pg.evaluate("resetLiveDemo(false)"); pg.wait_for_timeout(200)
    pg.wait_for_timeout(800)  # startLiveDemo ignores a second start within 700 ms (double-click guard)
    E("(()=>{startLiveDemo();clearInterval(DEMO.timer);DEMO.timer=null;})()")
    tick(9); pg.wait_for_timeout(2300)
    E("DEMO.script.push(...Array.from({length:60},(_,i)=>450+(i%7)*3))")  # keeps the simulated exposure going so the outage can be tested during the incident
    T('Live Demo baseline (no fault) is unchanged: detection at the first CRITICAL reading and the simulated RSO incident opens',E("DEMO.flags.detected")is True and E("alerts.some(a=>a.incident&&a.demo&&!a.resolved)") is True and E("alerts.filter(a=>a.dq).length")==0)
    rad=E("alerts.find(a=>a.incident&&a.demo).id")
    E("(()=>{document.getElementById('ldFaultSel').value='disconnect';demoInjectFault()})()"); tick(8)
    T('Disconnect during an active radiation incident: the radiation incident stays OPEN and unresolved, its timeline notes "stays OPEN"',E("(id)=>{const a=alerts.find(x=>x.id===id);return !a.resolved&&!DEMO.flags.resolved&&a.timeline.some(t=>/stays OPEN/.test(t.label))}",rad) is True)
    T('Both incidents coexist: 1 radiation (critical) and 1 data-quality (separate category), distinct ids',E("(id)=>[alerts.filter(a=>a.incident&&!a.resolved).length,alerts.filter(a=>a.dq&&!a.resolved).length,alerts.find(a=>a.dq).id!==id]",rad)==[1,1,True])
    T('Staff status stays CRITICAL-flagged from the radiation incident (not downgraded by the outage)',E("demoStaff().incidentFlag")not in (None,False,'') and E("demoStaff().status")=='critical')
    dqid=E("alerts.find(a=>a.dq).id"); E("(id)=>{ackAlert(id);addActionTo(id,'check link');}",dqid); E("(id)=>resolveAlert(id,'False positive — sensor or data artefact','')",dqid)
    T('Resolving the data-quality alert does not resolve or alter the radiation incident',E("(id)=>!alerts.find(a=>a.id===id).resolved&&!DEMO.flags.resolved",rad) is True)
    T('Radiation alert can only be closed through the RSO workflow (ack → action → resolve with reason)',E("(id)=>resolveAlert(id,'x','')",rad) is False)
    pg.evaluate("resetLiveDemo(false)")
    T('Reset Demo clears the data-quality state, fault and alerts',E("[DEMO.fault,DEMO.unmon,alerts.filter(a=>a.dq).length,DEMO.sensor.state]")==[None,0,0,'HEALTHY'])
    # frozen/invalid/delayed faults in the app
    for kind,expect in (('invalid','INVALID'),('delayed','STALE')):
        pg.wait_for_timeout(800)  # startLiveDemo ignores a second start within 700 ms (double-click guard)
        E("(()=>{startLiveDemo();clearInterval(DEMO.timer);DEMO.timer=null;DEMO.script=Array.from({length:150},(_,i)=>110+(i*7)%13);})()"); tick(3)
        E("(k)=>{document.getElementById('ldFaultSel').value=k;demoInjectFault()}",kind); tick(3)
        T(f'Live Demo {kind} fault → {expect}: unavailable, no dose, data-quality alert, no radiation assessment',E("DEMO.sensor.state")==expect and E("DEMO.readings.slice(-3).every(r=>r.rate===null)") is True and E("alerts.filter(a=>a.dq).length")==1)
        pg.evaluate("resetLiveDemo(false)"); pg.wait_for_timeout(100)
    pg.wait_for_timeout(1300)
    pg.wait_for_timeout(800)  # startLiveDemo ignores a second start within 700 ms (double-click guard)
    E("(()=>{startLiveDemo();clearInterval(DEMO.timer);DEMO.timer=null;DEMO.script=Array.from({length:150},(_,i)=>110+(i*7)%13);})()"); tick(3)
    E("(()=>{document.getElementById('ldFaultSel').value='frozen';demoInjectFault()})()"); tick(9)
    T('Live Demo frozen fault: SUSPECTED_FROZEN is flagged as UNCERTAIN (advisory), the reading stays usable and is not displayed as unavailable',E("DEMO.sensor.state")=='SUSPECTED_FROZEN' and E("demoStaff().dataStatus")=='uncertain' and E("alerts.filter(a=>a.dq&&/suspected frozen/.test(a.title)).length")==1 and 'DATA UNCERTAIN' in pg.inner_text('#ldNow'))
    pg.evaluate("resetLiveDemo(false)")
    # ================= 11. UI structure, exports, responsive =================
    pg.evaluate("showView('simlab')"); pg.click('#ssTabs [data-ss="S7"]')
    T('Safety section lists 7 scenario tabs S7–S13; original six tabs still exist',pg.locator('#ssTabs .sl-tab').count()==7 and pg.locator('#slTabs .sl-tab').count()==6)
    pg.click('text=Run all 7'); pg.wait_for_timeout(200)
    tb=pg.evaluate("[...document.querySelectorAll('#ssTbl tbody tr')].map(r=>[...r.cells].map(c=>c.innerText))")
    sm=list(csv.DictReader(io.StringIO(E("SafetyLab.summaryCsv()"))))
    T('Displayed table (TP/FP/FN, DQ TP/FP/FN, unmonitored minutes, incidents, naive notifications) equals the summary CSV for all 7 scenarios',len(tb)==7 and all(tb[i][2]==sm[i]['rad_TP'] and tb[i][3]==sm[i]['rad_FP'] and tb[i][4]==sm[i]['rad_FN'] and tb[i][6]==sm[i]['dq_TP'] and tb[i][7]==sm[i]['dq_FP'] and tb[i][8]==sm[i]['dq_FN'] and tb[i][11]==sm[i]['unmonitored_min'] and tb[i][13]=='%s / %s'%(sm[i]['incidents_radiation'],sm[i]['incidents_dq']) and tb[i][14]==sm[i]['naive_alert_notifications'] and tb[i][15]==sm[i]['incidents_unresolved_at_end'] for i in range(7)))
    with pg.expect_download() as dl: pg.click('text=Export step data (CSV) >> nth=1') if False else pg.evaluate("SafetyLab.downloadSteps()")
    T('Downloaded safety step CSV equals the in-page CSV',open(dl.value.path(),encoding='utf-8').read()==E("SafetyLab.stepsCsv()"))
    with pg.expect_download() as dl: pg.evaluate("SafetyLab.downloadSummary()")
    T('Downloaded safety summary equals the in-page summary',open(dl.value.path(),encoding='utf-8').read()==E("SafetyLab.summaryCsv()"))
    with pg.expect_download() as dl: pg.evaluate("SafetyLab.downloadReport()")
    rep=open(dl.value.path(),encoding='utf-8').read()
    T('Safety report states SIMULATED, no hardware, and that missing data is never zero exposure',('ALL DATA IS SIMULATED' in rep) and ('no hardware' in rep.lower()) and ('never treated as zero exposure' in rep))
    pg.click('text=Run before / after comparison'); pg.wait_for_timeout(500)
    T('Before/after tables render: 10 validation rows (all rejected after) and 15 policy rows',pg.locator('#ssCompare table >> nth=0').locator('tbody tr').count()==10 and pg.locator('#ssPolTbl tbody tr').count()==15 and 'REJECTED' in pg.inner_text('#ssCompare'))
    des=pg.inner_text('#ssDesign') if pg.locator('#ssDesign').count() else ''
    pg.evaluate("document.querySelector('#slSafetyCard details:nth-of-type(2)').open=true"); des=pg.inner_text('#ssDesign')
    T('Safety design text documents ranges and their basis, sensor states, simulation assumption, observed vs complete dose, and "not regulatory"',all(k in des for k in ['Valid input ranges','simulation conventions, not regulatory','STALE','SUSPECTED_FROZEN','uncertain, not a proven fault','simulation assumption','NOT a lower bound'.lower().replace('not a lower bound','lower bound'),'no upper bound']))
    T('No regulatory/annual limit is used or drawn as an instantaneous threshold in the safety section',('annual' not in pg.inner_text('#slSafetyCard').lower()) and ('mSv/yr' not in pg.inner_text('#slSafetyCard')))
    sec=pg.inner_text('#slSafetyCard')
    T('Safety section: no claim of hardware connectivity, clinical validity, certification or trained AI (negations only)',not re.search(r'(?<!no )(?<!not )(?<!no real )\b(clinically validated|certified|FDA|regulatory[- ]compliant)\b',sec,re.I) and 'no real device' in sec.lower() and 'simulated' in sec.lower())
    pg.set_viewport_size({'width':390,'height':800}); pg.evaluate("document.getElementById('slSafetyCard').scrollIntoView()"); pg.wait_for_timeout(250)
    T('Mobile 390 px: no horizontal page overflow with the Safety section and tables',E("document.documentElement.scrollWidth")<=392,str(E("document.documentElement.scrollWidth")))
    T('Mobile: all safety tables sit in scrolling wrappers; all safety SVGs have accessible names',E("[...document.querySelectorAll('#slSafetyCard table')].every(t=>t.closest('.sl-tw')||t.classList.contains('sl-mini'))") is True and E("[...document.querySelectorAll('#slSafetyCard svg')].every(s=>s.getAttribute('role')==='img'&&s.getAttribute('aria-label'))") is True)
    pg.set_viewport_size({'width':1400,'height':1000})
    T('Safety inputs are labelled',E("[...document.querySelectorAll('#slSafetyCard input,#slSafetyCard select')].every(e=>document.querySelector('label[for=\"'+e.id+'\"]'))") is True)
    pg.click('text=Reset >> nth=-1') if False else pg.evaluate("SafetyLab.reset()")
    T('Reset clears Safety results and comparison',E("Object.keys(SafetyLab.results()).length")==0 and 'Not run yet' in pg.inner_text('#ssTable'))
    # determinism
    h1=E("(()=>{SafetyLab.runAll();return SafetyLab.stepsCsv()})()"); h2=E("(()=>{SafetyLab.reset();SafetyLab.runAll();return SafetyLab.stepsCsv()})()")
    T('Safety scenarios are deterministic: reset + rerun gives byte-identical step CSV',h1==h2)
    f1=E("SafetyLab.runScenario(SafetyLab.SC[1],1,0).fingerprint"); f2=E("SafetyLab.runScenario(SafetyLab.SC[1],1,1).fingerprint")
    T('Seed offset changes the realisation (fingerprints differ)',f1!=f2)
    T('Safety scenarios do not touch the app state (staff, alerts, recommendations unchanged by running all 7 + comparison)',E("(()=>{const a=snapshotWorld();SafetyLab.runAll();SafetyLab.compare();return a===snapshotWorld()&&a===WORLD0})()") is True)
    BR.close()
finally:
    srv1.terminate(); srv2.terminate()
T('No JavaScript errors / console errors / dialogs during the whole Phase-3 run',len(errs)==0,str(errs[:5]))
json.dump(R,open(ROOT+'/logs/results_phase3.json','w'))
print('\n',sum(1 for r in R if r[1]=='PASS'),'passed,',sum(1 for r in R if r[1]=='FAIL'),'failed')


# ---- exit-code footer (M-01): added in the Final Candidate; no assertion changed
import sys as _sys
_sys.exit(1 if any(r[1]=='FAIL' for r in R) else 0)
