import os as _os
ROOT=_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))   # package root: all paths are relative to it
"""Final-candidate regression tests: one targeted group per corrected defect (H-01, M-04, M-05, M-06, M-07, M-01).
Run against the candidate (TARGET=cand, default) and, to prove the tests can detect the defects, against the untouched Phase-3 baseline (TARGET=base).
All expectations are derived independently (exact arithmetic / hand values), not from the app's own output."""
import subprocess,time,json,os,sys,re
from fractions import Fraction
from playwright.sync_api import sync_playwright
W=ROOT
TARGET=os.environ.get('TARGET','cand')
DIR=W+('/env/new' if TARGET=='cand' else '/env/base'); PORT=8860 if TARGET=='cand' else 8861
srv=subprocess.Popen(['python3','-m','http.server',str(PORT),'-d',DIR],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL); time.sleep(1)
R=[];errs=[]
def T(name,cond,detail=''):
    R.append((name,'PASS' if cond else 'FAIL',detail)); print(('PASS' if cond else 'FAIL'),'-',name,detail)
def ols(y):
    n=len(y); xs=range(n); mx=Fraction(sum(xs),n); my=Fraction(sum(y),n)
    sl=sum((x-mx)*(v-my) for x,v in zip(xs,y))/sum((x-mx)**2 for x in xs)
    return sl, [my+sl*(n+k-mx) for k in range(3)]   # next 3 points at x=n..n+2
def rnd(f): return max(0,int((f*2+1)//2)) if f>=0 else 0   # round half up, floor at 0 (values here are positive, non-.5)
try:
  with sync_playwright() as p:
    BR=p.chromium.launch(); ctx=BR.new_context(viewport={'width':1440,'height':900}); pg=ctx.new_page(); E=pg.evaluate
    pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.on('console',lambda m: errs.append(m.text) if m.type=='error' and 'Failed to load resource' not in m.text and 'ERR_' not in m.text else None)
    pg.on('dialog',lambda d:(errs.append('dialog'),d.dismiss()))
    pg.route('**/fonts.googleapis.com/**',lambda r:r.abort()); pg.route('**/fonts.gstatic.com/**',lambda r:r.abort())
    pg.goto(f'http://localhost:{PORT}/alarad_prototype.html'); pg.wait_for_timeout(500)
    def setup():
        E("(()=>{resetLiveDemo(false);DEMO.flags.started=true;DEMO.startedAt=0;})()")
    def tick(n=1): E(f"(()=>{{for(let i=0;i<{n};i++)demoTick()}})()")
    def txt(sel): return pg.inner_text(sel)
    def Tt(sel):
        try: return pg.inner_text(sel,timeout=800)
        except Exception: return ''
    def Et(js):
        try: return E(js)
        except Exception: return None   # element/function absent in the baseline = the defect
    sid=E("DEMO.staffId")
    def row(): return E(f"(()=>{{const t=[...document.querySelectorAll('#staffTable tr')].find(r=>r.innerText.includes('{sid}'));return t?t.innerText:''}})()")
    def rowhtml(): return E(f"(()=>{{const t=[...document.querySelectorAll('#staffTable tr')].find(r=>r.innerText.includes('{sid}'));return t?t.innerHTML:''}})()")
    # ================= H-01 =================
    T('H-01 baseline state: no UNKNOWN / incomplete wording on any staff surface when monitoring is available',
      all(('UNKNOWN' not in s and 'incomplete' not in s.lower()) for s in [txt('#staffTable'),txt('#staffMiniList'),pg.inner_html('#floorMap')]) and Et("document.getElementById('unkBanner').style.display")in(None,'none'))
    setup(); d0=E(f"staff.find(s=>s.id==='{sid}').today"); tick(3)   # 112,121,118
    d_valid=E(f"staff.find(s=>s.id==='{sid}').today"); exp=d0+(112+121+118)/60/1000
    T('H-01 pre-outage: three valid minutes integrate 112+121+118 µSv/h /60/1000 (dose math reference)',abs(d_valid-exp)<1e-4,f'{d_valid} vs {exp:.6f}')
    E("DEMO.fault={kind:'disconnect',value:null}"); tick(3)
    d_out=E(f"staff.find(s=>s.id==='{sid}').today")
    T('H-01 outage: observed dose unchanged by unmonitored minutes (no dose added, dose math untouched)',d_out==d_valid,f'{d_out} vs {d_valid}')
    T('H-01 outage: record keeps dataStatus unknown and 3 unmonitored minutes',E(f"(()=>{{const s=staff.find(s=>s.id==='{sid}');return s.dataStatus==='unknown'&&(s.unmonMin===3||s.unmonMin===undefined)}})()") and E("DEMO.unmon")==3)
    r=row()
    T('H-01 Staff Monitor shows UNKNOWN — MONITORING UNAVAILABLE for the worker',('UNKNOWN — MONITORING UNAVAILABLE' in r),r.replace('\n',' | '))
    T('H-01 Staff Monitor does not show a NORMAL badge for the worker during the outage','badge normal' not in rowhtml() and not re.search(r'\bNORMAL\b',r))
    T('H-01 Staff Monitor marks the observed dose as incomplete with the unmonitored duration','incomplete' in r.lower() and '3 min' in r,r.replace('\n',' | '))
    mini=E(f"(()=>{{const t=document.querySelector('.staff-mini-row[data-id=\"{sid}\"]');return t?t.innerText:''}})()")
    T('H-01 Dashboard mini staff list shows UNKNOWN for the worker','UNKNOWN' in mini,mini.replace('\n',' | '))
    fm=pg.inner_html('#floorMap')
    T('H-01 Floor map marks the worker UNKNOWN (label + tooltip) and not with the normal green dot',('UNKNOWN' in fm) and E(f"(()=>{{const g=[...document.querySelectorAll('#floorMap .staff-dot')].find(g=>g.textContent.includes('{sid}'));return g?g.querySelector('circle:last-of-type').getAttribute('fill'):''}})()")!='#34d399')
    E(f"selectStaff('{sid}')"); panel=txt('#staffInfoPanel')
    T('H-01 Selected-staff panel shows UNKNOWN and incomplete dose','UNKNOWN — MONITORING UNAVAILABLE' in panel and 'incomplete' in panel.lower(),panel.replace('\n',' | '))
    E("showView('dashboard')"); dash=txt('#view-dashboard')
    T('H-01 Dashboard shows an UNKNOWN — MONITORING UNAVAILABLE banner with the count of affected workers',Et("document.getElementById('unkBanner').style.display")=='flex' and Et("document.getElementById('unkCount').textContent")=='1' and 'UNKNOWN — MONITORING UNAVAILABLE' in dash,dash[:200].replace('\n',' | '))
    T('H-01 Dashboard KPI no longer says the worker is "Under monitoring" (monitored / UNKNOWN split)','UNKNOWN (monitoring unavailable)' in Tt('#kpiStaffSub') and 'Under monitoring' not in Tt('#kpiStaffSub'),Tt('#kpiStaffSub'))
    E("showView('staff')")
    others=E(f"staff.filter(s=>s.id!=='{sid}').every(s=>!s.dataStatus)")
    T('H-01 other workers are unaffected (no dataStatus, display unchanged)',others and txt('#staffTable').count('UNKNOWN — MONITORING UNAVAILABLE')==1)
    # recovery
    E("DEMO.fault=null"); tick(2)   # 190 and 310 valid again
    r2=row()
    E("showView('dashboard')"); T('H-01 recovery: Dashboard banner clears and the KPI returns to "Under monitoring"',Et("document.getElementById('unkBanner').style.display")=='none' and Tt('#kpiStaffSub')=='Under monitoring',Tt('#kpiStaffSub')); E("showView('staff')")
    T('H-01 recovery: UNKNOWN clears when valid data returns, but the dose stays marked incomplete (3 min unmonitored)','UNKNOWN — MONITORING UNAVAILABLE' not in r2 and '3 min' in r2,r2.replace('\n',' | '))
    # radiation incident preserved through an outage
    setup(); tick(9)  # through 420 -> abnormal exposure flagged
    inc_flag=E(f"staff.find(s=>s.id==='{sid}').incidentFlag"); st_before=E(f"staff.find(s=>s.id==='{sid}').status"); dose_b=E(f"staff.find(s=>s.id==='{sid}').today")
    E("DEMO.script.push(470,470,470)"); E("DEMO.fault={kind:'disconnect',value:null}"); tick(2)
    pg.wait_for_timeout(2200)   # let the delayed simulated notifications fire
    r=row()
    T('H-01 incident case: radiation incident still flagged on the record (status/flag preserved, not cleared by the outage)',bool(inc_flag) and E(f"staff.find(s=>s.id==='{sid}').incidentFlag")==inc_flag and E(f"staff.find(s=>s.id==='{sid}').status")==st_before=='critical')
    T('H-01 incident case: Staff Monitor shows UNKNOWN + "radiation incident still open" + last assessed CRITICAL (historical)','UNKNOWN — MONITORING UNAVAILABLE' in r and 'radiation incident still open' in r and 'CRITICAL' in r,r.replace('\n',' | '))
    T('H-01 incident case: the radiation alert stays open and a separate DATA QUALITY alert exists',E("(()=>{const a=alerts.find(x=>x.id===DEMO.alertId);return !!a&&!a.resolved})()") and E("alerts.some(a=>a.dq&&a.category==='DATA QUALITY')"))
    T('H-01 incident case: dose unchanged during outage (no added dose)',E(f"staff.find(s=>s.id==='{sid}').today")==dose_b)
    T('H-01 incident case: critical banner still counts the worker with the open incident (count = number of workers whose record status is critical)',E("document.getElementById('critBanner').style.display")!='none' and txt('#critCount')==str(E("staff.filter(s=>s.status==='critical').length")) and E(f"staff.find(s=>s.id==='{sid}').status")=='critical')
    # ================= M-04 =================
    setup(); tick(4)
    T('M-04 while the stream is running the fault controls are enabled',Et("!document.getElementById('ldInjectBtn').disabled && !document.getElementById('ldClearBtn').disabled"))
    tick(7)   # whole 10-entry script consumed + end-of-stream tick; incident detected, worker has not acknowledged -> stream paused
    note=pg.inner_text('#ldFaultNote') if pg.locator('#ldFaultNote').count() else ''
    health=txt('#ldHealth')
    T('M-04 paused (awaiting worker acknowledgement): controls disabled with an explanation of why and when they return',Et("document.getElementById('ldInjectBtn').disabled && document.getElementById('ldClearBtn').disabled") is True and 'acknowledg' in note.lower(),note or 'controls not disabled / no note')
    E("document.getElementById('ldFaultSel').value='frozen'"); E("demoInjectFault()")
    T('M-04 paused: injecting is refused (no fault set, no misleading log entry)',E("DEMO.fault")is None and not any('injected' in e['label'] for e in E("DEMO.events")))
    # acknowledge -> recovery ticks resume; inject disconnect while running; stream then ends with the fault still active
    pg.wait_for_timeout(900); E("demoWorkerLeaves()")
    T('M-04 after acknowledgement the stream resumes and the controls are enabled again',Et("!document.getElementById('ldInjectBtn').disabled && !document.getElementById('ldClearBtn').disabled"))
    E("document.getElementById('ldFaultSel').value='disconnect'"); E("demoInjectFault()"); tick(4); tick(1)
    note=pg.inner_text('#ldFaultNote') if pg.locator('#ldFaultNote').count() else ''; health=txt('#ldHealth')
    T('M-04 precondition: the scripted stream has ended',E("DEMO.idx>=DEMO.script.length") is True)
    T('M-04 ended: fault controls disabled and the explanation says the stream ended',Et("document.getElementById('ldInjectBtn').disabled && document.getElementById('ldClearBtn').disabled") is True and 'ended' in note.lower(),note or 'controls not disabled / no note')
    T('M-04 ended: health line names the last-sample state and says the stream ended (not a bare HEALTHY + "(fault active…)")',('ended' in health.lower()) and not ('HEALTHY' in health and '(fault active' in health),health)
    E("demoClearFault()"); T('M-04 ended: restoring the link is refused (no "samples arrive again" log entry)',not any('restored' in e['label'] for e in E("DEMO.events")))
    n_alerts=E("alerts.length"); E("document.getElementById('ldFaultSel').value='frozen'"); E("demoInjectFault()")
    T('M-04 ended: injecting is refused',E("DEMO.fault.kind")=='disconnect')
    # ================= M-05 =================
    setup(); tick(3)
    sl,_=ols([112,121,118]); tr=txt('#ldFactors')
    T('M-05 valid data (3 contiguous): regression slope is shown with the unchanged OLS formula',f'regression slope {float(sl):.1f}' in tr,tr[-160:].replace('\n',' '))
    tick(1); sl4,nx4=ols([112,121,118,126]); tr=txt('#ldFactors')
    fc=E("[...document.querySelectorAll('#ldChart .ld-bar.fc')].map(e=>e.title)")
    T('M-05 valid data (4 contiguous): slope and 3-step forecast equal an independent exact OLS',f'regression slope {float(sl4):.1f}' in tr and fc==[f'forecast {rnd(v)} µSv/h' for v in nx4],f'{fc} vs {[rnd(v) for v in nx4]}')
    E("DEMO.fault={kind:'disconnect',value:null}"); tick(2)
    tr=txt('#ldFactors'); fc=E("document.querySelectorAll('#ldChart .ld-bar.fc').length")
    T('M-05 during a data gap: no "regression slope 0.0" is displayed',('regression slope 0.0' not in tr),tr[-120:].replace('\n',' '))
    T('M-05 during a data gap: trend is UNAVAILABLE and no forecast bars are drawn','UNAVAILABLE' in tr and fc==0,f'bars={fc}')
    E("DEMO.fault=null"); tick(1)
    T('M-05 after the gap, 1 valid reading: still UNAVAILABLE, no forecast across the gap','UNAVAILABLE' in txt('#ldFactors') and E("document.querySelectorAll('#ldChart .ld-bar.fc').length")==0)
    tick(1)
    T('M-05 after the gap, 2 valid readings: still UNAVAILABLE',  'UNAVAILABLE' in txt('#ldFactors') and E("document.querySelectorAll('#ldChart .ld-bar.fc').length")==0)
    tick(1)   # 3rd contiguous valid: 190,310,420
    s3,n3=ols([190,310,420]); tr=txt('#ldFactors'); fc=E("[...document.querySelectorAll('#ldChart .ld-bar.fc')].map(e=>e.title)")
    T('M-05 3 contiguous valid readings after the gap: forecast uses ONLY those 3 (pre-gap values excluded)',f'regression slope {float(s3):.1f}' in tr and fc==[f'forecast {rnd(v)} µSv/h' for v in n3],f'{fc} / {tr[-100:]}'.replace('\n',' '))
    # ================= M-06 =================
    ws=lambda u,unc,st,rc: E(f"AlaradSafety.workerStatus({{usable:{str(u).lower()},uncertain:{str(unc).lower()},state:'{st}',riskClass:'{rc}'}})")
    a=ws(True,True,'SUSPECTED_FROZEN','low'); b=ws(True,True,'SUSPECTED_FROZEN','high'); c=ws(False,False,'DISCONNECTED','low'); d=ws(True,False,'HEALTHY','low')
    T('M-06 suspected-frozen status leads with uncertainty, not NORMAL',a.startswith('UNCERTAIN') and not a.startswith('NORMAL'),a)
    T('M-06 suspected-frozen still reports the last assessed class (NORMAL / CRITICAL), without hiding a high class',('last assessed: NORMAL' in a) and ('last assessed: CRITICAL' in b) and b.startswith('UNCERTAIN'),a+' || '+b)
    T('M-06 confirmed unavailability is still a distinct, unchanged status; healthy status unchanged',c=='UNKNOWN — MONITORING UNAVAILABLE' and d=='NORMAL',c+' / '+d)
    setup(); tick(3); E("DEMO.fault={kind:'frozen',value:null}"); tick(7)
    T('M-06 precondition: Live Demo reaches SUSPECTED_FROZEN',E("DEMO.sensor.state")=='SUSPECTED_FROZEN' and E(f"demoStaff().dataStatus")=='uncertain')
    nowtxt=txt('#ldNow'); wsx=pg.inner_text('.watch .w-status')
    T('M-06 Live Demo employee status leads with UNCERTAIN (suspected frozen sensor)','UNCERTAIN — suspected frozen sensor' in nowtxt and 'badge normal' not in pg.inner_html('#ldNow').split('Employee status')[-1],nowtxt.replace('\n',' | ')[-120:])
    T('M-06 smartwatch face does not say NORMAL while the sensor is suspected frozen',wsx=='DATA UNCERTAIN',wsx)
    T('M-06 frozen is not shown as disconnection (still usable, not UNKNOWN, dose still integrating)',E(f"demoStaff().dataStatus")!='unknown' and 'UNKNOWN — MONITORING UNAVAILABLE' not in txt('#ldNow'))
    # ================= N-01 (suspected frozen on staff surfaces) =================
    setup(); tick(3); E("DEMO.fault={kind:'frozen',value:null}"); tick(7)
    T('N-01 precondition: sensor SUSPECTED_FROZEN, record dataStatus uncertain',E("DEMO.sensor.state")=='SUSPECTED_FROZEN' and E("demoStaff().dataStatus")=='uncertain')
    E("showView('staff')"); r=row(); rh=rowhtml()
    T('N-01 Staff Monitor shows DATA UNCERTAIN — suspected frozen sensor (uncertainty first, not a NORMAL badge)','DATA UNCERTAIN — suspected frozen sensor' in r and 'badge normal' not in rh,r.replace('\n',' | '))
    T('N-01 Staff Monitor does not present it as a confirmed failure or as unavailable','UNKNOWN — MONITORING UNAVAILABLE' not in r and 'DISCONNECT' not in r.upper() and 'not a confirmed sensor failure' in r,r.replace('\n',' | '))
    T('N-01 Staff Monitor states it is not a verified current measurement','not a verified current measurement' in r)
    mini=E(f"(()=>{{const t=document.querySelector('.staff-mini-row[data-id=\"{sid}\"]');return t?t.innerText:''}})()")
    T('N-01 mini staff list shows DATA UNCERTAIN','DATA UNCERTAIN' in mini,mini.replace('\n',' | '))
    fm=pg.inner_html('#floorMap')
    T('N-01 floor map labels the worker UNCERTAIN (label + tooltip, dashed outline)','· UNCERTAIN' in fm and 'DATA UNCERTAIN' in fm and 'stroke-dasharray' in fm)
    E(f"selectStaff('{sid}')"); panel=txt('#staffInfoPanel')
    T('N-01 selected-staff panel shows DATA UNCERTAIN','DATA UNCERTAIN' in panel,panel.replace('\n',' | ')[:200])
    E("showView('dashboard')")
    T('N-01 Dashboard shows a DATA UNCERTAIN banner (count 1) and the UNKNOWN banner stays hidden',Et("document.getElementById('uncBanner').style.display")=='flex' and Et("document.getElementById('uncCount').textContent")=='1' and Et("document.getElementById('unkBanner').style.display")=='none')
    T('N-01 Dashboard KPI sub-line mentions DATA UNCERTAIN and no longer says "Under monitoring"','DATA UNCERTAIN' in Tt('#kpiStaffSub') and 'Under monitoring' not in Tt('#kpiStaffSub'),Tt('#kpiStaffSub'))
    T('N-01 frozen readings still integrate dose (usable, unchanged math): 7 repeated 118 µSv/h minutes added',abs(E(f"staff.find(s=>s.id==='{sid}').today")-(d0+(112+121+118+7*118)/60/1000))<6e-4,str(E(f"staff.find(s=>s.id==='{sid}').today")))
    E("DEMO.fault=null; DEMO.script.push(120,130,140)"); tick(3)
    E("showView('staff')"); r2=row()
    T('N-01 recovery: two changed samples clear the marker on Staff Monitor and Dashboard','DATA UNCERTAIN' not in r2 and Et("document.getElementById('uncBanner').style.display")=='none' and Tt('#kpiStaffSub')=='Under monitoring',r2.replace('\n',' | '))
    # ================= N-03 (static test card) =================
    E("showView('simlab')"); pg.wait_for_timeout(300)
    card=Tt('#slValCard')
    T('N-03 the embedded test table is labelled STATIC RECORD / NOT LIVE VERIFICATION EVIDENCE and says the page runs no tests','STATIC RECORD' in Tt('#slStaticTestBanner') and 'NOT LIVE' in Tt('#slStaticTestBanner').upper() and 'does not run any test' in Tt('#slStaticTestBanner'),Tt('#slStaticTestBanner')[:120])
    T('N-03 the card says which build the record was made for and that it was not updated',('Recorded for the Phase-3 build' in card) and ('NOT updated for later builds' in card),'')
    stt=Et("JSON.stringify(SL_TEST_STATUS)") or ''
    T('N-03 static record no longer claims the 87 are "unchanged" nor that the status card adds a check',('unchanged' not in stt) and ('adds one check' not in stt) and ('conditional placeholder' in stt),stt[:100])
    T('N-03 the heading still contains "Test execution" and table rows = suites + total (original check preserved)',E("[...document.querySelectorAll('#slValCard h4')].find(h=>h.textContent.includes('Test execution')).nextElementSibling.querySelectorAll('tbody tr').length")==5)
    # ================= M-07 =================
    def sw(w,h): pg.set_viewport_size({'width':w,'height':h}); pg.wait_for_timeout(250)
    views=E("[...document.querySelectorAll('.nav-item[data-view]')].map(a=>a.dataset.view)")
    bad=[]
    sw(768,1024)
    for v in views:
        E(f"showView('{v}')"); pg.wait_for_timeout(120)
        if E("document.documentElement.scrollWidth")>768: bad.append((v,E("document.documentElement.scrollWidth")))
    T(f'M-07 tablet 768: no horizontal page overflow on any of the {len(views)} views',not bad,str(bad))
    E("showView('staff')"); sw(768,1024)
    T('M-07 tablet: the Staff Monitor table scrolls inside its card (content still reachable)',E("(()=>{const t=document.querySelector('#view-staff .card table');return getComputedStyle(t).overflowX==='auto'&&t.scrollWidth>=t.clientWidth})()"))
    E("showView('policy')"); sw(768,1024)
    T('M-07 tablet: Policy Mapping has no page overflow',E("document.documentElement.scrollWidth")<=768)
    E("showView('staff')")
    sw(1440,900); disp_d=E("getComputedStyle(document.querySelector('#view-staff .card table')).display")
    sw(1101,900); disp_1101=E("getComputedStyle(document.querySelector('#view-staff .card table')).display")
    sw(390,844); disp_m=E("getComputedStyle(document.querySelector('#view-staff .card table')).display"); ov_m=E("document.documentElement.scrollWidth")
    T('M-07 desktop (1440 and 1101) layout untouched: tables keep display:table',disp_d=='table' and disp_1101=='table',f'{disp_d}/{disp_1101}')
    T('M-07 mobile (390) layout untouched: tables keep their existing scroll-block rule and the page does not overflow',disp_m=='block' and ov_m<=392,f'{disp_m}/{ov_m}')
    sw(1440,900)
    # ================= misc =================
    T('No JavaScript errors / dialogs during the final-fixes run',len(errs)==0,str(errs[:5]))
    BR.close()
finally:
  srv.terminate()
out=W+('/logs/results_final_fixes_%s.json'%TARGET)
json.dump(R,open(out,'w'))
print('\n',sum(1 for r in R if r[1]=='PASS'),'passed,',sum(1 for r in R if r[1]=='FAIL'),'failed (TARGET=%s)'%TARGET)
sys.exit(1 if any(r[1]=='FAIL' for r in R) else 0)
