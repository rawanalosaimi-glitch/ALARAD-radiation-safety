import os as _os
ROOT=_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))   # package root: all paths are relative to it
import subprocess,time,json,re
from playwright.sync_api import sync_playwright
srv=subprocess.Popen(['python3','-m','http.server','8781','-d',ROOT+'/env/new'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);time.sleep(1)
R=[]   # (id, name, status, detail)
errs=[]
def T(name,cond,detail=''):
    R.append((name,'PASS' if cond else 'FAIL',detail)); print(('PASS' if cond else 'FAIL'),'-',name,detail)
def txt(pg,sel): return pg.inner_text(sel)
try:
  with sync_playwright() as p:
    b=p.chromium.launch(args=['--no-sandbox']); ctx=b.new_context(viewport={'width':1400,'height':900}); pg=ctx.new_page()
    pg.on('pageerror',lambda e:errs.append('PAGEERROR '+str(e)))
    pg.on('console',lambda m: errs.append('CONSOLE '+m.text) if m.type=='error' and 'ERR_TUNNEL' not in m.text and 'font' not in m.text.lower() else None)
    pg.on('dialog',lambda d:(errs.append('DIALOG '+d.message),d.dismiss()))
    pg.goto('http://localhost:8781/alarad_prototype.html'); pg.wait_for_timeout(500)

    # ---- navigation
    views=pg.eval_on_selector_all('.nav-item','e=>e.map(x=>x.dataset.view)')
    ok=True
    for v in views:
        pg.click(f'.nav-item[data-view="{v}"]')
        ok &= pg.is_visible(f'#view-{v}')
    T('All 13 nav links open their view (was 12 before Simulation Lab was added)',ok and len(views)==13,f'{len(views)} views')
    pg.focus('.nav-item[data-view="staff"]'); pg.keyboard.press('Enter')
    T('Nav items keyboard-operable (Enter)',pg.is_visible('#view-staff'))
    pg.click('.nav-item[data-view="dashboard"]')

    # ---- initial consistency
    T('KPI active staff = 10',txt(pg,'#kpiStaff')=='10')
    T('KPI recs pending = 4 (matches 4 cards)',txt(pg,'#kpiRecs')=='4')
    T('Initial critical count = 2 (ST-04, ST-06)',txt(pg,'#critCount')=='2')
    T('Avg cumulative KPI computed (10.5 mSv)',txt(pg,'#kpiDose')=='10.5 mSv',txt(pg,'#kpiDose'))
    T('Topbar says SIMULATED, not LIVE',('SIMULATED' in txt(pg,'.live-pill')) and 'LIVE' not in txt(pg,'.live-pill'))

    # ---- physics: engine called directly
    ev=lambda a: pg.evaluate("a=>{const r=evaluateExposure(a);return {kind:r.kind,wr:r.workerRate,cum:r.cumulativeDose,dev:r.deviation,cls:r.riskClass}}",a)
    r=ev({'room':'Cath Lab 1','procMult':1.0,'rate':180,'dur':45,'dist':0.5,'refDist':3,'shield':0.15,'mode':'personal'})
    T('Personal mode ignores distance & shielding (measured = used)',abs(r['wr']-180)<1e-9 and r['kind']=='measured',str(r['wr']))
    r=ev({'room':'Cath Lab 1','procMult':1.0,'rate':180,'dur':45,'dist':2,'refDist':1,'shield':0.4,'mode':'area'})
    T('Area mode: 180×(1/2)²×0.4 = 18 µSv/h modeled',abs(r['wr']-18)<1e-9 and r['kind']=='modeled',str(r['wr']))
    T('Units: 180 µSv/h × 45 min = 0.135 mSv',abs(ev({'room':'Cath Lab 1','procMult':1.0,'rate':180,'dur':45,'mode':'personal'})['cum']-0.135)<1e-9)
    # form default regression: ELEVATED like before
    pg.click('.nav-item[data-view="anomaly"]'); pg.click('text=Recalculate Model')
    res=txt(pg,'#anomalyResult')
    T('Form default → ELEVATED, labelled MEASURED AT WORKER',('ELEVATED RISK' in res) and ('MEASURED AT WORKER' in res))
    T('Result says seeded history is SIMULATED',('SIMULATED' in res))
    T('Distance/shield fields disabled in personal mode',pg.is_disabled('#inDist') and pg.is_disabled('#inShield') and pg.is_disabled('#inRefDist'))
    pg.select_option('#inMode','area')
    T('Area mode enables distance/shield fields',pg.is_enabled('#inDist') and pg.is_enabled('#inShield'))
    pg.fill('#inRate','500'); pg.select_option('#inMode','personal'); pg.fill('#inRate','500'); pg.click('text=Recalculate Model')
    res=txt(pg,'#anomalyResult')
    T('High reading → CRITICAL — SUSPECTED ABNORMAL EXPOSURE (not "leak")',('SUSPECTED ABNORMAL' in res) and ('leak' not in res.lower() or 'not a confirmed leak' in res.lower()))
    # validation
    for bad,label in [('-5','negative rate'),('','empty'),('1e9','absurd rate')]:
        pg.fill('#inRate',bad); pg.click('text=Recalculate Model')
        T(f'Validation blocks {label}', txt(pg,'#anomalyErr')!='' and txt(pg,'#anomalyResult').strip()=='', repr(txt(pg,'#anomalyErr'))[:60])
    pg.fill('#inRate','500'); pg.fill('#inDur','0'); pg.click('text=Recalculate Model')
    T('Validation blocks duration 0',txt(pg,'#anomalyErr')!='')
    pg.fill('#inDur','45'); pg.select_option('#inMode','area'); pg.fill('#inDist','0.01'); pg.click('text=Recalculate Model')
    T('Validation blocks distance < 0.2 m (area mode)',txt(pg,'#anomalyErr')!='')
    pg.select_option('#inMode','personal'); pg.fill('#inRate','500'); pg.click('text=Recalculate Model')
    # escalate manual alert + dedupe
    pg.click('text=Raise as Suspected-Abnormal-Exposure Alert'); pg.wait_for_timeout(200)
    n1=pg.locator('#alertsList .alert-item:has-text("manual model run")').count()
    pg.click('.nav-item[data-view="anomaly"]'); pg.click('text=Recalculate Model'); pg.click('text=Raise as Suspected-Abnormal-Exposure Alert'); pg.wait_for_timeout(200)
    n2=pg.locator('#alertsList .alert-item:has-text("manual model run")').count()
    T('Escalate from model creates 1 alert and dedupes repeat',n1==1 and n2==1,f'{n1},{n2}')
    # thresholds config
    pg.click('.nav-item[data-view="anomaly"]')
    pg.fill('#cfgDevE','2'); pg.fill('#cfgDevC','1'); pg.click('text=Apply thresholds')
    T('Config rejects elevated ≥ critical',txt(pg,'#cfgErr')!='')
    pg.fill('#cfgDevE','0.3'); pg.fill('#cfgDevC','3'); pg.click('text=Apply thresholds')
    T('Config applies valid thresholds',pg.evaluate("CONFIG.devCritical")==3)
    pg.click('text=Restore defaults')
    T('Restore defaults works',pg.evaluate("CONFIG.devCritical")==1.5)

    # ---- Ask ALARAD
    pg.click('.nav-item[data-view="askai"]')
    T('Pipeline shows 4 future steps dashed',pg.locator('.pipe-step.future').count()==4)
    pg.fill('#aiQuestion','What should ALARAD do when a dose approaches the limit?'); pg.click('#view-askai .qbox button'); pg.wait_for_timeout(1500)
    a=txt(pg,'#aiAnswerArea')
    T('Answer states 5-year averaging & 50 mSv single-year',('5-year' in a) and ('50 mSv' in a))
    T('Answer shows NOT VERIFIED / PARTLY VERIFIED chips',('NOT VERIFIED' in a) and ('PARTLY VERIFIED' in a))
    T('Answer labelled pre-written / not LLM',('NOT LLM-GENERATED' in a))
    pg.fill('#aiQuestion','what is the weather in riyadh'); pg.click('#view-askai .qbox button'); pg.wait_for_timeout(1500)
    T('Unrelated question → fallback (no false keyword hit)','could not find a matching topic' in txt(pg,'#aiAnswerArea'))
    pg.fill('#aiQuestion','   '); pg.click('#view-askai .qbox button')
    T('Empty question gives a message, no crash','Type a question' in txt(pg,'#aiAnswerArea'))
    for chip in pg.locator('#view-askai .chip').all():
        chip.click(); pg.wait_for_timeout(1400)
        assert 'CURATED ANSWER' in txt(pg,'#aiAnswerArea') or 'NO MATCH' in txt(pg,'#aiAnswerArea')
    T('All 5 preset chips return an answer','CURATED ANSWER' in txt(pg,'#aiAnswerArea'))
    T('Leak chip answer says suspected, not confirmed',True) if False else None
    pg.locator('#view-askai .chip').nth(2).click(); pg.wait_for_timeout(1400)
    T('Leak chip → "suspected abnormal exposure … not a confirmed leak"','not a confirmed leak' in txt(pg,'#aiAnswerArea'))

    # ---- Recommendations
    pg.click('.nav-item[data-view="airec"]')
    pg.locator('#recList >> text=Apply Recommendation').first.click()
    T('Apply Recommendation changes state + log + KPI',('Applied' in txt(pg,'#recList')) and ('Applied:' in txt(pg,'#recLog')))
    pg.locator('#recList >> text=Dismiss').first.click()
    T('Dismiss changes state',('Dismissed' in txt(pg,'#recList')))
    pg.click('.nav-item[data-view="dashboard"]')
    T('KPI recs pending = 2 after apply+dismiss',txt(pg,'#kpiRecs')=='2')
    pg.click('.nav-item[data-view="airec"]'); pg.locator('#recList >> text=Undo').first.click()
    T('Undo reopens recommendation',pg.locator('#recList >> text=Apply Recommendation').count()==3)

    # ---- Exposure log / security / policy / wearable labels
    pg.click('.nav-item[data-view="exposure"]'); T('Exposure Log header unit µSv/h','Dose Rate (µSv/h)' in pg.evaluate("document.getElementById('view-exposure').textContent"))
    pg.click('.nav-item[data-view="security"]'); T('Security page flagged as DESIGN TARGET / not implemented','not implemented' in txt(pg,'#view-security') or 'DESIGN TARGET' in txt(pg,'#view-security'))
    pg.click('.nav-item[data-view="policy"]'); T('Policy page separates implemented vs planned retrieval','not implemented' in txt(pg,'#view-policy').lower() or 'Planned' in txt(pg,'#view-policy'))
    pg.click('.nav-item[data-view="wearable"]'); pg.click('text=Simulate Shift-Change Handoff'); T('Wearable handoff button works','Just now' in txt(pg,'#rotationLog'))

    # ---- Emergency / report to RSO + dedupe
    pg.click('.nav-item[data-view="emergency"]'); pg.locator('#staffMiniList .staff-mini-row').nth(3).click()
    pg.click('text=Report to Radiation Safety Officer'); pg.click('text=Report to Radiation Safety Officer')
    pg.click('.nav-item[data-view="alerts"]')
    T('Report to RSO dedupes duplicate clicks',pg.locator('#alertsList .alert-item:has-text("Manual report")').count()==1)
    T('Report toast says no real notification was sent','No real notification' in pg.evaluate("[...document.querySelectorAll('.toast')].map(t=>t.innerText).join(' ')"))

    # ---- Incident lifecycle on a seeded alert
    item=pg.locator('#alertsList .alert-item:has-text("ST-11")')
    T('Resolve not offered before ack',item.locator('text=Resolve').count()==0)
    item.locator('text=Acknowledge').click()
    T('Resolve disabled until an action exists',item.locator('button:has-text("Resolve")').is_disabled())
    # direct call guard
    T('resolveAlert() refuses without action',pg.evaluate("(()=>{const a=alerts.find(x=>/ST-11/.test(x.title));return resolveAlert(a.id,'x','')})()")==False)
    item.locator('text=Add Action').click(); pg.click('text=Save Action'); pg.wait_for_timeout(200)
    T('Action recorded with timestamp',re.search(r'\d\d:\d\d:\d\d — Rotate',txt(pg,'#alertsList'))is not None)
    item.locator('text=Add Action').click(); pg.click('text=Save Action')
    T('Duplicate identical action rejected',txt(pg,'#actErr')!='')
    pg.click('#actionModal >> text=Cancel')
    pg.locator('#alertsList .alert-item:has-text("ST-11")').locator('button:has-text("Resolve")').click()
    pg.click('#resolveModal button:has-text("Resolve Incident")')
    T('Resolution reason required',txt(pg,'#resErr')!='')
    pg.select_option('#resSel',index=2); pg.click('#resolveModal button:has-text("Resolve Incident")'); pg.wait_for_timeout(200)
    T('Resolved with reason + timestamp',('Resolution reason:' in txt(pg,'#alertsList')) and ('Resolved' in txt(pg,'#alertsList')))
    pg.keyboard.press('Escape')
    # info alert
    info=pg.locator('#alertsList .alert-item:has-text("Weekly compliance")'); info.locator('text=Acknowledge').click()
    T('Info alert needs no action: Archive enabled',info.locator('button:has-text("Archive")').is_enabled()); info.locator('button:has-text("Archive")').click()
    T('Info alert archived with auto reason','Informational' in txt(pg,'#alertsList'))

    # ---- Old simulate buttons
    pg.click('.nav-item[data-view="dashboard"]'); pg.click('text=Simulate Suspected Abnormal Exposure'); pg.wait_for_timeout(1600)
    T('Simulate abnormal exposure: banner count increases, alert added',int(txt(pg,'#critCount'))>=3 and pg.locator('text=Suspected abnormal exposure pattern').count()>0,txt(pg,'#critCount'))
    c_before=int(txt(pg,'#critCount'))
    pg.click('text=🚨 Simulate Radiation Incident'); pg.wait_for_timeout(8200)
    T('Simulate Radiation Incident completes, adds CRITICAL (active incident)',int(txt(pg,'#critCount'))==c_before+1 and pg.is_visible('#incidentTimelineCard'))
    # year dose must NOT jump to 18+ from a normal worker
    jump=pg.evaluate("staff.filter(s=>s.incidentFlag&&/Simulated incident/.test(s.incidentFlag)).map(s=>s.year)")
    T('Incident does not fake a jump in cumulative dose (<15 mSv yr for former NORMAL worker)',all(y<15 for y in jump),str(jump))
    pg.click('#incidentCloseBtn')

    # ---- Reset restores everything (before demo even runs)
    pg.click('.nav-item[data-view="livedemo"]'); pg.click('text=Reset Demo'); pg.wait_for_timeout(300)
    T('Reset restores crit count 2, KPI recs 4, alerts 6',(pg.evaluate("document.getElementById('critCount').textContent")=='2') and pg.evaluate("document.getElementById('kpiRecs').textContent")=='4' and pg.evaluate("alerts.length")==6)

    # ---- Manual live demo, full lifecycle
    pg.click('#ldStartBtn'); pg.wait_for_timeout(9800)
    st=txt(pg,'#ldStepper')
    T('Demo reaches detection, worker alert, RSO notification',all(k in st for k in ['Risk Detection']) and pg.evaluate("DEMO.flags.rso")==True)
    T('Staff ST-02 CRITICAL during incident',pg.evaluate("staff.find(s=>s.id==='ST-02').status")=='critical')
    T('Dashboard banner counts ST-02 (3)',pg.evaluate("document.getElementById('critCount').textContent")=='3')
    T('Alerts page lists the demo incident (SIMULATED)',pg.evaluate("alerts.some(a=>a.demo&&!a.resolved)"))
    wt=txt(pg,'#view-livedemo .watch')
    T('Smartwatch shows ID, status, rate, message',('ST-02' in wt) and ('ABNORMAL' in wt) and ('µSv/h' in wt) and ('SIMULATED' in wt))
    T('Timeline says simulated notification, no real device',('no real device contacted' in txt(pg,'#ldTimeline')) and ('no real person contacted' in txt(pg,'#ldTimeline')))
    T('Transparency lists threshold + EXCEEDED level',('CRITICAL' in txt(pg,'#ldFactors')) and ('critical ≥' in txt(pg,'#ldFactors')))
    T('Ack disabled? (Add Action / Resolve disabled before ack)',pg.locator('#ldRso button:has-text("Add Action")').is_disabled() and pg.locator('#ldRso button:has-text("Resolve")').is_disabled())
    pg.click('#view-livedemo .w-btn'); pg.wait_for_timeout(300)
    T('Worker acknowledgement on watch logged',('left the exposure area' in txt(pg,'#ldTimeline')))
    pg.click('#ldRso >> text=Acknowledge'); pg.wait_for_timeout(200)
    T('Resolve still disabled after ack (no action yet)',pg.locator('#ldRso button:has-text("Resolve")').is_disabled())
    pg.click('#ldRso >> text=Add Action'); pg.click('text=Save Action'); pg.wait_for_timeout(200)
    pg.click('#ldRso >> button:has-text("Resolve")'); pg.click('#resolveModal button:has-text("Resolve Incident")'); T('Demo resolve needs reason',txt(pg,'#resErr')!='')
    pg.select_option('#resSel',index=1); pg.click('#resolveModal button:has-text("Resolve Incident")'); pg.wait_for_timeout(400)
    T('Stepper complete (8/8 done)',pg.locator('#ldStepper .ld-step.done').count()==8,str(pg.locator('#ldStepper .ld-step.done').count()))
    T('After resolve: banner back to 2; ST-02 not critical',pg.evaluate("document.getElementById('critCount').textContent")=='2' and pg.evaluate("staff.find(s=>s.id==='ST-02').status")!='critical')
    T('ST-02 keeps the small recorded dose (not restored until reset)',pg.evaluate("staff.find(s=>s.id==='ST-02').today")>0.29)
    pg.click('.nav-item[data-view="alerts"]')
    T('Alerts page shows demo incident resolved w/ reason + timeline','Resolution reason:' in txt(pg,'#alertsList'))
    pg.click('.nav-item[data-view="livedemo"]'); pg.click('text=Reset Demo'); pg.wait_for_timeout(300)
    T('Reset after completion restores ST-02 dose 0.29 / 9.8',pg.evaluate("(()=>{const s=staff.find(s=>s.id==='ST-02');return s.today===0.29&&s.year===9.8})()"))

    # ---- Reset mid-run cancels pending events
    pg.click('#ldStartBtn'); pg.wait_for_timeout(8300)   # detected, pending watch/rso timeouts
    pg.click('text=Reset Demo'); pg.wait_for_timeout(2500)
    T('Reset mid-run: no late alert/watch/RSO events appear',pg.evaluate("alerts.length")==6 and pg.evaluate("DEMO.flags.rso")==False and pg.evaluate("DEMO.events.length")==0 and pg.evaluate("PENDING.size")==0)
    T('Reset mid-run: crit count 2, ST-02 normal',pg.evaluate("document.getElementById('critCount').textContent")=='2' and pg.evaluate("staff.find(s=>s.id==='ST-02').status")=='normal')
    # double click start
    pg.dblclick('#ldStartBtn'); pg.wait_for_timeout(1500)
    T('Double-click Start does not restart/duplicate',pg.evaluate("DEMO.idx")<=3)
    pg.click('text=Reset Demo')
    # reset during old incident modal
    pg.click('.nav-item[data-view="dashboard"]'); pg.click('text=🚨 Simulate Radiation Incident'); pg.wait_for_timeout(2500)
    pg.evaluate("resetLiveDemo(false)"); pg.wait_for_timeout(6000)
    T('Reset cancels in-flight Simulate Incident (no new alert, modal closed)',pg.evaluate("alerts.length")==6 and not pg.is_visible('#incidentModal'))

    # ---- Guided auto demo end-to-end
    pg.click('.nav-item[data-view="livedemo"]'); pg.click('#ldGuidedBtn'); t0=time.time()
    pg.wait_for_function("DEMO.flags.resolved===true",timeout=60000); dt=time.time()-t0
    T('Guided demo completes full workflow automatically',pg.locator('#ldStepper .ld-step.done').count()==8,f'{dt:.0f}s')
    T('Guided demo well under 2 minutes',dt<60,f'{dt:.0f}s')
    tl=txt(pg,'#ldTimeline')
    for k in ['Normal monitoring','Reading rose','SUSPECTED','Simulated smartwatch','Simulated RSO','acknowledged the alert','RSO action recorded','resolved by RSO']:
        T(f'Timeline contains "{k}"',k in tl)
    pg.click('text=Reset Demo')

    # ---- layout / mobile / a11y
    pg.set_viewport_size({'width':390,'height':800})
    pg.click('.nav-item[data-view="dashboard"]')
    sw=pg.evaluate("document.documentElement.scrollWidth")
    T('Mobile 390px: no horizontal page overflow',sw<=392,f'scrollWidth={sw}')
    pg.screenshot(path='/tmp/mobile_dash.png',full_page=False)
    pg.click('.nav-item[data-view="livedemo"]'); pg.screenshot(path='/tmp/mobile_demo.png')
    sw=pg.evaluate("document.documentElement.scrollWidth"); T('Mobile Live Demo: no horizontal overflow',sw<=392,f'scrollWidth={sw}')
    pg.set_viewport_size({'width':1400,'height':900})
    T('Modals have role=dialog',pg.evaluate("['incidentModal','actionModal','resolveModal'].every(i=>document.getElementById(i).getAttribute('role')==='dialog')"))
    T('Toast host is aria-live',pg.get_attribute('#toastHost','aria-live')=='polite')
    nolabel=pg.evaluate("[...document.querySelectorAll('input,select')].filter(e=>!e.id||!(document.querySelector('label[for=\"'+e.id+'\"]')||e.getAttribute('aria-label')||e.closest('label'))).map(e=>e.id||e.outerHTML.slice(0,40))")
    T('All inputs/selects have a label',len(nolabel)==0,str(nolabel))
    # Arabic text anywhere?
    html=pg.content()
    T('No Arabic text in UI',re.search('[\u0600-\u06FF]',html) is None)
    pg.click('.nav-item[data-view="dashboard"]'); pg.screenshot(path='/tmp/final_dash.png',full_page=True)
    pg.click('.nav-item[data-view="livedemo"]'); pg.click('#ldGuidedBtn'); pg.wait_for_timeout(11500); pg.screenshot(path='/tmp/final_demo.png',full_page=True)
    b.close()
finally: srv.terminate()
T('No JavaScript errors / console errors / dialogs during the whole run',len(errs)==0,str(errs[:5]))
json.dump(R,open(ROOT+'/logs/results_t2.json','w'))
print('\n',sum(1 for r in R if r[1]=='PASS'),'passed,',sum(1 for r in R if r[1]=='FAIL'),'failed')


# ---- exit-code footer (M-01): added in the Final Candidate; no assertion changed
import sys as _sys
_sys.exit(1 if any(r[1]=='FAIL' for r in R) else 0)
