# 01 — Defect-by-defect correction report (ALARAD Phase 3 → Final Candidate)
Scope: only the six approved items. No thresholds, dose mathematics, scenario ground truth or alert-detection policy were changed. Baseline `ALARAD_Prototype_Phase3.html` (SHA-256 `736b8ab6…b980b2e0`) is untouched; the candidate is a separate file (SHA-256 `50ea28a728023e7a13d2d7611437b783f7ab950db268a6f3d81381d05d136bab`/see 06). Simulated data only; no clinical or hospital-deployment approval is implied.
Evidence key: T = `tests/t_final_fixes.py` (49 checks; run against the baseline it FAILS 32 of them, proving it detects each defect), S = screenshots_before/ vs screenshots_after/, U = UI audit 92/92 on candidate.

## H-01 (HIGH) — unavailable monitoring shown as NORMAL → FIXED (verified)
- **Root cause:** `renderStaff`, `renderFloorMap`, `selectStaff`, `renderStaffMiniList` and the Dashboard read only `staff.status` (a cumulative-dose class); `staff.dataStatus` ("unknown") was read only by the Live Demo panel and watch face.
- **Change (display only):** new helpers `staffUnknown/staffUnmonNote/staffStatusHtml`; Staff Monitor, selected-staff panel, floor map (grey dashed dot, "· UNKNOWN" label, tooltip) and mini list show **UNKNOWN — MONITORING UNAVAILABLE**; the dose cell/panel adds **"observed dose is INCOMPLETE — N min unmonitored"** (new display field `staff.unmonMin`, persists after recovery because the dose remains incomplete); the Dashboard gets an amber banner with the worker count and the "Active Staff" sub-line changes from "Under monitoring" to "N monitored · M UNKNOWN (monitoring unavailable)".
- **Preserved:** `staff.status`, `incidentFlag`, alerts and the critical banner are not modified. An open radiation incident displays "UNKNOWN … / last assessed: CRITICAL (historical, not current) / radiation incident still open". The "last assessed" note is shown only for non-normal classes so the word NORMAL never appears beside an outage. No dose is added during an outage (checked: dose before = after).
- **Evidence:** T H-01 group (20 checks: outage, incident-preserved, recovery, other workers unaffected, dose math, dashboard banner/KPI); S `04c_`, `04d_`, `H01_floormap_minilist_during_outage` (before/after); U "outage-main-views" checks now PASS (were FAIL).

## M-04 — fault controls inert after the stream ends → FIXED
- **Root cause:** `demoInjectFault/ClearFault` accepted input with no further samples to process, so the badge read "HEALTHY (fault active: disconnect)".
- **Change:** `demoFaultBlock()`: while the stream is *paused awaiting worker acknowledgement* or *ended/resolved*, the Inject and Restore buttons are disabled with an explanatory note, functions refuse with a toast, and the health line reads "Sensor state at last sample: X · stream paused/ended — no further samples" (naming any fault still active at the last sample). Controls re-enable after "Acknowledge & leave area". (Design note: the paused state is included because faults injected there were equally inert until acknowledgement.)
- **Evidence:** T M-04 (9 checks); S `06b_`; U lifecycle flow (order adapted, see 07).

## M-05 — zero slope / forecast across data gaps → FIXED
- **Change:** trend and forecast use only the trailing run of **contiguous** valid readings (≥3, last 4); otherwise the row shows "UNAVAILABLE — needs ≥3 contiguous valid readings", no forecast bars and no slope value. `linearForecast` is unchanged.
- **Evidence:** T M-05 (7 checks, exact OLS reference incl. slope 115.0 and forecast 537/652/767 for 190,310,420 after a gap); S `M05_trend_during_gap`; U "trend row shows no numeric slope" now PASS.

## M-06 — "NORMAL (UNCERTAIN …)" → FIXED
- **Change:** `workerStatus` returns "UNCERTAIN — repeated values, suspected frozen sensor (last assessed: NORMAL|ELEVATED|CRITICAL)"; Live Demo employee status leads with "UNCERTAIN — suspected frozen sensor" (the existing "DATA UNCERTAIN" badge is kept so the original test still passes); watch face shows DATA UNCERTAIN. Unusable data still returns "UNKNOWN — MONITORING UNAVAILABLE"; suspected-frozen stays usable (not a disconnection).
- **Evidence:** T M-06 (7 checks). Side effect (expected): the `worker_status` text of 54 S10/S12 frozen rows and two summary fingerprints differ from the Phase-3 `data/` CSVs; every metric column is identical (see 03).

## M-01 — exit codes → FIXED
- Footer `sys.exit(1 if any FAIL else 0)` appended to each runner; assertions untouched (diff: `logs/tests_diff_vs_phase3_runs.txt`). Evidence: original `t_validation.py` now exits 1 (its single intentional failure) while the 436-check set exits 0; `t_final_fixes.py` on the baseline exits 1. `tests/run_all_tests.sh` aggregates.

## M-02 — regression-transparency documentation → FIXED
- New `02_Test_Results_and_Regression_Transparency_CORRECTED.md` lists the five re-baselined Phase-1 assertions and the real 113/114 cause. The original document is not edited.

## M-07 — tablet overflow → FIXED (CSS only, Chromium)
- One rule: `@media(min-width:761px) and (max-width:1100px){.card table{display:block;max-width:100%;overflow-x:auto}}`. Page overflow at 768 px: Staff Monitor 875→768, Policy Mapping 900→768, all 13 views ≤768. Desktop (1440 and 1101 px) keeps `display:table`; mobile (390 px) unchanged (`display:block`, no overflow). Firefox/WebKit NOT TESTED.

## Not changed / not fixed
M-03 (package not self-contained), L-02 … L-06, and the new observations in 04_Updated_Defect_Register.csv.
