# 02 — Test results and regression transparency (CORRECTED; supersedes `2_Test_Results_and_Regression_Transparency.md`, which is left untouched)
All counts below were executed on the Final Candidate (SHA-256 `50ea28a728023e7a13d2d7611437b783f7ab950db268a6f3d81381d05d136bab`); logs in `logs/run_*`.

| Category | Suite | Executed | Passed | Failed | Exit code | Notes |
|---|---|---|---|---|---|---|
| A. Original, assertions unmodified | `t2_rerun.py` (original 92) | 92 | 92 | 0 | 0 | identical to Phase-2 `test_original_92_suite.py` apart from output path + exit footer |
| B. **Re-baselined in Phase 2 (5 assertions revised)** | `t_sim_v2.py` (Phase-1 Simulation Lab) | 87 | 87 | 0 | 0 | not "unchanged" — see list below |
| C. Phase-2 suite, 1 intentional revision | `t_validation_v2.py` | 114 | 114 | 0 | 0 | |
| C′. Phase-2 original (kept for transparency, not in the total) | `t_validation.py` | 114 | 113 | 1 | 1 | the one FAIL is the NaN-engine expectation the Phase-3 fix intentionally changed |
| D. New in Phase 3 | `t_phase3.py` | 143 | 143 | 0 | 0 | |
| **Existing checks** | A+B+C+D | **436** | **436** | **0** | | |
| E. **New in this correction** | `t_final_fixes.py` | 49 | 49 | 0 | 0 | H-01 20, M-04 9, M-05 7, M-06 7, M-07 5, console 1 |
| **All executed on candidate** | | **485** | **485** | **0** | | skipped 0; could-not-run 0 |

Mutation/detection proof: `t_final_fixes.py` run against the unpatched Phase-3 baseline: 17 PASS / **32 FAIL**, exit 1.

## The five re-baselined Phase-1 assertions (in `t_sim_v2.py`, vs the original `test_simlab.py`)
1. Comparison table: 15 → **16** columns (F1 column added in Phase 2).
2. Step CSV: 19 → **21** columns (`reading_valid`, `dt_min` added).
3. CSV row check for S2 engine rate: column index 5 → **7**.
4. CSV ground-truth column check: index 3 → **4**.
5. Report-section heading list: "5. Limitations / 6. Reproducibility" → **"6. Limitations / 7. Reproducibility"** (a section was inserted).
These are schema/heading changes, not threshold changes, but they are *revised* tests. Run unmodified on a Phase-3 build the original Phase-1 suite gives 55 PASS, 3 FAIL, then crashes (exit 1).

## The real cause of 113 vs 114
`t_validation*.py` lines 363–369: `if SL_TEST_STATUS exists → 2 checks, else → 1 always-true placeholder`. It is a conditional placeholder, not "the status card adds one check" (the previous wording was inaccurate). No check is lost.

## Other facts
- No skip mechanism exists; 0 skipped. Dead `if False else` branches (not counted): t2_rerun.py:93, t_phase3.py:429/449, t_validation(_v2).py:259/360.
- No mocks; tests drive the real HTML in Chromium. The embedded Lab "test status" card is static, hand-authored JSON (L-04); it was **not** updated and is not evidence.
- Runner exit codes (M-01) now reflect failures. Firefox and WebKit: **NOT TESTED**.
