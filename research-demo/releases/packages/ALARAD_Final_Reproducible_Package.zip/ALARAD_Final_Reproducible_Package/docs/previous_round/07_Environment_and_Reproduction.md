# 07 — Environment and reproduction
Linux sandbox, Python 3.13, Node 22, Playwright 1.56 + Chromium 141 (Firefox/WebKit not installed: NOT TESTED). Google Fonts blocked by the sandbox (fallback fonts).
1. Serve `ALARAD_Prototype_Final_Candidate.html` as `env/new/alarad_prototype.html` plus the Phase-1/Phase-2 reference builds in `env/p1`, `env/p2` (not included: M-03).
2. Adjust the absolute paths at the top of each runner, then `tests/run_all_tests.sh` (exit code ≠ 0 if any suite fails). `TARGET=base python3 t_final_fixes.py` serves the unpatched baseline to show the tests detect the defects.
3. `reference_calculations/ref_*.py`, `ui_audit.py` (usage in their docstrings; the arguments used are in `logs/run_refs.sh`).
Harness adaptations are listed in 03. No modified-baseline HTML exists; the baseline zip/HTML hashes were re-checked at the end.
