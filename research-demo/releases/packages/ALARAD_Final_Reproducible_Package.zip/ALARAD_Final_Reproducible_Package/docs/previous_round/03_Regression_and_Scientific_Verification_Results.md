# 03 — Regression and scientific verification on the Final Candidate
| Check | Result | Log |
|---|---|---|
| Existing automated checks | **436/436** pass (92+87+114+143), exit 0; 0 skipped | logs/run_t2_rerun, run_t_sim_v2, run_t_validation_v2, run_t_phase3 |
| Original `t_validation.py` | 113 pass / 1 intentional fail, exit 1 (now reported) | logs/run_t_validation |
| New targeted tests | **49/49** pass on candidate; **32 of 49 fail on the Phase-3 baseline** (17 pass) | logs/run_t_final_fixes_cand / _base |
| Independent science reference (exact rational, hand-derived) | 66 results: **65 PASS, 0 FAIL, 1 INFO** (identical to Phase-3 run) | logs/ref_science_cand_stdout.txt |
| 13 scenarios + metrics | 30/32 PASS, 2 expected "FAIL" = byte-identity with Phase-3 `data/` (see below); all TP/FP/FN/latency/P/R/F1/dose/DQ/unmonitored values recomputed from raw rows **match**; S1–S6 identical to Phase-2 | logs/ref_scenarios_cand_stdout.txt |
| Sensitivity sweep | 8,640 runs / 432 cells: **0 mismatches**; full re-run byte-identical to Phase-2 CSVs | logs/ref_sweep_cand_stdout.txt |
| Immediate-alert policy comparison | **30/30** rows reproduced | logs/ref_policy_cand_stdout.txt |
| Phase-2 vs candidate engine | 4,000 random valid inputs: **0 differences**; 10 invalid cases → unknown | logs/ref_before_after_cand_stdout.txt |
| Incident counts / validators / extremes / claim scan | identical to Phase-3 baseline run except the M-06 status text of ST-13 | logs/ref_misc_results_cand.json |
| UI audit (Chromium; 1440×900, 768×1024, 390×844) | **92/92 PASS, 0 FAIL** (baseline: 85/92) ; 0 console errors | logs/ui_audit_results_cand.json |
| Firefox / WebKit | **NOT TESTED** (not installed) | — |

**Expected byte-difference (N-02):** regenerated S7–S13 steps CSV differs from the Phase-3 `data/safety_steps.csv` in exactly one column (`worker_status`, 54 cells: S10 and S12/ST-13 frozen minutes; "NORMAL (UNCERTAIN — repeated values)" → "UNCERTAIN — repeated values, suspected frozen sensor (last assessed: NORMAL)"), and the summary CSV in the `fingerprint` column of 2 rows (the fingerprint hashes that text). No numeric column changed. Regenerated files: `data_regenerated/`.
**Harness adaptations (disclosed):** `ui_audit.py` (a) acknowledges the worker before injecting the outage fault (faults are now blocked while the stream is paused), and (b) tests the disabled Inject button instead of the select; original in `reference_calculations/ui_audit_ORIG_BASELINE_VERSION.py`. No project test assertion was changed.
