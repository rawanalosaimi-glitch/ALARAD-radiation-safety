# 04 — Change log and hashes
Chain: untouched baseline → `build_tools/patch.py` (previous round: H-01, M-04, M-05, M-06, M-07; = superseded candidate `50ea28a7…d136bab`) → `build_tools/patch2.py` (this round) → final candidate `3ff46558…b5c53`. Diffs: `build_tools/final_candidate_vs_baseline.diff` (total), `build_tools/previous_round_candidate_vs_baseline.diff`.
## This round
| Change | Where | Defect |
|---|---|---|
| `staffUncertain`, uncertain branch in `staffStatusHtml`; floor-map/mini-list/panel labels; `#uncBanner`; KPI sub-line | candidate HTML | N-01 |
| STATIC RECORD banner, heading, `recordedFor`, corrected typed wording | candidate HTML (`SL_TEST_STATUS`, card renderer) | N-03 |
| `regen_data.py`, `data_sync_diff.py`; `data/` regenerated | data | N-02 |
| `ROOT`-relative runners, `setup_env.sh`, `run_all.sh`, `summarize.py`, `build_candidate.sh`, `requirements.txt`, `SHA256SUMS.txt`, reference builds/data | package | M-03 |
| 15 new checks in `tests/t_final_fixes.py` (N-01 ×11, N-03 ×4); total there 64 | tests | N-01, N-03 |
**Unchanged:** `evaluateExposure`, thresholds, `integrateDose`, `doseAccount`, `immediateAlert`, `linearForecast`, `sensorStep`, scenario definitions, alert/incident logic, every assertion of the 436 existing checks (`tests_diff_vs_phase3_package.txt`: 0 non-path lines differ).
## Test classification
Original, unmodified assertions: 92 · Re-baselined in Phase 2 (5 assertions revised): 87 · Phase-2 suite (1 intentional revision): 114 · New Phase 3: 143 · New in the correction rounds: 64 (49 previous round + 15 this round). Skipped: 0. Could not run: 0. Firefox/WebKit: NOT TESTED.
## Hashes
`SHA256SUMS.txt` (every shipped input/test/script/data file, verified by `setup_env.sh`); evidence hashes: `hashes_evidence_sha256.txt`.
