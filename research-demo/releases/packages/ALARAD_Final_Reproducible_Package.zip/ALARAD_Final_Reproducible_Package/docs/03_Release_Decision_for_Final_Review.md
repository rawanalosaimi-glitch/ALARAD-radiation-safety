# 03 — Release decision for final independent review (PROPOSED — release NOT declared frozen)
Scope: the corrected MEDATHON 2026 research demonstration only (simulated data). No clinical, regulatory or hospital-deployment approval is implied.
**Final candidate:** `candidate/ALARAD_Prototype_Final_Release_Candidate.html`, SHA-256 `3ff465583697e5896a32591a8516bffd003d22fb3dd50a48984ad694021b5c53`. **Baseline** (untouched) `736b8ab657665ef04178b311acb318495228f6d96891c3c08b4b7dcbb980b2e0`; original Phase-3 zip `7cac1155f239446507608f7e2e27e76fbbc685100f89e2288b1f2be6fc1ff59a`.

**Proposed decision: CONDITIONAL APPROVAL — RESEARCH DEMO (unchanged), to be confirmed or revised by the independent reviewer.**
Evidence (all from one `run_all.sh` executed from an extracted copy of this package; `logs/SUMMARY.md`: ALL GATES PASS): existing 436/436 (92+87+114+143), targeted 64/64 (and 44 of 64 fail on the baseline, so they detect the defects) → 500 executed, 0 skipped, 0 failed; science 65/0/1 INFO; scenarios 32/32; sweep 0/8,640 and 0/432 mismatches; policy 30/30; 4,000 valid inputs identical to Phase 2; Chromium UI 92/92 at 1440×900, 768×1024, 390×844; data sync scope verified.

## Remaining findings (`02_Updated_Defect_Register.csv`)
0 BLOCKER · 0 HIGH · 0 MEDIUM open · LOW open: L-02 (`linearForecast([])` returns NaN, unreachable), L-03 (watch face shows "—" for a valid 0 reading; code inspection only), L-05 (Google Fonts external dependency), L-06 (app "before" column wording for null/text input) · mitigated: L-04 (static card, now labelled).
## Limitations to carry into the release note
1. **Firefox and WebKit: NOT TESTED**; all browser results are Chromium 141 only.
2. Tests show the software computes what it claims on synthetic data; not clinical or detection-accuracy validation. S10 remains a documented missed-event limitation; S3H is a purpose-built comparison scenario.
3. Reproduction needs Python ≥ 3.11 + `playwright==1.56.0` and Chromium (no network access to the app is required; Google Fonts are blocked/unavailable and fallback fonts are used).
4. The embedded Lab test card is still static hand-typed text (labelled as such; not evidence).
5. A typo in the gate script `summarize.py` (found in a first packaged run) was fixed and the **entire** run was then repeated from the final package; the figures above come from that second run.
6. Not freezing is deliberate: the release is to be declared frozen only after the independent review of this package.
