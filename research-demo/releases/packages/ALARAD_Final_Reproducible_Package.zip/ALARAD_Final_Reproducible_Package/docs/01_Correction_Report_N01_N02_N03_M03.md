# 01 — Correction report: N-01, N-02, N-03, M-03 (final minimal patch)
Candidate: `ALARAD_Prototype_Final_Release_Candidate.html`, SHA-256 `3ff465583697e5896a32591a8516bffd003d22fb3dd50a48984ad694021b5c53` (= untouched Phase-3 baseline `736b8ab6…b980b2e0` + `build_tools/patch.py` (previous round: H-01, M-04–M-07) + `build_tools/patch2.py` (this round)). Display/text-only changes; scientific calculations, thresholds, alert policies, scenarios and test assertions are untouched. Simulated data only.

## N-01 — suspected-frozen (DATA UNCERTAIN) on the staff surfaces → FIXED
- Staff Monitor: "DATA UNCERTAIN — suspected frozen sensor" badge (no NORMAL badge), with "repeated identical readings: not a confirmed sensor failure and not a verified current measurement. Last assessed: <class>". An open incident marker is kept.
- Selected-staff panel, floor map (dashed outline, "· UNCERTAIN", tooltip), mini list ("DATA UNCERTAIN — suspected frozen") and Dashboard (separate amber banner with count; KPI line "N monitored · K DATA UNCERTAIN (suspected frozen)") use the same wording.
- Distinct from UNKNOWN: a frozen reading is still usable (dose keeps integrating, checked), the UNKNOWN banner stays hidden, the word DISCONNECTED never appears. Marker clears after two changed samples (existing exit rule).
- Evidence: `tests/t_final_fixes.py` N-01 group (11 checks); screenshots `evidence/screenshots_after/N01_*` vs `screenshots_before/` (baseline shows NORMAL).

## N-02 — generated data synchronised → FIXED
- `data/` = regenerated from the candidate with `reference_calculations/regen_data.py`. The same procedure run on the untouched Phase-3 build reproduces the Phase-3 package files **byte-for-byte** (method validated).
- `evidence/DATA_SYNC_REPORT.md` (machine-generated): `safety_steps.csv` — header and 540 rows identical, **only `worker_status` changed (54 cells: S10 and S12/ST-13 frozen minutes)**; `safety_summary.csv` — **only `fingerprint` changed (2 cells; the fingerprint hashes that text)**; `cmp.json` identical; `safety_report.md` identical (0 differing lines). **No numerical metric changed** (TP/FP/FN, latency, dose, unmonitored minutes, precision/recall/F1 all identical).
- S1–S6 files and the Phase-2 sweep CSVs are unchanged (byte-identical re-run).

## N-03 — static embedded test-status card → FIXED (labelled)
- A bordered banner above the card: "STATIC RECORD — NOT LIVE VERIFICATION EVIDENCE … This page does not run any test and cannot show that any test passed. Verification of a build is only by running the test commands in the verification package and reading its logs." Heading "Test execution status (static record)"; note names the build it was typed for (Phase-3, `736b8ab6…`) and that it was not updated.
- Corrected two inaccurate texts in the typed record ("87 unchanged" → "5 assertions re-baselined in Phase 2"; the "card adds one check" explanation → the real conditional-placeholder cause). Numbers unchanged (they describe the Phase-3 build). The original check "table rows = suites + total" is preserved.

## M-03 — reproducible delivery → FIXED
- Package contains: candidate, untouched baseline, Phase-1/Phase-2 reference builds (byte-identical to the earlier deliveries, see `reference_builds/PROVENANCE.md`), Phase-2 and Phase-3 reference data, tests, reference calculations, build scripts, `requirements.txt` (playwright 1.56.0, Chromium 141), `SHA256SUMS.txt` (verified by `setup_env.sh` before every run), `run_all.sh`, `summarize.py` (decides every gate; exit code 0 only if all pass).
- Runners now compute paths from the package root (`ROOT`), no absolute paths remain (grep-verified). Diff vs the Phase-3 package runners: only path/port/result-file lines and the exit-code footer; 0 other lines differ (`docs/tests_diff_vs_phase3_package.txt`).
- The candidate is rebuildable from the baseline (`build_tools/build_candidate.sh` → REPRODUCED).
- Proof: the whole verification was executed **from an extracted copy of the final zip** (see logs/ and SUMMARY.md).
