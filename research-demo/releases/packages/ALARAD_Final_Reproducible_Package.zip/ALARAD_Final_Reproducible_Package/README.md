# ALARAD — Final Release Candidate: reproducible verification package
**Status: candidate for final independent review. NOT declared frozen. Simulated data only; no clinical, regulatory or hospital-deployment claim.**

| Item | Value |
|---|---|
| Final candidate | `candidate/ALARAD_Prototype_Final_Release_Candidate.html` — SHA-256 `3ff465583697e5896a32591a8516bffd003d22fb3dd50a48984ad694021b5c53` |
| Untouched Phase-3 baseline | `baseline/ALARAD_Prototype_Phase3.html` — SHA-256 `736b8ab657665ef04178b311acb318495228f6d96891c3c08b4b7dcbb980b2e0` |
| Previous correction candidate (superseded) | `ALARAD_Prototype_Final_Candidate.html` — `50ea28a728023e7a13d2d7611437b783f7ab950db268a6f3d81381d05d136bab` |
| Original Phase-3 zip (never modified) | `7cac1155f239446507608f7e2e27e76fbbc685100f89e2288b1f2be6fc1ff59a` |

## Reproduce everything (relative paths only)
```
pip install -r requirements.txt && python3 -m playwright install chromium     # Python >= 3.11, Chromium 141 used
unzip ALARAD_Final_Reproducible_Package.zip && cd ALARAD_Final_Reproducible_Package
./run_all.sh            # ~20 min; verifies SHA256SUMS, rebuilds the candidate, runs every suite, writes logs/SUMMARY.md; exit 0 only if all gates pass
```
Individual commands (after `./setup_env.sh`): `python3 tests/t_phase3.py`, `python3 tests/t_final_fixes.py` (use `TARGET=base` to run the same tests against the untouched baseline: they must fail), `./build_tools/build_candidate.sh`, `python3 reference_calculations/ref_science.py env/new logs/x.json`, etc. (see `run_all.sh` for every argument). Test runners exit non-zero on any failure; `tests/run_all_tests.sh` aggregates them.

## Layout
`candidate/` `baseline/` · `reference_builds/` (Phase-1 `phase1_base.html`, Phase-2 `ALARAD_Prototype_Validation.html` — needed by the legacy-comparison tests; provenance in `reference_builds/PROVENANCE.md`) · `reference_data/` (Phase-2 CSVs for the regression/sweep checks, Phase-3 package data) · `data/` (generated data files synchronised with the candidate) · `tests/` · `reference_calculations/` · `build_tools/` (patch scripts + diff) · `docs/` · `evidence/` (before/after screenshots, regenerated data, DATA_SYNC_REPORT.md) · `logs/` (raw stdout/stderr/exit/duration of the run that produced the numbers in docs/, plus SUMMARY.md).

## Limits
Chromium only — **Firefox and WebKit: NOT TESTED**. Google Fonts are blocked in the sandbox (fallback fonts). Tests drive the real HTML; they show the software computes what it claims, not clinical performance.
