"""ALARAD v1.2.1 -> v1.2.2: ONE feature - manual 'Report to RSO' button on the simulated smartwatch. No calculation, threshold, prediction, automatic-alert or simulation logic is touched."""
import sys
src,dst=sys.argv[1],sys.argv[2]
s=open(src,encoding='utf-8').read()
def rep(old,new):
    global s
    assert s.count(old)==1,(s.count(old),old[:70])
    s=s.replace(old,new)
# CSS (watch button + confirmation line + manual tag)
rep(".watch .w-btn{margin-top:6px;}",
""".watch .w-btn{margin-top:6px;}
.watch .w-report{margin-top:8px;width:100%;font-weight:700;}
.watch .w-report:disabled{opacity:.55;cursor:not-allowed;}
.watch .w-confirm{font-size:10px;color:var(--green);margin-top:6px;line-height:1.35;min-height:14px;}
.cat-tag.manual{color:var(--purple);border-color:#5b3d8f;}""")
# smartwatch markup (shared by Live Demo and Wearable pages): always-visible button + confirmation line
rep("""<button class="btn sm solid w-btn" onclick="demoWorkerLeaves()" style="display:none">Acknowledge &amp; leave area</button>
      </div>""",
"""<button class="btn sm solid w-btn" onclick="demoWorkerLeaves()" style="display:none">Acknowledge &amp; leave area</button>
        <button type="button" class="btn sm red w-report" onclick="watchReportToRSO()">🚨 Report to RSO</button>
        <div class="w-confirm" role="status" aria-live="polite"></div>
      </div>""")
# per-refresh state of the button / confirmation line
rep("    el.querySelector('.w-btn').style.display=w.status==='alert'?'inline-block':'none';\n  });",
"""    el.querySelector('.w-btn').style.display=w.status==='alert'?'inline-block':'none';
    const wr=openWatchReport(), rb=el.querySelector('.w-report'), cf=el.querySelector('.w-confirm');
    rb.disabled=!!wr; rb.title=wr?'A manual report is already open — sent '+wr.reportedAt+' (simulated)':'Send a manual report to the simulated RSO queue (works in any radiation status)';
    cf.textContent=wr?'Report Sent to RSO (Simulated) · '+wr.reportedAt+(wr.ack?' · acknowledged by RSO '+(wr.ackAt||'')+' (simulated)':' · awaiting RSO acknowledgement (simulated)'):'';
  });""")
# the feature itself (next to the existing dashboard report function; that function is unchanged)
rep("function renderStaffMiniList(){",
"""/* v1.2.2 - manual report from the SIMULATED smartwatch. Human-initiated; independent of radiation status; never touches thresholds, engine or automatic alerts.
   Duplicate guard: while a report from this watch is open (not archived/resolved) no second one is created. */
function openWatchReport(){ return alerts.find(a=>a.watchReport&&!a.resolved&&a.staffId===DEMO.staffId); }
function watchReportToRSO(){
  const s=staff.find(x=>x.id===DEMO.staffId); if(!s) return;
  const ex=openWatchReport();
  if(ex){ toast('Report already sent (Simulated)',`A manual report from ${s.id} is already open (sent ${ex.reportedAt}) and awaits RSO handling on the Alerts page. No second report was created.`); return; }
  const t=nowClock(), w=DEMO.watch||{};
  const eng=(DEMO.last&&DEMO.last.riskLabel)?DEMO.last.riskLabel:'no reading yet';
  const rad=((s.dataStatus==='unknown')?'UNKNOWN (no current data)':s.status.toUpperCase()+(s.dataStatus==='uncertain'?' (DATA UNCERTAIN)':''))+' · latest engine assessment: '+eng;
  alerts.unshift({id:nextAlertId(),level:'info',simulated:true,manual:true,watchReport:true,category:'MANUAL REPORT · SMARTWATCH',staffId:s.id,reportedAt:t,
    title:`Manual report from smartwatch — ${s.name} (${s.id}), worker-initiated`,
    meta:`${t} · ${s.dept} · Source: worker-initiated manual report (simulated smartwatch) — not an automatic radiation alert · no real message was sent`,ack:false,
    timeline:[{time:t,label:'Worker pressed "Report to RSO" on the simulated smartwatch (simulated)',type:'normal'}],
    explain:[`Human-initiated report: ${s.name} chose to contact the RSO from the simulated smartwatch. It was not raised by the detection engine, a threshold or a forecast.`,
      `Radiation status shown by the prototype at the time of the report: ${rad}${w.rate?' · last watch reading '+w.rate+' µSv/h (simulated)':''}. The report is sent in every status, including NORMAL.`,
      `Location (simulated): ${s.dept} — illustrative coordinates, not real GPS · today’s dose ${s.today.toFixed(2)} mSv (illustrative)`,
      'Simulated only: no real smartwatch is connected and no real message or notification was delivered.']});
  renderAlerts(); demoRefresh();
  toast('Report Sent to RSO (Simulated)',`Manual report from ${s.id} added to the simulated RSO queue on the Alerts page. No real smartwatch or real message delivery is involved.`);
}
function renderStaffMiniList(){""")
# Alerts list: neutral wording for manual reports only (automatic alerts keep the existing text)
rep("<summary>Why was this alert triggered?</summary>","<summary>${a.manual?'Details of this manual report':'Why was this alert triggered?'}</summary>")
rep('<div style="margin-top:6px;color:var(--amber);">Prototype output — a suspected pattern for RSO review, not a confirmed event and not a medical decision.</div>',
    '<div style="margin-top:6px;color:var(--amber);">${a.manual?\'Worker-initiated manual report (simulated) — not generated by the detection engine, not a confirmed event and not a medical decision.\':\'Prototype output — a suspected pattern for RSO review, not a confirmed event and not a medical decision.\'}</div>')
rep("${a.category?`<span class=\"cat-tag ${a.dq?'dq':''}\">${a.category}</span>`:''}","${a.category?`<span class=\"cat-tag ${a.dq?'dq':a.manual?'manual':''}\">${a.category}</span>`:''}")
rep("ALARAD v1.2.1 — KSA","ALARAD v1.2.2 — KSA")
open(dst,'w',encoding='utf-8').write(s)
