# ALARAD v1.2.3 – RSO Response Workflow (SIMULATED)
Base: v1.2.2 (unchanged, kept in backup_v1.2.2_unchanged/). Everything is a simulation: no real smartwatch, hospital/RSO notification or emergency dispatch; no clinical validation.

## Changes
1. Live Demo "RSO Console" (the existing RSO notification panel) now shows the smartwatch manual report immediately on click: worker ID, location (simulated), report type, radiation status at report time, report time, with an Acknowledge button. Tagged MANUAL REPORT; the automatic incident box is tagged AUTOMATIC RADIATION ALERT.
2. Three distinct statuses: Report Received, Acknowledged by RSO, Response Initiated. Initiate Response is enabled only after Acknowledge; acknowledging never sets Response Initiated.
3. Same alert object as the Alerts page: state is shared both ways (no second system). Alerts page shows the same three statuses plus an Initiate Response button.
4. No "Resolved"/"Worker Safe" for manual reports. Existing Archive is shown as "Archived (simulated record closed)".
5. Report now stores location (department) and radiation status text; watch confirmation line adds "response initiated <time> (simulated)".
6. Version label ALARAD v1.2.3 — KSA.

## Design decisions / disclosures
- Alert level stays `info`. Archive is independent of Initiate Response (available after Acknowledge).
- Reset Demo removes the report/workflow (restores the alerts snapshot).
- Unchanged: thresholds, calculations, prediction, datasets, automatic alerts, duplicate guard, Emergency/GPS report.
- Test edits (disclosed): in the v1.2.2 manual-report test copy, label expectation -> v1.2.3 and two `text=Acknowledge` locators -> `button:has-text("Acknowledge")` (the new status chip "Acknowledged by RSO" also matches the text locator). Wording-suite copies: label expectation only.
- Chromium only; Firefox/WebKit NOT TESTED. summarize.py not used. No independent validation.

## Tests executed (Chromium, Playwright)
New t_v123_workflow: 85/85 (NORMAL, ELEVATED RISK, CRITICAL; sync both ways; duplicates; automatic independence; Reset; Emergency/GPS; 1440/768/390 overflow; no network; engine identity vs v1.2.2).
Regression: t_validation 113 pass/1 fail (same expected failure as before); t_final_fixes TARGET=base 20/44 (expected); ref_science 65 PASS+1 INFO; ref_scenarios 32/32; ref_policy 30/30; ref_sweep 31/31; ui_audit 92/92; v1.2 wording 37/37; v1.2.1 wording 21/21; v1.2.2 manual report 74/74; t_v12_responsive and t_header_v11 and others exit 0. See evidence/logs.
