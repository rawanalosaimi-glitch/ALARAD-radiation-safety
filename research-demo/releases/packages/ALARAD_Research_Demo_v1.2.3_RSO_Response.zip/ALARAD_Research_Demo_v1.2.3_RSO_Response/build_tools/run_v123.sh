#!/bin/bash
set -u; cd "$(dirname "$0")"; L=logs; mkdir -p $L evidence/data_regenerated_scenarios evidence/screenshots_after evidence/screenshots_before evidence/regen_candidate evidence/regen_baseline
run(){ n=$1; shift; "$@" > $L/$n.stdout 2> $L/$n.stderr; echo "$n exit=$?"; }
for n in t2_rerun t_sim_v2 t_validation_v2 t_phase3 t_final_fixes; do run run_$n python3 tests/$n.py; done
run run_t_validation python3 tests/t_validation.py
run run_t_final_fixes_base env TARGET=base python3 tests/t_final_fixes.py
RC=reference_calculations
run ref_science python3 $RC/ref_science.py env/new $L/ref_science_results.json
run ref_scenarios python3 $RC/ref_scenarios.py env/new . reference_data/phase2 evidence/data_regenerated_scenarios
run ref_policy python3 $RC/ref_policy.py env/new evidence/data_regenerated_scenarios
run ref_misc python3 $RC/ref_misc.py env/new $L/ref_misc_results.json
run ref_before_after python3 $RC/ref_before_after.py env/p2 env/new $L/ref_before_after_results.json
run ref_sweep python3 $RC/ref_sweep.py env/new reference_data/phase2 evidence/data_regenerated_scenarios
run ui_audit python3 $RC/ui_audit.py env/new evidence/screenshots_after $L/ui_audit_results.json
run shots_after python3 $RC/shots_extra.py env/new evidence/screenshots_after 8896
run regen_data_candidate python3 $RC/regen_data.py env/new evidence/regen_candidate
run t_v12_wording_for_v123 python3 ../../build/t_v12_wording_for_v123.py $PWD/env/new/alarad_prototype.html $PWD/../../build/v11_in.html
run t_v121_wording_for_v123 python3 ../../build/t_v121_wording_for_v123.py $PWD/env/new/alarad_prototype.html $PWD/../../build/v12_in.html
run t_v122_manual_report_for_v123 python3 ../../build/t_v122_manual_report_for_v123.py $PWD/env/new/alarad_prototype.html $PWD/../../build/v121_in.html
run t_v12_responsive python3 ../../build/t_v12_responsive.py $PWD/env/new/alarad_prototype.html $PWD/../../shots_tmp $PWD/../../build/v11_in.html
run t_v123_workflow python3 ../../build/t_v123_workflow.py $PWD/env/new/alarad_prototype.html $PWD/../../build/v122_in.html
run t_header_v11 python3 ../../../audit3/V11/build/t_header_v11.py $PWD/env/new/alarad_prototype.html
echo DONE
