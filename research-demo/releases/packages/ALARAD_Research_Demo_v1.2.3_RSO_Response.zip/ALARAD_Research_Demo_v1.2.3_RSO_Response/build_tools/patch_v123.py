"""ALARAD v1.2.2 -> v1.2.3: RSO response workflow for the manual smartwatch report (Live Demo RSO Console + Alerts, same alert object). No calculation, threshold, prediction, dataset, automatic-alert or Emergency/GPS logic is touched."""
import sys
src,dst=sys.argv[1],sys.argv[2]
s=open(src,encoding='utf-8').read()
def rep(old,new):
    global s
    assert s.count(old)==1,(s.count(old),old[:70])
    s=s.replace(old,new)
# CSS: status ladder + tags (used by Live Demo RSO Console and by the Alerts page)
rep(".cat-tag.manual{color:var(--purple);border-color:#5b3d8f;}",
""".cat-tag.manual{color:var(--purple);border-color:#5b3d8f;}
.cat-tag.auto{color:var(--red);border-color:#6b2a33;margin:0 0 6px 0;}
.rso-box.manual{border-color:#5b3d8f;background:#150f24;margin-top:10px;}
.rso-box.manual .btn:disabled{opacity:.45;cursor:not-allowed;}
.rsl{display:flex;gap:6px;flex-wrap:wrap;margin:6px 0 8px;}
.rsl .st{font-size:10.5px;padding:3px 8px;border-radius:12px;border:1px dashed var(--border);color:var(--muted2);}
.rsl .st.on{border-style:solid;border-color:#5b3d8f;color:#fff;background:#241a40;}
.rsl .st.arch{border-style:solid;color:var(--muted);}""")
# shared helpers (placed with the v1.2.2 watch-report code)
rep("function openWatchReport(){",
"""/* v1.2.3 - three DISTINCT statuses on the same alert object: Report Received -> Acknowledged by RSO -> Response Initiated.
   Acknowledging never initiates a response. No 'Resolved' / 'Worker Safe' wording: archiving only closes the simulated record. */
function manualStatusHtml(a){
  const st=(on,txt)=>`<span class="st ${on?'on':''}">${txt}</span>`;
  return `<div class="rsl" aria-label="Manual report status (simulated)">${st(true,'① Report Received · '+a.reportedAt)}${st(a.ack,a.ack?'② Acknowledged by RSO · '+(a.ackAt||''):'② Acknowledged by RSO — pending')}${st(!!a.respAt,a.respAt?'③ Response Initiated · '+a.respAt:'③ Response Initiated — not initiated')}${a.resolved?`<span class="st arch">Archived (simulated record closed) · ${a.resolvedAt}</span>`:''}</div>`;
}
function initiateResponse(id){
  const a=alerts.find(x=>x.id===id);
  if(!a||!a.manual||!a.ack||a.resolved||a.respAt) return false;
  a.respAt=nowClock(); alertLog(a,'RSO selected "Initiate Response" (simulated) — no real dispatch and no real person was contacted','good');
  renderAlerts(); demoRefresh();
  toast('Response Initiated (Simulated)','Recorded at '+a.respAt+'. No real emergency response was dispatched and no real person was contacted.');
  return true;
}
function manualConsoleHtml(){
  const a=alerts.find(x=>x.watchReport); if(!a) return '';
  const rad=a.radStatus||'—';
  return `<div class="rso-box manual"><span class="cat-tag manual" style="margin:0 0 6px 0;">MANUAL REPORT · worker-initiated (simulated smartwatch)</span>
    <div style="color:#fff;font-weight:700;font-size:12.5px;">Worker ${a.staffId}</div>
    <div style="margin-top:4px;">Location (simulated): <b>${a.loc||'—'}</b> · Report type: <b>Manual report</b> · Radiation status at report time: <b>${rad}</b> · Report time: <b>${a.reportedAt}</b></div>
    ${manualStatusHtml(a)}
    <div style="display:flex;gap:6px;flex-wrap:wrap;">
      <button class="btn sm" ${a.ack||a.resolved?'disabled':''} onclick="ackAlert(${a.id})">Acknowledge</button>
      <button class="btn sm solid" ${(!a.ack||a.resolved||a.respAt)?`disabled title="${a.respAt?'Response already initiated':a.resolved?'Report archived':'Acknowledge first'}"`:''} onclick="initiateResponse(${a.id})">Initiate Response</button>
    </div>
    <div class="foot-note" style="margin-top:8px;border:none;padding:0;">Same report as on the Alerts page — state is shared. Acknowledging does not initiate a response. Simulated only: no real smartwatch, no real notification, no emergency dispatch.</div></div>`;
}
function openWatchReport(){""")
# store location + radiation status on the report (display fields only)
rep("category:'MANUAL REPORT · SMARTWATCH',staffId:s.id,reportedAt:t,",
    "category:'MANUAL REPORT · SMARTWATCH',staffId:s.id,reportedAt:t,loc:s.dept,radStatus:rad,")
# watch confirmation line: also show response status
rep("(wr.ack?' · acknowledged by RSO '+(wr.ackAt||'')+' (simulated)':' · awaiting RSO acknowledgement (simulated)')",
    "(wr.ack?' · acknowledged by RSO '+(wr.ackAt||'')+' (simulated)'+(wr.respAt?' · response initiated '+wr.respAt+' (simulated)':''):' · awaiting RSO acknowledgement (simulated)')")
# Live Demo RSO Console: tag the automatic box and append the manual box (existing automatic content unchanged)
rep("""    rso.innerHTML=`<div class="rso-box ${a.resolved?'done':'crit'}">
      <div style="color:#fff;font-weight:700;font-size:12.5px;">${a.title}</div>""",
    """    rso.innerHTML=`<div class="rso-box ${a.resolved?'done':'crit'}"><span class="cat-tag auto">AUTOMATIC RADIATION ALERT · rule-based (simulated)</span>
      <div style="color:#fff;font-weight:700;font-size:12.5px;">${a.title}</div>""")
rep("""Resolution requires acknowledgement, a recorded action and a reason.</div></div>`;
  }
  document.getElementById('ldTimeline')""",
    """Resolution requires acknowledgement, a recorded action and a reason.</div></div>`;
  }
  rso.innerHTML+=manualConsoleHtml();     /* v1.2.3: manual smartwatch report shown here too (same alert object as the Alerts page) */
  document.getElementById('ldTimeline')""")
# Alerts page: status ladder + Initiate Response + archive wording for manual reports only
rep("${a.resolved?' · <span style=\"color:var(--cyan)\">Resolved '+a.resolvedAt+'</span>':''}</div>",
    "${a.resolved?(a.manual?' · <span style=\"color:var(--cyan)\">Archived (simulated record closed) '+a.resolvedAt+'</span>':' · <span style=\"color:var(--cyan)\">Resolved '+a.resolvedAt+'</span>'):''}</div>\n          ${a.manual?manualStatusHtml(a):''}")
rep("${a.resolved&&a.resolution?`<div class=\"a-sub\"><b>Resolution reason:</b>","${a.resolved&&a.resolution&&!a.manual?`<div class=\"a-sub\"><b>Resolution reason:</b>")
rep("""            ${a.ack&&!a.resolved&&na?`<button class="btn sm" onclick="openActionModal(${a.id})">Add Action</button>`:''}""",
    """            ${a.manual&&a.ack&&!a.resolved&&!a.respAt?`<button class="btn sm solid" onclick="initiateResponse(${a.id})">Initiate Response</button>`:''}
            ${a.ack&&!a.resolved&&na?`<button class="btn sm" onclick="openActionModal(${a.id})">Add Action</button>`:''}""")
rep("ALARAD v1.2.2 — KSA","ALARAD v1.2.3 — KSA")
open(dst,'w',encoding='utf-8').write(s)
