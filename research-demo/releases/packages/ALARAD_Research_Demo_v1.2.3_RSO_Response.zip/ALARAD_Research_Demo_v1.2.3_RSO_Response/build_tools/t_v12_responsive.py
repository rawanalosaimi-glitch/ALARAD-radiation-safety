import sys,os
from playwright.sync_api import sync_playwright
f12,out,f11=sys.argv[1],sys.argv[2],sys.argv[3]; res=[]
def T(n,c,d=''):
    res.append(bool(c)); print(('PASS' if c else 'FAIL'),'|',n,('| '+str(d)[:200] if not c else ''))
def prep(b,f,w,h):
    pg=b.new_page(viewport={'width':w,'height':h}); pg.route('**/fonts.*/**',lambda r:r.abort()); pg.goto('file://'+f); pg.wait_for_timeout(400)
    pg.evaluate("(()=>{resetLiveDemo(false);DEMO.flags.started=true;DEMO.startedAt=0;})()")
    pg.evaluate("(()=>{for(let i=0;i<3;i++)demoTick();DEMO.fault={kind:'frozen',value:null};for(let i=0;i<7;i++)demoTick()})()"); return pg
with sync_playwright() as p:
    b=p.chromium.launch()
    for tag,w,h in (('desktop',1440,900),('tablet',768,1024),('mobile',390,844)):
        pg=prep(b,f12,w,h)
        for v in ('dashboard','staff','livedemo','alerts','anomaly','emergency'):
            pg.evaluate(f"showView('{v}')")
            if v=='livedemo': pg.evaluate("(()=>{for(let i=0;i<4;i++)demoTick()})()")
            pg.wait_for_timeout(150)
            ov=pg.evaluate("document.documentElement.scrollWidth-innerWidth")
            T(f'{tag} {w}px {v}: no horizontal page overflow (frozen-sensor state)',ov<=0,ov)
            if v in('staff','livedemo','alerts','anomaly','dashboard'):
                pg.screenshot(path=f'{out}/after/{tag}_{v}.png',full_page=False)
        pg.evaluate("showView('livedemo')"); el=pg.query_selector('#ldPredict'); el.scroll_into_view_if_needed(); pg.wait_for_timeout(150)
        r=el.bounding_box(); T(f'{tag}: forecast note fits in viewport width',r['x']>=0 and r['x']+r['width']<=w+1,r)
        el.screenshot(path=f'{out}/after/{tag}_forecast_box.png')
        pg.evaluate("showView('emergency')"); fm=pg.query_selector('#floorMap'); 
        if fm: fm.scroll_into_view_if_needed(); fm.screenshot(path=f'{out}/after/{tag}_floormap.png')
        pg.close()
    for tag,w,h in (('desktop',1440,900),):
        pg=prep(b,f11,w,h); pg.evaluate("showView('emergency')"); fm=pg.query_selector('#floorMap'); fm.screenshot(path=f'{out}/before/{tag}_floormap_v1.1.png')
        pg.evaluate("showView('staff')"); pg.screenshot(path=f'{out}/before/{tag}_staff_v1.1.png'); pg.evaluate("showView('livedemo')"); 
        pg.evaluate("(()=>{for(let i=0;i<4;i++)demoTick()})()"); pg.query_selector('#ldPredict').screenshot(path=f'{out}/before/{tag}_forecast_box_v1.1.png'); pg.close()
    b.close()
print('TOTAL',len(res),'PASS',sum(res),'FAIL',len(res)-sum(res)); sys.exit(0 if all(res) else 1)
