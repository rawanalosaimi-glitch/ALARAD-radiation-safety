"""Targeted checks v1.2.2 - manual 'Report to RSO' from the simulated smartwatch. Usage: t_v122_manual_report.py <v1.2.2.html> <v1.2.1.html>"""
import sys,json
from playwright.sync_api import sync_playwright
F,F0=sys.argv[1],sys.argv[2]; res=[]
def T(n,c,d=''):
    res.append(bool(c)); print(('PASS' if c else 'FAIL'),'|',n,('| '+str(d)[:260] if not c else ''))
def boot(b,f,w=1440,h=900):
    pg=b.new_page(viewport={'width':w,'height':h}); pg.route('**/fonts.*/**',lambda r:r.abort()); pg.goto('file://'+f); pg.wait_for_timeout(400); return pg
SNAP="""()=>JSON.stringify({staff:staff,alerts:alerts.filter(a=>!a.watchReport),flags:DEMO.flags,watch:DEMO.watch,last:DEMO.last&&DEMO.last.riskLabel,sensor:DEMO.sensor&&DEMO.sensor.state})"""
with sync_playwright() as p:
    b=p.chromium.launch(); pg=boot(b,F); E=pg.evaluate; errs=[]; reqs=[]
    pg.on('pageerror',lambda e:errs.append(str(e))); pg.on('request',lambda r:reqs.append(r.url) if not r.url.startswith('file:') and 'fonts.g' not in r.url else None)
    def setup(n): E("(()=>{resetLiveDemo(false);DEMO.flags.started=true;DEMO.startedAt=0;for(let i=0;i<%d;i++)demoTick()})()"%n)
    def toasts(): return E("document.getElementById('toastHost').innerText")
    def check_state(name,prep,expect_status):
        prep(); E("showView('livedemo')"); pg.wait_for_timeout(200)
        btn=pg.locator('#view-livedemo .w-report'); vis=btn.is_visible(); bb=btn.bounding_box(); wb=pg.locator('#view-livedemo .watch').bounding_box()
        T(f'[{name}] "Report to RSO" button is visible inside the smartwatch, enabled, and within the watch frame',vis and btn.is_enabled() and 'Report to RSO' in btn.inner_text() and bb['x']>=wb['x'] and bb['x']+bb['width']<=wb['x']+wb['width']+1,(bb,wb))
        T(f'[{name}] radiation status as expected ({expect_status})',expect_status(),E("[DEMO.watch.status,demoStaff().status,DEMO.last&&DEMO.last.riskLabel]"))
        before=E(SNAP); n0=E("alerts.length"); act0=E("alerts.filter(a=>!a.resolved).length"); crit0=E("alerts.filter(a=>!a.resolved&&a.level==='critical').length")
        btn.click(); pg.wait_for_timeout(250)
        T(f'[{name}] click shows confirmation "Report Sent to RSO (Simulated)" (toast and on the watch)','Report Sent to RSO (Simulated)' in toasts() and 'Report Sent to RSO (Simulated)' in pg.locator('#view-livedemo .w-confirm').inner_text(),toasts())
        T(f'[{name}] exactly one manual report created (alerts +1)',E("alerts.length")==n0+1 and E("alerts.filter(a=>a.watchReport).length")==1)
        a=E("(()=>{const a=alerts.find(a=>a.watchReport);return {level:a.level,manual:a.manual,cat:a.category,title:a.title,meta:a.meta,ex:a.explain.join(' | '),inc:!!a.incident,demo:!!a.demo,ack:a.ack,st:a.staffId}})()")
        T(f'[{name}] report is distinguished from automatic alerts: MANUAL tag, worker-initiated wording, not an incident/demo alert, info level',a['manual'] and 'MANUAL REPORT' in a['cat'] and 'worker-initiated' in a['title'] and 'not an automatic radiation alert' in a['meta'] and a['level']=='info' and not a['inc'] and not a['demo'],a)
        T(f'[{name}] explanation records the radiation status at report time and the simulated-only disclaimer','Radiation status shown by the prototype at the time of the report:' in a['ex'] and 'latest engine assessment:' in a['ex'] and 'no real smartwatch is connected' in a['ex'] and 'no real message' in a['ex'],a['ex'])
        T(f'[{name}] automatic side untouched: staff doses/status, existing alerts, demo flags, watch, engine assessment and sensor state identical',E(SNAP)==before)
        T(f'[{name}] active-alert count +1 and critical count unchanged',E("alerts.filter(a=>!a.resolved).length")==act0+1 and E("alerts.filter(a=>!a.resolved&&a.level==='critical').length")==crit0)
        T(f'[{name}] button now disabled (duplicate guard) with confirmation line awaiting RSO',pg.locator('#view-livedemo .w-report').is_disabled() and 'awaiting RSO acknowledgement (simulated)' in pg.locator('#view-livedemo .w-confirm').inner_text())
        # repeated clicks / calls
        E("(()=>{for(let i=0;i<5;i++)watchReportToRSO();document.querySelectorAll('.w-report').forEach(x=>{x.click();x.click()})})()"); 
        try: pg.locator('#view-livedemo .w-report').click(force=True,click_count=3,timeout=1500)
        except Exception: pass
        pg.wait_for_timeout(150)
        T(f'[{name}] repeated clicks/calls (5 direct + 6 DOM + 3 forced) create NO duplicate',E("alerts.filter(a=>a.watchReport).length")==1 and E("alerts.length")==n0+1,E("alerts.length"))
        T(f'[{name}] a repeat attempt tells the user a report is already open (no second report)','Report already sent (Simulated)' in toasts())
        # RSO workflow
        E("showView('alerts')"); pg.wait_for_timeout(150)
        item=pg.locator('#alertsList .alert-item:has-text("Manual report from smartwatch")')
        T(f'[{name}] report appears in the simulated RSO workflow (Alerts page) with Acknowledge button',item.count()==1 and item.locator('button:has-text("Acknowledge")').count()==1 and 'MANUAL REPORT' in item.inner_text() and 'Why was this alert triggered?' not in item.inner_text(),item.inner_text()[:200])
        badge=int(E("document.getElementById('alertCountBadge').textContent")); T(f'[{name}] sidebar alert badge / KPI count include the report',badge==E("alerts.filter(a=>!a.resolved).length") and int(E("document.getElementById('kpiAlerts').textContent"))==badge)
        auto_ack0=E("alerts.filter(a=>!a.watchReport).map(a=>a.ack)")
        item.locator('button:has-text("Acknowledge")').click(); pg.wait_for_timeout(200)
        T(f'[{name}] RSO acknowledges the manual report with the existing mechanism',E("alerts.find(a=>a.watchReport).ack")==True and 'Acknowledged' in item.inner_text())
        T(f'[{name}] acknowledging the manual report leaves every automatic alert and demo flag untouched',E("alerts.filter(a=>!a.watchReport).map(a=>a.ack)")==auto_ack0 and E(SNAP)==before)
        E("showView('livedemo')"); pg.wait_for_timeout(150)
        T(f'[{name}] watch shows the acknowledgement; button still disabled until the report is closed',pg.locator('#view-livedemo .w-report').is_disabled() and 'acknowledged by RSO' in pg.locator('#view-livedemo .w-confirm').inner_text())
        flag0=E("demoStaff().incidentFlag"); st0=E("demoStaff().status")
        E("showView('alerts')"); item=pg.locator('#alertsList .alert-item:has-text("Manual report from smartwatch")'); item.locator('text=Archive').click(); pg.wait_for_timeout(250)
        T(f'[{name}] RSO can archive (resolve) the acknowledged manual report; staff incident flag/status not altered',E("alerts.find(a=>a.watchReport).resolved")==True and E("demoStaff().incidentFlag")==flag0 and E("demoStaff().status")==st0,(flag0,st0))
        E("showView('livedemo')"); pg.wait_for_timeout(150)
        T(f'[{name}] after closing, the button is enabled again and a NEW report is possible (one more, not a duplicate)',pg.locator('#view-livedemo .w-report').is_enabled() and (pg.locator('#view-livedemo .w-report').click() or True) and E("alerts.filter(a=>a.watchReport).length")==2 and E("alerts.filter(a=>a.watchReport&&!a.resolved).length")==1)
        # keep consistency of other pages
        E("showView('wearable')"); pg.wait_for_timeout(150)
        T(f'[{name}] Wearable page watch mirrors the button state (disabled while a report is open) and text',pg.locator('#view-wearable .w-report').is_disabled() and 'Report Sent to RSO (Simulated)' in pg.locator('#view-wearable .w-confirm').inner_text())
    check_state('NORMAL',lambda:setup(2),lambda:E("DEMO.watch.status")=='normal' and E("demoStaff().status")=='normal' and E("DEMO.last.riskLabel")=='LOW RISK')
    check_state('WARNING/ELEVATED',lambda:setup(7),lambda:E("DEMO.last.riskLabel")=='ELEVATED RISK' and E("demoStaff().status")=='normal')
    def crit():
        setup(8); pg.wait_for_function("DEMO.watch.status==='alert'",timeout=20000); pg.wait_for_function("DEMO.flags.rso===true",timeout=20000); pg.wait_for_timeout(800)
    check_state('CRITICAL',crit,lambda:E("DEMO.watch.status")=='alert' and E("demoStaff().status")=='critical')
    # critical: the automatic incident is still fully usable and independent
    setup(8); pg.wait_for_function("DEMO.watch.status==='alert'",timeout=20000); pg.wait_for_function("DEMO.flags.rso===true",timeout=20000)
    E("showView('livedemo')"); pg.locator('#view-livedemo .w-report').click(); pg.wait_for_timeout(200)
    auto=E("alerts.find(a=>a.demo)"); T('CRITICAL: the automatic demo incident alert exists, is critical, not acknowledged and not affected by the manual report',auto is not None and auto['level']=='critical' and auto['ack']==False and auto['incident'])
    E("showView('alerts')"); pg.locator('#alertsList .alert-item.critical:has-text("live demo") >> text=Acknowledge').first.click(); pg.wait_for_timeout(200)
    T('CRITICAL: acknowledging the automatic incident does not acknowledge the manual report (and vice versa)',E("alerts.find(a=>a.demo).ack")==True and E("alerts.find(a=>a.watchReport).ack")==False)
    # data-quality / not started / reset
    pg.close(); pg=boot(b,F); E=pg.evaluate; pg.on('pageerror',lambda e:errs.append(str(e)))
    E("showView('livedemo')"); pg.wait_for_timeout(150)
    T('demo NOT started: button still visible and works (status-independent)',pg.locator('#view-livedemo .w-report').is_visible() and pg.locator('#view-livedemo .w-report').is_enabled())
    pg.locator('#view-livedemo .w-report').click(); pg.wait_for_timeout(200)
    T('demo not started: report created with "no reading yet" engine note',E("alerts.filter(a=>a.watchReport).length")==1 and 'no reading yet' in E("alerts.find(a=>a.watchReport).explain.join(' ')"))
    E("resetLiveDemo(false)"); T('Reset Demo restores the simulated world: report removed (like every other simulated change) and the button is enabled again',E("alerts.filter(a=>a.watchReport).length")==0 and E("document.querySelector('#view-livedemo .w-report').disabled")==False)
    # automatic alerts unaffected: full automatic scenario with and without an early manual report gives the same automatic alert
    def run(report):
        E("(()=>{resetLiveDemo(false);DEMO.flags.started=true;DEMO.startedAt=0;})()")
        if report: E("watchReportToRSO()")
        E("(()=>{for(let i=0;i<9;i++)demoTick()})()"); pg.wait_for_function("DEMO.flags.rso===true",timeout=20000)
        return E("(()=>{const a=alerts.find(a=>a.demo);return JSON.stringify({l:a.level,t:a.title,x:a.explain,s:demoStaff().status,f:DEMO.flags.detected,d:demoStaff().today.toFixed(6)})})()").replace('"',"'")
    r0=run(False); r1=run(True)
    T('automatic alert unaffected: same title, level, explanation, staff status and dose with or without a prior manual report',r0==r1,(r0[:120],r1[:120]))
    # dashboard manual report (existing feature) unaffected and independent
    E("showView('emergency')"); E("selectStaff('ST-04')"); n=E("alerts.length"); E("reportToRSO('ST-04')")
    T('existing dashboard "Report to Radiation Safety Officer" still works independently of the watch report',E("alerts.length")==n+1 and E("alerts.find(a=>a.manualReportFor==='ST-04')!==undefined") and E("alerts.find(a=>a.manualReportFor==='ST-04').level")=='critical')
    T('no network requests (nothing is actually sent anywhere)',not reqs,reqs)
    T('no page errors',not errs,errs)
    # responsive: watch + button on both pages at 3 widths
    for w,h in ((1440,900),(768,1024),(390,844)):
        q=boot(b,F,w,h); 
        for v in ('livedemo','wearable'):
            q.evaluate(f"showView('{v}')"); q.wait_for_timeout(150)
            bb=q.locator(f'#view-{v} .w-report').bounding_box(); ww=q.locator(f'#view-{v} .watch').bounding_box()
            T(f'{w}px {v}: button visible, inside the watch, no horizontal page overflow',bb and bb['x']>=ww['x'] and bb['x']+bb['width']<=ww['x']+ww['width']+1 and bb['x']+bb['width']<=w and q.evaluate("document.documentElement.scrollWidth-innerWidth")<=0)
        q.close()
    # engine identity vs v1.2.1
    JS="""()=>{const out=[];for(const room of ['Cath Lab 1','CT Suite','Fluoroscopy Suite'])for(const rate of [20,60,90,118,310,470,900,3000])for(const dur of [5,20,30,45])for(const mode of ['personal','area'])out.push(JSON.stringify(evaluateExposure({room,procMult:1.4,rate,dur,dist:2,refDist:1,shield:1,mode})));out.push(JSON.stringify(linearForecast([118,126,115,122,190,310,420,470])));out.push(JSON.stringify(CONFIG));out.push(JSON.stringify(SimLab.SCEN.map(s=>{const r=SimLab.run(s.id,3,0);return [s.id,r.fingerprint,r.TP,r.FP,r.FN]})));out.push(JSON.stringify(alerts.map(a=>[a.id,a.level,a.title,a.meta])));return out.join('\\n')}"""
    p0=boot(b,F0); p1=boot(b,F); T('calculations/forecast/CONFIG/Lab fingerprints/initial alerts byte-identical between v1.2.1 and v1.2.2',p0.evaluate(JS)==p1.evaluate(JS))
    h1=open(F,encoding='utf-8').read(); T('label ALARAD v1.2.3; disclaimers kept','ALARAD v1.2.3 — KSA' in h1 and 'SIMULATED DATA ONLY' in h1 and 'SIMULATED smartwatch · prototype, not a certified radiation measurement device' in h1)
    b.close()
print('TOTAL',len(res),'PASS',sum(res),'FAIL',len(res)-sum(res)); sys.exit(0 if all(res) else 1)
