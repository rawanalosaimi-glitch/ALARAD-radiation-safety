"""Targeted checks v1.2.3 - RSO response workflow. Usage: t_v123_workflow.py <v1.2.3.html> <v1.2.2.html>"""
import sys,re
from playwright.sync_api import sync_playwright
F,F0=sys.argv[1],sys.argv[2]; res=[]
def T(n,c,d=''):
    res.append(bool(c)); print(('PASS' if c else 'FAIL'),'|',n,('| '+str(d)[:300] if not c else ''))
def boot(b,f,w=1440,h=900):
    pg=b.new_page(viewport={'width':w,'height':h}); pg.route('**/fonts.*/**',lambda r:r.abort()); pg.goto('file://'+f); pg.wait_for_timeout(400); return pg
SNAP="""()=>JSON.stringify({staff:staff,alerts:alerts.filter(a=>!a.watchReport),flags:DEMO.flags,watch:DEMO.watch,last:DEMO.last&&DEMO.last.riskLabel,sensor:DEMO.sensor&&DEMO.sensor.state})"""
BAD=re.compile(r'Resolved|Worker Safe|Resolution reason',re.I)
with sync_playwright() as p:
    b=p.chromium.launch(); pg=boot(b,F); E=pg.evaluate; errs=[]; reqs=[]
    pg.on('pageerror',lambda e:errs.append(str(e))); pg.on('request',lambda r:reqs.append(r.url) if not r.url.startswith('file:') and 'fonts.g' not in r.url else None)
    def setup(n): E("(()=>{resetLiveDemo(false);DEMO.flags.started=true;DEMO.startedAt=0;for(let i=0;i<%d;i++)demoTick()})()"%n)
    con=lambda: E("document.getElementById('ldRso').innerText")
    man=lambda: pg.locator('#ldRso .rso-box.manual')
    ON=lambda: E("[...document.querySelectorAll('#ldRso .rso-box.manual .rsl .st')].map(x=>x.classList.contains('on'))")
    def workflow(name,prep,expect,via_alerts_response=False):
        prep(); E("showView('livedemo')"); pg.wait_for_timeout(200)
        T(f'[{name}] precondition',expect(),E("[DEMO.watch.status,demoStaff().status,DEMO.last&&DEMO.last.riskLabel]"))
        T(f'[{name}] before the report the console shows no manual box',man().count()==0)
        before=E(SNAP); n0=E("alerts.length")
        pg.locator('#view-livedemo .w-report').click(); pg.wait_for_timeout(250)
        T(f'[{name}] Live Demo is still the active page (no navigation needed) and the manual report is in the RSO Console immediately',E("document.getElementById('view-livedemo').classList.contains('active')") and man().count()==1)
        ct=man().inner_text(); a=E("(()=>{const a=alerts.find(a=>a.watchReport);return {id:a.id,t:a.reportedAt,rad:a.radStatus,loc:a.loc,st:a.staffId}})()")
        T(f'[{name}] essentials shown: worker ID, location, report type, radiation status, report time',a['st'] in ct and 'Location (simulated): '+a['loc'] in ct and 'Report type: Manual report' in ct and a['rad'] in ct and a['t'] in ct,ct)
        T(f'[{name}] radiation status text matches the state at report time',(E("demoStaff().status").upper() in a['rad']) and (E("DEMO.last.riskLabel") in a['rad']),a['rad'])
        T(f'[{name}] MANUAL REPORT tag; not labelled automatic; simulated-only disclaimer','MANUAL REPORT' in ct and 'AUTOMATIC RADIATION ALERT' not in ct and 'no real smartwatch' in ct and 'no emergency dispatch' in ct,ct)
        T(f'[{name}] statuses distinct: Report Received on; Acknowledged pending; Response not initiated',ON()==[True,False,False] and 'Acknowledged by RSO — pending' in ct and 'Response Initiated — not initiated' in ct,ON())
        T(f'[{name}] Initiate Response disabled before acknowledgement',man().locator('button:has-text("Initiate Response")').is_disabled())
        T(f'[{name}] no second report system: exactly one new alert object',E("alerts.length")==n0+1 and E("alerts.filter(a=>a.watchReport).length")==1)
        # acknowledge in the console
        man().locator('button:has-text("Acknowledge")').click(); pg.wait_for_timeout(200)
        T(f'[{name}] Acknowledge in the console uses the existing mechanism (alert.ack, ackAt)',E("alerts.find(a=>a.watchReport).ack")==True and bool(E("alerts.find(a=>a.watchReport).ackAt")))
        T(f'[{name}] after acknowledgement: status 2 on, status 3 STILL off (acknowledgement does not imply response)',ON()==[True,True,False] and E("alerts.find(a=>a.watchReport).respAt")is None and 'Response Initiated — not initiated' in man().inner_text())
        T(f'[{name}] Initiate Response now enabled, Acknowledge disabled',man().locator('button:has-text("Initiate Response")').is_enabled() and man().locator('button:has-text("Acknowledge")').is_disabled())
        E("showView('alerts')"); pg.wait_for_timeout(150); item=pg.locator('#alertsList .alert-item:has-text("Manual report from smartwatch")')
        T(f'[{name}] Alerts page shows the SAME state (acknowledged, response not initiated, Initiate Response offered)',item.count()==1 and 'Acknowledged by RSO ·' in item.inner_text() and 'Response Initiated — not initiated' in item.inner_text() and item.locator('button:has-text("Initiate Response")').count()==1,item.inner_text()[:260])
        if via_alerts_response:
            item.locator('button:has-text("Initiate Response")').click(); pg.wait_for_timeout(200)
            E("showView('livedemo')"); pg.wait_for_timeout(150)
            T(f'[{name}] Initiate Response clicked on the ALERTS page is reflected in the Live Demo console (sync both ways)',ON()==[True,True,True] and 'Response Initiated ·' in man().inner_text())
        else:
            E("showView('livedemo')"); pg.wait_for_timeout(150); man().locator('button:has-text("Initiate Response")').click(); pg.wait_for_timeout(200)
            T(f'[{name}] Initiate Response in the console -> all three statuses on, with a toast "Response Initiated (Simulated)"',ON()==[True,True,True] and 'Response Initiated (Simulated)' in E("document.getElementById('toastHost').innerText"))
            E("showView('alerts')"); pg.wait_for_timeout(150); item=pg.locator('#alertsList .alert-item:has-text("Manual report from smartwatch")')
            T(f'[{name}] Alerts page reflects Response Initiated and no longer offers the button','Response Initiated ·' in item.inner_text() and 'Response Initiated — not initiated' not in item.inner_text() and item.locator('button:has-text("Initiate Response")').count()==0)
        T(f'[{name}] no "Resolved" / "Worker Safe" wording anywhere on the open manual report (console + Alerts item)',not BAD.search(con()) and not BAD.search(item.inner_text()) and 'Worker Safe' not in E("document.body.innerText"),(con()[-200:],item.inner_text()[-200:]))
        T(f'[{name}] timeline records the simulated response (no dispatch / no real person)',any('Initiate Response' in x for x in E("alerts.find(a=>a.watchReport).timeline.map(t=>t.label)")))
        T(f'[{name}] simulation state untouched through the whole workflow (staff, doses, existing alerts, flags, watch, engine, sensor)',E(SNAP)==before)
        # duplicates
        E("(()=>{for(let i=0;i<5;i++)watchReportToRSO();document.querySelectorAll('.w-report').forEach(x=>{x.click();x.click()})})()"); pg.wait_for_timeout(150)
        T(f'[{name}] still no duplicate while the report is open (even after acknowledge + response)',E("alerts.filter(a=>a.watchReport).length")==1 and E("alerts.length")==n0+1)
        # archive
        E("showView('alerts')"); pg.wait_for_timeout(150); item=pg.locator('#alertsList .alert-item:has-text("Manual report from smartwatch")')
        item.locator('button:has-text("Archive")').click(); pg.wait_for_timeout(250)
        it=pg.locator('#alertsList .alert-item:has-text("Manual report from smartwatch")')
        T(f'[{name}] existing Archive works; wording "Archived (simulated record closed)", never Resolved/Worker Safe','Archived (simulated record closed)' in it.inner_text() and not BAD.search(it.inner_text()) and E("alerts.find(a=>a.watchReport).resolved")==True,it.inner_text()[:300])
        E("showView('livedemo')"); pg.wait_for_timeout(150)
        T(f'[{name}] console after archive: archived chip, no actions, watch button enabled again','Archived (simulated record closed)' in man().inner_text() and man().locator('button:has-text("Acknowledge")').is_disabled() and man().locator('button:has-text("Initiate Response")').is_disabled() and pg.locator('#view-livedemo .w-report').is_enabled() and not BAD.search(man().inner_text()))
        pg.locator('#view-livedemo .w-report').click(); pg.wait_for_timeout(250)
        T(f'[{name}] a new report starts a fresh workflow (status 1 only) in the console',E("alerts.filter(a=>a.watchReport).length")==2 and ON()==[True,False,False] and man().count()==1)
        # Reset Demo clears the workflow
        E("resetLiveDemo(false)"); pg.wait_for_timeout(200)
        T(f'[{name}] Reset Demo clears the workflow: no report, no manual box, watch button enabled, no confirmation line',E("alerts.filter(a=>a.watchReport).length")==0 and man().count()==0 and E("document.querySelector('#view-livedemo .w-report').disabled")==False and E("document.querySelector('#view-livedemo .w-confirm').textContent")=='')
    workflow('NORMAL',lambda:setup(2),lambda:E("DEMO.last.riskLabel")=='LOW RISK' and E("demoStaff().status")=='normal')
    workflow('ELEVATED RISK',lambda:setup(7),lambda:E("DEMO.last.riskLabel")=='ELEVATED RISK',via_alerts_response=True)
    def crit():
        setup(8); pg.wait_for_function("DEMO.watch.status==='alert'",timeout=20000); pg.wait_for_function("DEMO.flags.rso===true",timeout=20000); pg.wait_for_timeout(800)
    workflow('CRITICAL',crit,lambda:E("DEMO.watch.status")=='alert' and E("demoStaff().status")=='critical')
    # ---- automatic alert independence (CRITICAL with both boxes)
    crit(); E("showView('livedemo')"); pg.locator('#view-livedemo .w-report').click(); pg.wait_for_timeout(250)
    full=con()
    T('CRITICAL: console shows BOTH boxes, clearly labelled AUTOMATIC RADIATION ALERT and MANUAL REPORT','AUTOMATIC RADIATION ALERT' in full and 'MANUAL REPORT' in full and pg.locator('#ldRso .rso-box').count()==2 and full.index('AUTOMATIC RADIATION ALERT')<full.index('MANUAL REPORT'),full[:200])
    autoflags0=E("JSON.stringify([DEMO.flags.ack,DEMO.flags.action,DEMO.flags.resolved,alerts.find(a=>a.demo).ack,(alerts.find(a=>a.demo).actions||[]).length])")
    man().locator('button:has-text("Acknowledge")').click(); pg.wait_for_timeout(150); man().locator('button:has-text("Initiate Response")').click(); pg.wait_for_timeout(150)
    T('CRITICAL: acknowledging / initiating response on the manual report does NOT touch the automatic incident (flags, ack, actions)',E("JSON.stringify([DEMO.flags.ack,DEMO.flags.action,DEMO.flags.resolved,alerts.find(a=>a.demo).ack,(alerts.find(a=>a.demo).actions||[]).length])")==autoflags0 and 'AUTOMATIC' in con())
    pg.locator('#ldRso .rso-box.crit button:has-text("Acknowledge")').click(); pg.wait_for_timeout(200)
    T('CRITICAL: acknowledging the automatic alert works as before and does not change the manual report state',E("alerts.find(a=>a.demo).ack")==True and E("alerts.find(a=>a.watchReport).respAt")is not None and E("alerts.filter(a=>a.watchReport).length")==1)
    T('CRITICAL: automatic alert keeps its own wording (no manual/Archive wording leaks)','Resolution requires acknowledgement, a recorded action and a reason' in con() and 'Archived' not in pg.locator('#ldRso .rso-box.crit').inner_text())
    pg.locator('#ldRso .rso-box.crit button:has-text("Add Action")').click(); pg.click('text=Save Action'); pg.wait_for_timeout(200)
    T('CRITICAL: existing automatic Add Action -> Resolve workflow still enabled as before',pg.locator('#ldRso .rso-box.crit button:has-text("Resolve")').is_enabled())
    # ---- automatic scenario identical with / without a full manual workflow
    def run(manual):
        E("(()=>{resetLiveDemo(false);DEMO.flags.started=true;DEMO.startedAt=0;})()")
        if manual: E("(()=>{watchReportToRSO();const a=alerts.find(a=>a.watchReport);ackAlert(a.id);initiateResponse(a.id)})()")
        E("(()=>{for(let i=0;i<9;i++)demoTick()})()"); pg.wait_for_function("DEMO.flags.rso===true",timeout=20000)
        return E("(()=>{const a=alerts.find(a=>a.demo);return JSON.stringify({l:a.level,t:a.title,x:a.explain,s:demoStaff().status,f:DEMO.flags.detected,d:demoStaff().today.toFixed(6)})})()")
    T('automatic alert unaffected: identical title/level/explanation/status/dose with or without a full manual workflow before it',run(False)==run(True))
    # ---- Emergency/GPS report unchanged
    E("resetLiveDemo(false)"); E("showView('emergency')"); E("selectStaff('ST-04')"); n=E("alerts.length"); E("reportToRSO('ST-04')")
    g=E("(()=>{const a=alerts.find(a=>a.manualReportFor==='ST-04');return {lvl:a.level,man:!!a.manual,wr:!!a.watchReport,title:a.title}})()")
    T('Emergency/GPS report unchanged (critical level, its own title) and is NOT shown as a smartwatch manual report in the console',E("alerts.length")==n+1 and g['lvl']=='critical' and not g['man'] and not g['wr'] and g['title'].startswith('Manual report: ') and (E("showView('livedemo')") or True) and pg.locator('#ldRso .rso-box.manual').count()==0,g)
    # ---- responsive
    for w,h in ((1440,900),(768,1024),(390,844)):
        q=boot(b,F,w,h); q.evaluate("(()=>{resetLiveDemo(false);DEMO.flags.started=true;DEMO.startedAt=0;for(let i=0;i<7;i++)demoTick();watchReportToRSO();const a=alerts.find(a=>a.watchReport);ackAlert(a.id);initiateResponse(a.id)})()")
        for v in ('livedemo','alerts'):
            q.evaluate(f"showView('{v}')"); q.wait_for_timeout(200)
            ov=q.evaluate("document.documentElement.scrollWidth-innerWidth")
            sel='#ldRso .rso-box.manual' if v=='livedemo' else '#alertsList .alert-item:has-text("Manual report from smartwatch")'
            bb=q.locator(sel).first.bounding_box(); rl=q.locator(sel+' .rsl').first.bounding_box()
            T(f'{w}px {v}: no horizontal overflow; status ladder inside viewport',ov<=0 and bb['x']>=0 and rl['x']+rl['width']<=w+1,(ov,bb,rl))
        q.screenshot(path=f'/tmp/claude-0/ws_{w}.png')
        q.close()
    T('no network requests',not reqs,reqs)
    T('no page errors',not errs,errs)
    JS="""()=>{const out=[];for(const room of ['Cath Lab 1','CT Suite','Fluoroscopy Suite'])for(const rate of [20,60,90,118,310,470,900,3000])for(const dur of [5,20,30,45])for(const mode of ['personal','area'])out.push(JSON.stringify(evaluateExposure({room,procMult:1.4,rate,dur,dist:2,refDist:1,shield:1,mode})));out.push(JSON.stringify(linearForecast([118,126,115,122,190,310,420,470])));out.push(JSON.stringify(CONFIG));out.push(JSON.stringify(SimLab.SCEN.map(s=>{const r=SimLab.run(s.id,3,0);return [s.id,r.fingerprint,r.TP,r.FP,r.FN]})));out.push(JSON.stringify(alerts.map(a=>[a.id,a.level,a.title,a.meta])));return out.join('\\n')}"""
    p0=boot(b,F0); p1=boot(b,F); T('calculations/forecast/CONFIG/Lab fingerprints/initial alerts byte-identical between v1.2.2 and v1.2.3',p0.evaluate(JS)==p1.evaluate(JS))
    h=open(F,encoding='utf-8').read(); T('label ALARAD v1.2.3; simulation disclaimers kept','ALARAD v1.2.3 — KSA' in h and 'SIMULATED DATA ONLY' in h and 'SIMULATED smartwatch · prototype, not a certified radiation measurement device' in h)
    b.close()
print('TOTAL',len(res),'PASS',sum(res),'FAIL',len(res)-sum(res)); sys.exit(0 if all(res) else 1)
