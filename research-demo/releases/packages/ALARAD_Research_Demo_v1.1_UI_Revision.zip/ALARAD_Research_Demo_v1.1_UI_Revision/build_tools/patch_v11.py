import sys
src,dst=sys.argv[1],sys.argv[2]
s=open(src,encoding='utf-8').read()
def rep(old,new):
    global s
    assert s.count(old)==1,(s.count(old),old[:60])
    s=s.replace(old,new)
# CSS (added after .profile .avatar rule)
rep(".profile .avatar{",
""".hdr-left{display:flex;align-items:center;gap:8px 14px;min-width:0;flex:1 1 0;flex-wrap:wrap;}
.profile{flex-shrink:0;}
.profile .name,.profile .role{white-space:nowrap;}
.hosp{display:flex;flex-direction:column;line-height:1.25;min-width:0;}
.hosp-row{display:flex;align-items:center;gap:8px;flex-wrap:wrap;}
.live-pill{white-space:nowrap;}
@media(min-width:421px){.hosp-row{flex-wrap:nowrap;}}
@media(max-width:900px){.topbar{flex-wrap:wrap;row-gap:8px;}.hdr-left{flex:1 1 100%;}.profile{margin-left:auto;}}
.hosp .hname{font-size:14px;font-weight:700;color:#fff;letter-spacing:.2px;}
.hosp .hsub{font-size:10.5px;color:var(--muted);}
.demo-tag{display:inline-block;font-size:9.5px;font-weight:700;letter-spacing:.8px;color:#ffc857;background:#ffc85718;border:1px solid #ffc85766;padding:2px 7px;border-radius:4px;white-space:nowrap;}
.profile .avatar{""")
rep("  .topbar{padding:10px 12px;}",
"""  .topbar{padding:10px 12px;flex-wrap:wrap;row-gap:8px;}
  .hdr-left{flex:1 1 100%;order:1;}
  .profile{order:2;margin-left:auto;}
  .profile .role{display:block !important;}
  .hosp .hname{font-size:13px;}
  .live-pill{font-size:10.5px;padding:5px 10px;}
  .hdr-left .live-pill{display:flex;}""")
rep("""    <div class="topbar">
      <div class="live-pill"><span class="bar"></span><span class="bar"></span><span class="bar"></span> SIMULATED MONITORING — PROTOTYPE</div>""",
"""    <div class="topbar">
      <div class="hdr-left">
        <div class="hosp">
          <div class="hosp-row"><span class="hname">ALARAD Medical Center</span><span class="demo-tag" title="Fictional hospital environment — simulation only">SIMULATION / DEMO</span></div>
          <div class="hsub">Radiation Safety Monitoring System</div>
        </div>
        <div class="live-pill"><span class="bar"></span><span class="bar"></span><span class="bar"></span> SIMULATED MONITORING — PROTOTYPE</div>
      </div>""")
rep('<div class="name">Dr. Radiation Safety Officer</div>','<div class="name">Radiation Safety Officer</div>')
rep('<div class="role">King Fahad Medical City</div>','<div class="role">Safety Administration</div>')
open(dst,'w',encoding='utf-8').write(s)
# --- v1.1 step 2: sidebar version label (applied after header patch) ---
s=open(dst,encoding='utf-8').read()
assert s.count('ALARAD v1.0 — KSA')==1
open(dst,'w',encoding='utf-8').write(s.replace('ALARAD v1.0 — KSA','ALARAD v1.1 — KSA'))
