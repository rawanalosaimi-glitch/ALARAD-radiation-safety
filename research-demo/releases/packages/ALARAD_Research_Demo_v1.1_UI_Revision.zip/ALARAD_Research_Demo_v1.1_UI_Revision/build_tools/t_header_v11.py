import sys
from playwright.sync_api import sync_playwright
f=sys.argv[1]; res=[]
def T(n,c): res.append(bool(c)); print(('PASS' if c else 'FAIL'),'|',n)
with sync_playwright() as p:
    b=p.chromium.launch()
    for w,h in [(1920,1080),(1440,900),(1280,800),(1024,768),(768,1024),(600,900),(414,896),(390,844),(360,740),(320,640)]:
        pg=b.new_page(viewport={'width':w,'height':h}); pg.goto('file://'+f); pg.wait_for_timeout(500)
        r=pg.evaluate("""()=>{const t=s=>(document.querySelector(s)||{}).innerText||'';
        const vis=s=>{const e=document.querySelector(s);if(!e)return false;const r=e.getBoundingClientRect(),c=getComputedStyle(e);return r.width>0&&r.height>0&&c.display!='none'&&c.visibility!='hidden'};
        const inside=s=>{const e=document.querySelector(s).getBoundingClientRect();return e.left>=0&&e.right<=innerWidth+0.5};
        return {name:t('.profile .name'),role:t('.profile .role'),h:t('.hname'),sub:t('.hsub'),tag:t('.demo-tag'),pill:t('.live-pill'),
          vis:['.hname','.hsub','.demo-tag','.live-pill','.profile .name','.profile .role','.profile .avatar'].every(vis),
          inside:['.hname','.hsub','.demo-tag','.live-pill','.profile .name','.profile .role','.profile .avatar'].every(inside),
          ov:document.documentElement.scrollWidth>innerWidth, dr:document.body.innerText.includes('Dr. Radiation'), kf:document.body.innerText.includes('King Fahad')}}""")
        T(f'{w}px: texts exact',r['name']=='Radiation Safety Officer' and r['role']=='Safety Administration' and r['h']=='ALARAD Medical Center' and r['sub']=='Radiation Safety Monitoring System' and r['tag']=='SIMULATION / DEMO')
        T(f'{w}px: all header elements visible + inside viewport + no h-scroll',r['vis'] and r['inside'] and not r['ov'])
        T(f'{w}px: SIMULATED pill kept, no "LIVE", no "Dr.", no "King Fahad"','SIMULATED' in r['pill'] and 'LIVE' not in r['pill'] and not r['dr'] and not r['kf'])
        pg.close()
    b.close()
print('TOTAL',len(res),'PASS',sum(res),'FAIL',len(res)-sum(res)); sys.exit(0 if all(res) else 1)
