import sys
from playwright.sync_api import sync_playwright
f=sys.argv[1]; out=sys.argv[2]
with sync_playwright() as p:
    b=p.chromium.launch()
    for w,h in [(1920,1080),(1440,900),(1280,800),(1100,800),(1024,768),(900,800),(768,1024),(600,900),(414,896),(390,844),(360,740),(320,640)]:
        pg=b.new_page(viewport={'width':w,'height':h}); pg.goto('file://'+f); pg.wait_for_timeout(600)
        m=pg.evaluate("""()=>{const t=document.querySelector('.topbar').getBoundingClientRect();
        const q=s=>{const e=document.querySelector(s);if(!e)return null;const r=e.getBoundingClientRect();return [Math.round(r.left),Math.round(r.right),Math.round(r.top),Math.round(r.bottom),getComputedStyle(e).display]};
        return {topbarH:Math.round(t.height),hscroll:document.documentElement.scrollWidth>innerWidth,hname:q('.hname'),tag:q('.demo-tag'),sub:q('.hsub'),pill:q('.live-pill'),name:q('.profile .name'),role:q('.profile .role'),av:q('.profile .avatar')}}""")
        print(w,m)
        pg.screenshot(path=f'{out}_{w}.png',clip={'x':0,'y':0,'width':w,'height':min(h,200)})
        pg.close()
    b.close()
