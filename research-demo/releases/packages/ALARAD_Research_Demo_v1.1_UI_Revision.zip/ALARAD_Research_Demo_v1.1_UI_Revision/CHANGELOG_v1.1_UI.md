# ALARAD v1.1 — UI Revision (header only)
**SIMULATION / RESEARCH DEMO ONLY — NOT CLINICALLY VALIDATED.** Fictional hospital; all data simulated.

Base: frozen v1.0 (`ALARAD_Prototype_Research_Demo_v1.0_FROZEN.html`, SHA-256 3ff46558…b5c53). The frozen v1.0 files were not touched (hashes re-checked, see `evidence/frozen_v1.0_hashes_unchanged_check.txt`).
This is a separately versioned UI revision, NOT a new freeze or re-approval.

## Requested changes
| # | Request | Result |
|---|---|---|
| 1 | "Dr. Radiation Safety Officer" -> "Radiation Safety Officer" | Done |
| 2 | Fictional hospital name in header | "ALARAD Medical Center" (replaces the real-institution name "King Fahad Medical City" that was under the officer's name) |
| 3 | Subtitle | "Radiation Safety Monitoring System" under the hospital name |
| 4 | "Safety Administration" beneath the RSO role | Shown under "Radiation Safety Officer" (visible at all widths) |
| 5 | Small visible SIMULATION / DEMO label | Amber badge next to the hospital name |

## What changed (diff lines, `evidence/v1.0_to_v1.1.diff`)
- Topbar HTML: new `.hdr-left` block (hospital name, badge, subtitle, existing SIMULATED pill moved inside it) and two text edits in `.profile`.
- CSS: new classes `.hdr-left .hosp .hosp-row .hname .hsub .demo-tag`; responsive rules (<=900 px topbar wraps; <=760 px role line is shown instead of hidden).
- Nothing else: no JS, thresholds, calculations, alerts, predictions, scenarios or data touched. Update 2: sidebar footer label changed "ALARAD v1.0 — KSA" -> "ALARAD v1.1 — KSA" (text only; verified at 1440/768 px; hidden on mobile as in v1.0). Page `<title>` unchanged. Total diff vs v1.0: 33 changed-line markers (header HTML/CSS + footer label). Regression re-run after this change: 92/87/114/143, 64/64, ui_audit 92/92, header test 30/30 — all PASS.
- Reproducible: `build_tools/patch_v11.py <v1.0 html> <out>` reproduces the v1.1 file byte-for-byte.

## Responsive check (Chromium 141, Playwright 1.56)
Widths 1920, 1440, 1280, 1024, 768, 600, 414, 390, 360, 320: all header elements visible, inside viewport, no horizontal scroll, exact texts (`build_tools/t_header_v11.py`: 30/30 PASS). Layout: single row >=1100 px; wraps to 2–3 rows at tablet/mobile. Before/after screenshots in `evidence/`.

## Regression results (v1.1 build)
| Suite | Result |
|---|---|
| t2_rerun | 92/92 |
| t_sim_v2 | 87/87 |
| t_validation_v2 | 114/114 |
| t_phase3 | 143/143 (436 existing checks total: all PASS) |
| t_final_fixes (targeted) | 64/64 |
| ui_audit | 92/92 |
| ref_science | 0 FAIL (65 PASS of 66 rows; rest informational) |
| ref_scenarios | 32/32 |
| ref_policy | 0 mismatches of 30 |
| ref_sweep | 0 mismatches of 432; byte-identical to Phase-2 grid/runs |
| ref_misc | completed; 16 claim-term hits (same count as v1.0) |
| t_header_v11 (new) | 30/30 |

## Limitations
Chromium only; Firefox and WebKit/Safari NOT TESTED. Remaining LOW findings from v1.0 (L-02, L-03, L-05, L-06; L-04 mitigated) are unchanged. Google Fonts blocked in the sandbox (fallback fonts used). The v1.0 packaged `run_all.sh` hash gate was bypassed for this run (build under test replaced); the build-reproducibility and before/after-baseline steps were not re-run because the only change is header HTML/CSS.

## SHA-256
- v1.1 HTML: 35866ebc9389c44d90fa3f0dda33f1700980d855a9950d91f933af0fc71025a4
